--
-- PostgreSQL database dump
--

\restrict 2YHCTDHbh8AjRX2Umxh8D95xUgra8KQwTWF044YpmIJXPgbvAKUSWC3yQB3OgOJ

-- Dumped from database version 15.19 (Debian 15.19-0+deb12u1)
-- Dumped by pg_dump version 15.19 (Debian 15.19-0+deb12u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO postgres;

--
-- Name: alerts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alerts (
    id character varying NOT NULL,
    customer_id character varying NOT NULL,
    jeweller_id character varying NOT NULL,
    target double precision,
    metal character varying(10),
    alert_type character varying(10),
    buy_amount double precision,
    status character varying(20),
    triggered_at timestamp with time zone,
    triggered_price double precision,
    created_at timestamp with time zone
);


ALTER TABLE public.alerts OWNER TO postgres;

--
-- Name: app_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.app_settings (
    key character varying(100) NOT NULL,
    value text
);


ALTER TABLE public.app_settings OWNER TO postgres;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_logs (
    id character varying NOT NULL,
    actor_type character varying(20),
    actor_id character varying,
    actor_name character varying(200),
    jeweller_id character varying,
    action character varying(80),
    target character varying(200),
    detail json,
    created_at timestamp with time zone
);


ALTER TABLE public.audit_logs OWNER TO postgres;

--
-- Name: banners; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.banners (
    id character varying NOT NULL,
    jeweller_id character varying,
    title character varying(120),
    subtitle character varying(200),
    eyebrow character varying(60),
    image_url text,
    link character varying(60),
    sort integer,
    is_active boolean,
    created_at timestamp with time zone
);


ALTER TABLE public.banners OWNER TO postgres;

--
-- Name: bifurcation_invoices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bifurcation_invoices (
    id character varying NOT NULL,
    pool_id character varying NOT NULL,
    total_grams double precision,
    details json,
    status character varying(20),
    created_at timestamp with time zone
);


ALTER TABLE public.bifurcation_invoices OWNER TO postgres;

--
-- Name: customers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customers (
    id character varying NOT NULL,
    jeweller_id character varying NOT NULL,
    phone character varying(15) NOT NULL,
    first_name character varying(100),
    last_name character varying(100),
    email character varying(200),
    dob character varying(20),
    gender character varying(10),
    wallet_id character varying(20) NOT NULL,
    gold_grams double precision,
    silver_grams double precision,
    invested double precision,
    wallet_balance double precision,
    referral_code character varying(10) NOT NULL,
    referral_balance double precision,
    referred_by character varying,
    kyc_status character varying(20),
    kyc_data json,
    status character varying(20),
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.customers OWNER TO postgres;

--
-- Name: faqs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.faqs (
    id character varying NOT NULL,
    jeweller_id character varying,
    question text NOT NULL,
    answer text NOT NULL,
    sort integer,
    created_at timestamp with time zone
);


ALTER TABLE public.faqs OWNER TO postgres;

--
-- Name: gifts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gifts (
    id character varying NOT NULL,
    sender_id character varying NOT NULL,
    recipient_id character varying NOT NULL,
    jeweller_id character varying NOT NULL,
    grams double precision,
    rate double precision,
    amount double precision,
    theme character varying(30),
    message text,
    seen boolean,
    created_at timestamp with time zone
);


ALTER TABLE public.gifts OWNER TO postgres;

--
-- Name: goals; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.goals (
    id character varying NOT NULL,
    customer_id character varying NOT NULL,
    name character varying(100) NOT NULL,
    occasion character varying(50),
    target_grams double precision,
    months integer,
    deadline timestamp with time zone,
    start_grams double precision,
    created_at timestamp with time zone,
    metal character varying(10) DEFAULT 'gold'::character varying
);


ALTER TABLE public.goals OWNER TO postgres;

--
-- Name: jewellers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.jewellers (
    id character varying NOT NULL,
    business_name character varying(200) NOT NULL,
    owner_name character varying(200) NOT NULL,
    phone character varying(15) NOT NULL,
    email character varying(200) NOT NULL,
    password_hash character varying(200) NOT NULL,
    pan character varying(10),
    aadhaar character varying(12),
    address text,
    city character varying(100),
    state character varying(100),
    pincode character varying(6),
    logo_url character varying(500),
    primary_color character varying(7),
    secondary_color character varying(7),
    domain character varying(200),
    admin_domain character varying(200),
    gold_buy_markup_pct double precision,
    gold_sell_discount_pct double precision,
    silver_buy_markup_pct double precision,
    silver_sell_discount_pct double precision,
    gold_commission_per_g double precision,
    silver_commission_per_g double precision,
    min_redemption_grams double precision,
    status character varying(20),
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    gold22_commission_per_g double precision DEFAULT 0,
    gold18_commission_per_g double precision DEFAULT 0,
    app_name character varying(60) DEFAULT ''::character varying,
    bundle_id character varying(120) DEFAULT ''::character varying,
    theme_preset character varying(40) DEFAULT ''::character varying,
    splash_url character varying(500) DEFAULT ''::character varying,
    app_status character varying(30) DEFAULT 'details_pending'::character varying,
    app_version character varying(20) DEFAULT '1.0.0'::character varying,
    store_short character varying(80) DEFAULT ''::character varying,
    store_long text DEFAULT ''::text,
    store_keywords character varying(100) DEFAULT ''::character varying,
    support_email character varying(200) DEFAULT ''::character varying
);


ALTER TABLE public.jewellers OWNER TO postgres;

--
-- Name: master_admins; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.master_admins (
    id character varying NOT NULL,
    username character varying(100) NOT NULL,
    password_hash character varying(200) NOT NULL,
    name character varying(200),
    created_at timestamp with time zone
);


ALTER TABLE public.master_admins OWNER TO postgres;

--
-- Name: mt5_bookings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mt5_bookings (
    id character varying NOT NULL,
    metal character varying(10),
    symbol character varying(40),
    volume double precision,
    grams double precision,
    status character varying(20),
    ticket character varying(40),
    price double precision,
    error text,
    trigger character varying(20),
    created_at timestamp with time zone
);


ALTER TABLE public.mt5_bookings OWNER TO postgres;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications (
    id character varying NOT NULL,
    customer_id character varying NOT NULL,
    title character varying(200) NOT NULL,
    message text,
    type character varying(30),
    read boolean,
    created_at timestamp with time zone
);


ALTER TABLE public.notifications OWNER TO postgres;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    id character varying NOT NULL,
    customer_id character varying NOT NULL,
    jeweller_id character varying NOT NULL,
    metal character varying(10),
    grams double precision,
    rate double precision,
    amount double precision,
    gst double precision,
    total double precision,
    status character varying(20),
    provider character varying(20),
    payment_id character varying(100),
    method character varying(30),
    paid_at timestamp with time zone,
    created_at timestamp with time zone
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: otp_challenges; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.otp_challenges (
    id character varying NOT NULL,
    phone character varying(15) NOT NULL,
    jeweller_id character varying NOT NULL,
    digest character varying(100) NOT NULL,
    attempts integer,
    used boolean,
    created_at timestamp with time zone,
    expires_at timestamp with time zone NOT NULL
);


ALTER TABLE public.otp_challenges OWNER TO postgres;

--
-- Name: pickups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pickups (
    id character varying NOT NULL,
    customer_id character varying NOT NULL,
    jeweller_id character varying NOT NULL,
    transaction_id character varying,
    item character varying(200) NOT NULL,
    grams double precision,
    making_charges double precision,
    otp character varying(6) NOT NULL,
    attempts integer,
    locked boolean,
    status character varying(20),
    collected_at timestamp with time zone,
    collected_by character varying(100),
    created_at timestamp with time zone
);


ALTER TABLE public.pickups OWNER TO postgres;

--
-- Name: pool_accumulator; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pool_accumulator (
    id character varying NOT NULL,
    total_grams double precision,
    threshold_grams double precision,
    status character varying(20),
    triggered_at timestamp with time zone,
    procured_at timestamp with time zone,
    created_at timestamp with time zone
);


ALTER TABLE public.pool_accumulator OWNER TO postgres;

--
-- Name: pool_contributions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pool_contributions (
    id character varying NOT NULL,
    pool_id character varying NOT NULL,
    transaction_id character varying NOT NULL,
    customer_id character varying NOT NULL,
    jeweller_id character varying NOT NULL,
    grams double precision,
    created_at timestamp with time zone
);


ALTER TABLE public.pool_contributions OWNER TO postgres;

--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    id character varying NOT NULL,
    jeweller_id character varying NOT NULL,
    name character varying(200) NOT NULL,
    category character varying(50),
    grams double precision,
    making_charges double precision,
    making_pct double precision,
    image_url character varying(500),
    tag character varying(50),
    description text,
    is_active boolean,
    created_at timestamp with time zone,
    purity character varying(5) DEFAULT '22K'::character varying
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: quotes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quotes (
    id character varying NOT NULL,
    jeweller_id character varying NOT NULL,
    metal character varying(10),
    buy double precision,
    sell double precision,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone
);


ALTER TABLE public.quotes OWNER TO postgres;

--
-- Name: sips; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sips (
    id character varying NOT NULL,
    customer_id character varying NOT NULL,
    jeweller_id character varying NOT NULL,
    amount double precision,
    frequency character varying(10),
    status character varying(20),
    installments integer,
    grams_accumulated double precision,
    next_run timestamp with time zone,
    created_at timestamp with time zone,
    metal character varying(10) DEFAULT 'gold'::character varying
);


ALTER TABLE public.sips OWNER TO postgres;

--
-- Name: transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.transactions (
    id character varying NOT NULL,
    invoice_no character varying(20) NOT NULL,
    customer_id character varying NOT NULL,
    jeweller_id character varying NOT NULL,
    type character varying(30) NOT NULL,
    metal character varying(10),
    grams double precision,
    rate double precision,
    amount double precision,
    gst double precision,
    total double precision,
    method character varying(30),
    status character varying(20),
    note text,
    extra json,
    pool_contribution boolean,
    created_at timestamp with time zone
);


ALTER TABLE public.transactions OWNER TO postgres;

--
-- Name: uploads; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.uploads (
    id character varying NOT NULL,
    owner character varying(80),
    path text NOT NULL,
    content_type character varying(80),
    size integer,
    created_at timestamp with time zone
);


ALTER TABLE public.uploads OWNER TO postgres;

--
-- Name: wallet_transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.wallet_transactions (
    id character varying NOT NULL,
    customer_id character varying NOT NULL,
    type character varying(20) NOT NULL,
    amount double precision,
    description text,
    created_at timestamp with time zone
);


ALTER TABLE public.wallet_transactions OWNER TO postgres;

--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alembic_version (version_num) FROM stdin;
7a1c2e9b4d10
\.


--
-- Data for Name: alerts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alerts (id, customer_id, jeweller_id, target, metal, alert_type, buy_amount, status, triggered_at, triggered_price, created_at) FROM stdin;
\.


--
-- Data for Name: app_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.app_settings (key, value) FROM stdin;
last_live_rates	{"g": 13848.5, "gp": 13841.9, "s": 179.132, "sp": 178.9, "at": "2026-10-31T15:46:43.423808+00:00"}
platform_controls	{"global": {"rates": true, "booking": true, "min_investment": 500.0}, "shops": {}}
referral_reward:demo-jeweller-001	50.0
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_logs (id, actor_type, actor_id, actor_name, jeweller_id, action, target, detail, created_at) FROM stdin;
64a42e99-d3a2-459d-91b1-faf72411c5a9	jeweller	demo-jeweller-001	Sharma Gold & Jewellers	demo-jeweller-001	product.making	Minimalist Gold Bangle	{"making_pct": 9.0}	2026-10-29 17:31:34.084496+00
2cb159c4-f253-4ae2-83b2-044c3d95fe3d	jeweller	demo-jeweller-001	Sharma Gold & Jewellers	demo-jeweller-001	commission.update	Sharma Gold & Jewellers	{"gold": 200.0, "silver": 0.0}	2026-10-29 17:33:43.836795+00
21070924-84b7-4826-8632-d66ceb79b7be	jeweller	demo-jeweller-001	Sharma Gold & Jewellers	demo-jeweller-001	commission.update	Sharma Gold & Jewellers	{"gold": 100.0, "silver": 0.0}	2026-10-29 18:02:05.16065+00
913616bb-d2cf-49f9-872e-9f1f6ae716dd	jeweller	demo-jeweller-001	Sharma Gold & Jewellers	demo-jeweller-001	product.making	Minimalist Gold Bangle	{"making_pct": 14.0}	2026-10-29 18:26:15.655662+00
6f76d498-2f76-434e-8c48-396fa6ba8555	jeweller	demo-jeweller-001	Sharma Gold & Jewellers	demo-jeweller-001	product.making	Minimalist Gold Bangle	{"making_pct": 22.0}	2026-10-29 18:26:43.661846+00
2877a412-ac68-4d9f-95c5-8fd1de21165b	jeweller	demo-jeweller-001	Sharma Gold & Jewellers	demo-jeweller-001	product.making	Minimalist Gold Bangle	{"making_pct": 24.0}	2026-10-29 18:27:14.385456+00
dd1610ff-126a-4361-94f7-a47cbd5aaff2	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-002	app.update	Patel Jewellery House	{"app_name": "Patel Gold", "bundle_id": "in.pateljewelleryhouse.gold", "theme": "emerald_heritage"}	2026-10-31 09:27:21.768554+00
27dce5d9-9198-47b9-be5c-72c9c8fc0168	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-002	app.kit_export	Patel Jewellery House	{"bundle_id": "in.pateljewelleryhouse.gold"}	2026-10-31 09:27:22.316106+00
a1edfd57-7bbb-41c5-b0af-aadab6d39437	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-002	pricing.update	Patel Jewellery House	{"gold_per_g": -25.0, "silver_per_g": -2.0, "gold22_per_g": -40.5, "gold18_per_g": 33.0}	2026-10-31 09:33:46.573727+00
d90a7c8d-c13e-4abc-a8b1-8db43073841f	jeweller	demo-jeweller-002	Patel Jewellery House	demo-jeweller-002	commission.update	Patel Jewellery House	{"gold": 10.0, "silver": 1.0}	2026-10-31 09:33:47.232252+00
34f60684-eec4-43e3-a674-8bcb441b02fc	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-002	app.update	Patel Jewellery House	{"app_name": "Patel Gold", "bundle_id": "patel.gold.app", "theme": "emerald_heritage"}	2026-10-31 09:33:48.591145+00
5d8fa242-78d2-4ab4-90ef-69b53efd0944	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-001	app.update	Sharma Gold & Jewellers	{"app_name": "Sharma Gold", "bundle_id": "in.pateljewelleryhouse.gold", "theme": "emerald_heritage"}	2026-10-31 09:33:48.692636+00
0e1a452c-f915-4441-9324-88c2169c913e	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-002	app.kit_export	Patel Jewellery House	{"bundle_id": "patel.gold.app"}	2026-10-31 09:33:49.400656+00
d0b384d0-d30d-475d-8a62-fb504a3e9c99	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-001	app.kit_export	Sharma Gold & Jewellers	{"bundle_id": "in.pateljewelleryhouse.gold"}	2026-10-31 09:33:49.987387+00
dfcd5440-f028-464b-93b3-1f56485d2b17	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-002	app.status	Patel Jewellery House	{"status": "theme_selected"}	2026-10-31 09:33:50.487647+00
e1cf25b9-e9dc-465b-b956-a9fe03cda243	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-001	pricing.update	Sharma Gold & Jewellers	{"gold_per_g": 100.0, "silver_per_g": 0.0, "gold22_per_g": 0.0, "gold18_per_g": 0.0}	2026-10-31 09:33:50.56951+00
d6b9aa62-9e06-4298-8e7c-96338ae1ddee	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-002	pricing.update	Patel Jewellery House	{"gold_per_g": 0.0, "silver_per_g": 0.0, "gold22_per_g": 0.0, "gold18_per_g": 0.0}	2026-10-31 09:33:50.640652+00
d6078b71-72d1-49ce-9b97-e749fc2f8fee	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-002	pricing.update	Patel Jewellery House	{"gold_per_g": -25.0, "silver_per_g": -2.0, "gold22_per_g": -40.5, "gold18_per_g": 33.0}	2026-10-31 09:34:24.90021+00
ad1f0a92-817b-44b0-a248-063af9d5013c	jeweller	demo-jeweller-002	Patel Jewellery House	demo-jeweller-002	commission.update	Patel Jewellery House	{"gold": 10.0, "silver": 1.0}	2026-10-31 09:34:25.493784+00
23a31cad-9841-4981-84c8-a16b40683c5c	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-002	app.update	Patel Jewellery House	{"app_name": "Patel Gold", "bundle_id": "in.pateljewelleryhouse.gold", "theme": "emerald_heritage"}	2026-10-31 09:34:27.25935+00
dde79c1b-df90-4bcb-bfc1-04477ad4ca04	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-002	app.update	Patel Jewellery House	{"app_name": "Patel Gold", "bundle_id": "in.pateljewelleryhouse.gold", "theme": "emerald_heritage"}	2026-10-31 09:34:27.731984+00
1ffc89df-2610-44f1-9368-214843e06251	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-002	app.status	Patel Jewellery House	{"status": "built"}	2026-10-31 09:34:27.798755+00
22bb6a34-626a-48a0-b919-96a18f090db2	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-002	app.kit_export	Patel Jewellery House	{"bundle_id": "in.pateljewelleryhouse.gold"}	2026-10-31 09:34:28.480615+00
b3793912-f511-419d-a9fe-557d91253485	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-002	app.update	Patel Jewellery House	{"app_name": "Patel Gold", "bundle_id": "in.pateljewelleryhouse.gold", "theme": "emerald_heritage"}	2026-10-31 09:34:28.960648+00
ab7ccd66-f984-4fa9-a06f-3208d5b26fee	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-002	app.status	Patel Jewellery House	{"status": "theme_selected"}	2026-10-31 09:34:29.025954+00
a64e6901-d82d-48d5-ae0c-23cb23d0aa55	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-001	pricing.update	Sharma Gold & Jewellers	{"gold_per_g": 100.0, "silver_per_g": 0.0, "gold22_per_g": 0.0, "gold18_per_g": 0.0}	2026-10-31 09:34:29.091175+00
51eee844-9d30-4647-9606-4c40b44a5867	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-002	pricing.update	Patel Jewellery House	{"gold_per_g": 0.0, "silver_per_g": 0.0, "gold22_per_g": 0.0, "gold18_per_g": 0.0}	2026-10-31 09:34:29.154767+00
d874f3e2-14c8-4d34-90da-5c155e1a3737	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-002	app.kit_export	Patel Jewellery House	{"bundle_id": "in.pateljewelleryhouse.gold"}	2026-10-31 09:34:39.42887+00
b71c23ad-5582-4e4d-a02e-073acc218992	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-002	app.update	Patel Jewellery House	{"app_name": "Patel Test App", "bundle_id": "in.pateljewelleryhouse.gold", "theme": "ivory_classic"}	2026-10-31 09:37:35.008839+00
e4c267db-9b3a-483f-ad82-286c01047660	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-002	app.kit_export	Patel Jewellery House	{"bundle_id": "in.pateljewelleryhouse.gold"}	2026-10-31 09:37:38.36173+00
5176797d-11d2-41b7-aef2-8fca784c0a7f	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-002	app.status	Patel Jewellery House	{"status": "built"}	2026-10-31 09:37:38.518135+00
839ec24f-60b0-4fbb-ba08-75496f4738e9	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-002	pricing.update	Patel Jewellery House	{"gold_per_g": 0.0, "silver_per_g": 0.0, "gold22_per_g": -12.0, "gold18_per_g": 7.5}	2026-10-31 09:37:40.656118+00
49b636cb-63f2-425f-aaa7-dde114015346	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-002	pricing.update	Patel Jewellery House	{"gold_per_g": 0.0, "silver_per_g": 0.0, "gold22_per_g": 0.0, "gold18_per_g": 0.0}	2026-10-31 09:37:53.221952+00
0c329890-5f3c-4ccd-88b8-6d7a1b11febb	jeweller	demo-jeweller-001	Sharma Gold & Jewellers	demo-jeweller-001	commission.update	Sharma Gold & Jewellers	{"gold": 100.0, "silver": 0.0}	2026-10-31 09:38:14.124134+00
9c43b18c-1f75-45a6-a0e9-3815a728de71	jeweller	demo-jeweller-001	Sharma Gold & Jewellers	demo-jeweller-001	commission.update	Sharma Gold & Jewellers	{"gold": 100.0, "silver": 0.0}	2026-10-31 09:38:16.787477+00
f28d386b-7b44-4dda-a457-e58127480a86	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-002	app.kit_export	Patel Jewellery House	{"bundle_id": "in.pateljewelleryhouse.gold"}	2026-10-31 10:14:07.924031+00
71046bcb-4a5d-48cf-ac71-85f302e41ff0	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-002	app.kit_export	Patel Jewellery House	{"bundle_id": "in.pateljewelleryhouse.gold"}	2026-10-31 10:15:02.404539+00
f1b4be80-4735-4f1f-8dbf-00dd44569900	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-002	app.kit_export	Patel Jewellery House	{"bundle_id": "in.pateljewelleryhouse.gold"}	2026-10-31 10:15:57.290804+00
ae7d9ef9-64ab-4bcf-9957-1832eae29081	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-002	app.update	Patel Jewellery House	{"app_name": "Patel Gold", "bundle_id": "in.pateljewelleryhouse.gold", "theme": "emerald_heritage"}	2026-10-31 10:15:57.623045+00
269b5251-5cc6-4b56-baf2-64317774cf10	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-002	app.update	Patel Jewellery House	{"app_name": "Patel Gold", "bundle_id": "in.pateljewelleryhouse.gold", "theme": "emerald_heritage"}	2026-10-31 10:15:57.790953+00
a151dc09-90c9-4723-8ee9-4f341e52de41	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-002	app.update	Patel Jewellery House	{"app_name": "Patel Gold", "bundle_id": "in.pateljewelleryhouse.gold", "theme": "emerald_heritage"}	2026-10-31 10:15:57.953625+00
65fb176a-07c0-4b6c-827c-99088b9ab121	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-002	app.status	Patel Jewellery House	{"status": "built"}	2026-10-31 10:15:58.078001+00
bf18caa6-0e74-4ea9-a53a-e41cbc54ba4b	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-002	app.update	Patel Jewellery House	{"app_name": "Patel Gold", "bundle_id": "in.pateljewelleryhouse.gold", "theme": "emerald_heritage"}	2026-10-31 10:15:58.224824+00
884ded72-efe7-46d0-98d8-27e07559d7be	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-002	app.update	Patel Jewellery House	{"app_name": "Patel Gold", "bundle_id": "in.pateljewelleryhouse.gold", "theme": "emerald_heritage"}	2026-10-31 10:15:58.350663+00
b6d6ee76-bb6e-4875-b231-d3ef937ff5a5	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-002	app.update	Patel Jewellery House	{"app_name": "Patel Gold", "bundle_id": "in.pateljewelleryhouse.gold", "theme": "emerald_heritage"}	2026-10-31 10:18:54.652508+00
972a6307-2cf2-4082-bd4a-d52be0476834	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-002	app.kit_export	Patel Jewellery House	{"bundle_id": "in.pateljewelleryhouse.gold"}	2026-10-31 10:18:55.144357+00
e60fbe0e-3077-4d31-b048-b94d3012fc57	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-002	app.status	Patel Jewellery House	{"status": "config_ready"}	2026-10-31 12:06:30.119575+00
73ec914f-3f06-4b60-a541-84d7b0d6d090	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-002	app.status	Patel Jewellery House	{"status": "built"}	2026-10-31 12:06:32.304257+00
0a840802-e289-4722-a20e-f5f8e636e2da	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-002	app.status	Patel Jewellery House	{"status": "submitted"}	2026-10-31 12:06:34.774735+00
d0c2bed0-b51b-4c9a-bbd2-7471e5caa57a	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-002	app.status	Patel Jewellery House	{"status": "live"}	2026-10-31 12:06:36.747285+00
39f8ba0b-388e-4190-aaab-15ecc73d042a	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-002	app.update	Patel Jewellery House	{"app_name": "Patel Gold", "bundle_id": "in.pateljewelleryhouse.gold", "theme": "emerald_heritage"}	2026-10-31 12:06:41.150658+00
9ebceebc-8e7b-465e-aec5-031f85d7f63a	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-002	app.kit_export	Patel Jewellery House	{"bundle_id": "in.pateljewelleryhouse.gold"}	2026-10-31 12:06:41.925496+00
be7ebf51-4e18-4f10-a221-c0e0309c8754	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": false, "booking": true, "min_investment": 500.0}, "shops": {}}	2026-10-31 15:20:49.622424+00
b3c46336-7bb7-49aa-b0f5-b92e1ced2347	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": true, "booking": true, "min_investment": 500.0}, "shops": {}}	2026-10-31 15:20:50.11876+00
47ff43dc-d8fe-4330-9dda-2dd8a9193681	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": true, "booking": true, "min_investment": 500.0}, "shops": {"demo-jeweller-002": {"rates": true, "booking": false}}}	2026-10-31 15:20:50.701334+00
3d08a598-d330-4efe-91d2-8167b315224c	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": true, "booking": true, "min_investment": 500.0}, "shops": {}}	2026-10-31 15:20:51.480692+00
36e60065-c92e-4b8a-947a-86376b7efaa6	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": true, "booking": true, "min_investment": 1000.0}, "shops": {}}	2026-10-31 15:20:51.757249+00
589bc66e-b676-417b-9b1f-f1bc8bec0657	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": true, "booking": true, "min_investment": 500.0}, "shops": {}}	2026-10-31 15:20:52.311646+00
684537da-eaff-4f6f-934e-e74b29a3a635	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": true, "booking": true, "min_investment": 500.0}, "shops": {}}	2026-10-31 15:20:54.378148+00
6868b341-55f7-4b3f-b79e-5a8a6928a509	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": false, "booking": true, "min_investment": 500.0}, "shops": {}}	2026-10-31 15:21:12.709405+00
2f31bde3-dc7f-4507-9a08-b49de7ea31bb	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": true, "booking": true, "min_investment": 500.0}, "shops": {}}	2026-10-31 15:21:13.097375+00
169a2c9e-a56a-4e93-95c2-cde0dba6c3ce	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": true, "booking": true, "min_investment": 500.0}, "shops": {"demo-jeweller-002": {"rates": true, "booking": false}}}	2026-10-31 15:21:13.653174+00
421622cd-30ad-4ba5-bc0a-f21479b10690	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": true, "booking": true, "min_investment": 500.0}, "shops": {}}	2026-10-31 15:21:14.394787+00
c4fbc972-1e5b-45d5-8538-72b72879ae1b	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": true, "booking": true, "min_investment": 1000.0}, "shops": {}}	2026-10-31 15:21:14.652698+00
1cb00553-dcdc-48cf-a1d4-2fd961b1355a	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": false, "booking": true, "min_investment": 500.0}, "shops": {"demo-jeweller-001": {"rates": true, "booking": true}, "demo-jeweller-002": {"rates": true, "booking": true}, "b8a020fb-7073-48d2-a800-d7f3bef9a213": {"rates": true, "booking": true}}}	2026-10-31 15:24:53.380442+00
e13d9131-f040-45aa-b11a-aa9ee783053e	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": true, "booking": true, "min_investment": 500.0}, "shops": {}}	2026-10-31 15:26:05.863396+00
b8bd4b5e-70d8-4ad8-a322-def449af2582	jeweller	demo-jeweller-002	Patel Jewellery House	demo-jeweller-002	commission.update	Patel Jewellery House	{"gold": 10.0, "silver": 1.0}	2026-10-31 15:26:46.712249+00
7bbf978d-6fa3-4251-a14d-eae2c7cef015	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-002	app.update	Patel Jewellery House	{"app_name": "Patel Gold", "bundle_id": "in.pateljewelleryhouse.gold", "theme": "emerald_heritage"}	2026-10-31 15:26:48.976179+00
0f73846c-90bc-4976-96e9-d42489226a16	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-002	app.status	Patel Jewellery House	{"status": "built"}	2026-10-31 15:26:49.630173+00
b4262b82-aff7-400e-aa55-55577dca7364	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-002	app.status	Patel Jewellery House	{"status": "theme_selected"}	2026-10-31 15:26:51.050781+00
42e0dbad-a894-4d1e-9a5f-1408280ea5ce	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": true, "booking": true, "min_investment": 500.0}, "shops": {}}	2026-10-31 15:21:15.314872+00
428d378e-26f2-44ba-8995-1a2dc7f770dc	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": true, "booking": true, "min_investment": 500.0}, "shops": {}}	2026-10-31 15:21:18.929506+00
8fe3d612-ee8d-4abf-a5d3-f426ea87a2ad	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-002	pricing.update	Patel Jewellery House	{"gold_per_g": -25.0, "silver_per_g": -2.0, "gold22_per_g": -40.5, "gold18_per_g": 33.0}	2026-10-31 15:26:45.976829+00
458c5532-6ed5-4558-9113-0ad07081c15c	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-002	app.update	Patel Jewellery House	{"app_name": "Patel Gold", "bundle_id": "in.pateljewelleryhouse.gold", "theme": "emerald_heritage"}	2026-10-31 15:26:49.55885+00
a7bbce68-fb25-484b-8f47-59b60e18e736	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-002	app.kit_export	Patel Jewellery House	{"bundle_id": "in.pateljewelleryhouse.gold"}	2026-10-31 15:26:50.230975+00
1fc99ffc-371b-4667-b3f8-a038d7d6bbd0	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-002	app.update	Patel Jewellery House	{"app_name": "Patel Gold", "bundle_id": "in.pateljewelleryhouse.gold", "theme": "emerald_heritage"}	2026-10-31 15:26:50.976575+00
b9d8db74-bae7-4993-a6f0-412db8269af8	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-001	pricing.update	Sharma Gold & Jewellers	{"gold_per_g": 100.0, "silver_per_g": 0.0, "gold22_per_g": 0.0, "gold18_per_g": 0.0}	2026-10-31 15:26:51.119995+00
38738c24-c4ff-4f59-a3fe-0cdca3afad90	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	demo-jeweller-002	pricing.update	Patel Jewellery House	{"gold_per_g": 0.0, "silver_per_g": 0.0, "gold22_per_g": 0.0, "gold18_per_g": 0.0}	2026-10-31 15:26:51.190651+00
eb24d98e-093c-4a5e-b999-738cbfd7af6b	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": false, "booking": true, "min_investment": 500.0}, "shops": {}}	2026-10-31 15:29:44.893016+00
4e7281c5-fbf7-4a3b-b146-543422938cdc	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": true, "booking": true, "min_investment": 500.0}, "shops": {}}	2026-10-31 15:29:45.746496+00
5d2da0a5-d1e1-4160-8d83-04fc84cc5975	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": true, "booking": true, "min_investment": 500.0}, "shops": {"demo-jeweller-002": {"rates": false, "booking": true}}}	2026-10-31 15:29:46.220014+00
c930484c-8aa0-47c8-93ef-3b177fbdbc31	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": true, "booking": true, "min_investment": 500.0}, "shops": {}}	2026-10-31 15:29:46.620174+00
7b8b8d1b-e944-47df-9d7c-bb6eeff0c16d	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": false, "booking": true, "min_investment": 500.0}, "shops": {}}	2026-10-31 15:29:47.315674+00
f69d756b-b9a8-4ef3-b669-0e5058aa8527	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": true, "booking": true, "min_investment": 500.0}, "shops": {}}	2026-10-31 15:29:47.722324+00
86a2cf7f-9ff4-48b3-8ef5-4316383b98a2	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": true, "booking": true, "min_investment": 500.0}, "shops": {"demo-jeweller-002": {"rates": true, "booking": false}}}	2026-10-31 15:29:48.26195+00
2be1494d-5603-44fa-9c88-f2c896e34632	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": true, "booking": true, "min_investment": 500.0}, "shops": {}}	2026-10-31 15:29:49.210394+00
9aa34bc5-0cc1-4918-8f7c-6e09909bcdf7	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": true, "booking": true, "min_investment": 1000.0}, "shops": {}}	2026-10-31 15:29:49.482432+00
76348d82-460c-4754-8099-c53fcb1b2377	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": true, "booking": true, "min_investment": 500.0}, "shops": {}}	2026-10-31 15:29:50.020648+00
53b4ecf8-da69-484d-9437-40562f97c6dd	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": true, "booking": true, "min_investment": 500.0}, "shops": {}}	2026-10-31 15:29:50.216705+00
ca4a0c1c-ae42-4c8d-9180-b0c2b603740e	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": true, "booking": true, "min_investment": 500.0}, "shops": {}}	2026-10-31 15:29:53.277969+00
b5b4c905-83fc-4704-9d96-81f0cf7fcfba	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": false, "booking": true, "min_investment": 500.0}, "shops": {}}	2026-10-31 15:29:59.196996+00
c53f2b80-326c-4241-98b7-7634f2bfc1ae	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": true, "booking": true, "min_investment": 500.0}, "shops": {}}	2026-10-31 15:29:59.566433+00
8ce4f64c-db93-4dfb-86da-cd27f034cfe1	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": true, "booking": true, "min_investment": 500.0}, "shops": {"demo-jeweller-002": {"rates": false, "booking": true}}}	2026-10-31 15:29:59.812168+00
6e69d8b8-9b3e-4a73-9b75-669a80665bc3	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": true, "booking": true, "min_investment": 500.0}, "shops": {}}	2026-10-31 15:30:00.184168+00
1d1c53fe-17fe-42ce-afa3-968d08456f5a	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": true, "booking": true, "min_investment": 500.0}, "shops": {}}	2026-10-31 15:30:02.44499+00
0624e64e-84da-4f06-af73-39429ef95434	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": false, "booking": true, "min_investment": 500.0}, "shops": {}}	2026-10-31 15:31:13.791912+00
1a064835-f300-4a61-a859-9b6ed947c84f	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": true, "booking": true, "min_investment": 500.0}, "shops": {}}	2026-10-31 15:31:14.190691+00
ae1282a9-bcc9-4166-a29f-f38ad434a0d7	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": true, "booking": true, "min_investment": 500.0}, "shops": {"demo-jeweller-002": {"rates": true, "booking": false}}}	2026-10-31 15:31:14.734637+00
751c9f2a-8472-4d12-81e7-cef4af625fcf	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": true, "booking": true, "min_investment": 500.0}, "shops": {}}	2026-10-31 15:31:15.491541+00
d790c5e3-942d-4f04-a50a-cf0d58aa1f7a	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": true, "booking": true, "min_investment": 1000.0}, "shops": {}}	2026-10-31 15:31:15.749419+00
809deb7c-4bda-435f-ad3b-abb85dc5ad6d	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": true, "booking": true, "min_investment": 500.0}, "shops": {}}	2026-10-31 15:31:16.245806+00
f41c22f2-6d33-4130-b2cc-b4281680aa5c	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": true, "booking": true, "min_investment": 500.0}, "shops": {}}	2026-10-31 15:31:20.569843+00
6dfe94a0-1c0c-4d73-8c24-b64dcedefdaa	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": true, "booking": true, "min_investment": 500.0}, "shops": {}}	2026-10-31 15:31:27.926003+00
6eeb297a-ac82-4ca5-888b-fa35c339cad6	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": true, "booking": true, "min_investment": 500.0}, "shops": {}}	2026-10-31 15:31:36.344595+00
9ba94618-7688-4e8f-b701-02ab751d8cd6	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": true, "booking": true, "min_investment": 500.0}, "shops": {}}	2026-10-31 15:31:43.924623+00
80c2f40a-e417-4299-8889-1d103be8e975	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": true, "booking": true, "min_investment": 500.0}, "shops": {}}	2026-10-31 15:31:51.701691+00
5e484ed1-2bda-4aef-b9a6-762473bfd230	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": true, "booking": true, "min_investment": 500.0}, "shops": {}}	2026-10-31 15:31:52.572005+00
268a834b-4d51-45e0-8a42-92b8a3a9dd45	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": false, "booking": true, "min_investment": 500.0}, "shops": {}}	2026-10-31 15:33:34.883857+00
a9a145e5-8b7a-4f04-af2f-fd1e162d83fc	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": true, "booking": false, "min_investment": 500.0}, "shops": {}}	2026-10-31 15:34:09.81745+00
95c00542-adfb-4eae-a83d-964c723ac3ca	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": true, "booking": true, "min_investment": 500.0}, "shops": {}}	2026-10-31 15:34:26.476115+00
57f12f11-4ac4-4e17-8d60-db651affa98c	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": true, "booking": true, "min_investment": 500.0}, "shops": {}}	2026-10-31 15:37:03.639702+00
1a45ac75-f900-4d7c-a342-37a1170e3a33	master	97effbae-d8c9-4c54-ba50-fae1d757cd34	Vaultra Super Admin	\N	controls.update	platform	{"global": {"rates": true, "booking": true, "min_investment": 500.0}, "shops": {}}	2026-10-31 15:37:04.249395+00
\.


--
-- Data for Name: banners; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.banners (id, jeweller_id, title, subtitle, eyebrow, image_url, link, sort, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: bifurcation_invoices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bifurcation_invoices (id, pool_id, total_grams, details, status, created_at) FROM stdin;
9449bdbe-b291-4f72-b512-dc390afc90e9	99ad57ba-3279-4b85-a7df-38285e0bbc11	15.308	[{"jeweller_id": "demo-jeweller-001", "jeweller_name": "Sharma Gold & Jewellers", "customer_id": "a44a44be-7a5d-4dfc-9b40-bf8a46e44bb7", "customer_name": "Aarav Sharma", "grams": 0.6912}, {"jeweller_id": "demo-jeweller-001", "jeweller_name": "Sharma Gold & Jewellers", "customer_id": "a44a44be-7a5d-4dfc-9b40-bf8a46e44bb7", "customer_name": "Aarav Sharma", "grams": 0.1398}, {"jeweller_id": "demo-jeweller-001", "jeweller_name": "Sharma Gold & Jewellers", "customer_id": "a44a44be-7a5d-4dfc-9b40-bf8a46e44bb7", "customer_name": "Aarav Sharma", "grams": 0.3489}, {"jeweller_id": "demo-jeweller-001", "jeweller_name": "Sharma Gold & Jewellers", "customer_id": "a44a44be-7a5d-4dfc-9b40-bf8a46e44bb7", "customer_name": "Aarav Sharma", "grams": 0.1412}, {"jeweller_id": "demo-jeweller-001", "jeweller_name": "Sharma Gold & Jewellers", "customer_id": "41d1e25d-a0b9-4aba-8eaf-f86db84c90e0", "customer_name": "Diya Patel", "grams": 0.2818}, {"jeweller_id": "demo-jeweller-001", "jeweller_name": "Sharma Gold & Jewellers", "customer_id": "41d1e25d-a0b9-4aba-8eaf-f86db84c90e0", "customer_name": "Diya Patel", "grams": 0.6926}, {"jeweller_id": "demo-jeweller-001", "jeweller_name": "Sharma Gold & Jewellers", "customer_id": "41d1e25d-a0b9-4aba-8eaf-f86db84c90e0", "customer_name": "Diya Patel", "grams": 0.2809}, {"jeweller_id": "demo-jeweller-001", "jeweller_name": "Sharma Gold & Jewellers", "customer_id": "41d1e25d-a0b9-4aba-8eaf-f86db84c90e0", "customer_name": "Diya Patel", "grams": 0.7066}, {"jeweller_id": "demo-jeweller-001", "jeweller_name": "Sharma Gold & Jewellers", "customer_id": "82db254e-16c1-447e-a5aa-dc4a74b47a8b", "customer_name": "Kabir Singh", "grams": 0.1383}, {"jeweller_id": "demo-jeweller-001", "jeweller_name": "Sharma Gold & Jewellers", "customer_id": "82db254e-16c1-447e-a5aa-dc4a74b47a8b", "customer_name": "Kabir Singh", "grams": 0.2772}, {"jeweller_id": "demo-jeweller-001", "jeweller_name": "Sharma Gold & Jewellers", "customer_id": "82db254e-16c1-447e-a5aa-dc4a74b47a8b", "customer_name": "Kabir Singh", "grams": 0.3506}, {"jeweller_id": "demo-jeweller-001", "jeweller_name": "Sharma Gold & Jewellers", "customer_id": "b37c10f7-5af1-4711-817b-b53849d7016c", "customer_name": "Meera Iyer", "grams": 0.2773}, {"jeweller_id": "demo-jeweller-001", "jeweller_name": "Sharma Gold & Jewellers", "customer_id": "b37c10f7-5af1-4711-817b-b53849d7016c", "customer_name": "Meera Iyer", "grams": 0.2811}, {"jeweller_id": "demo-jeweller-001", "jeweller_name": "Sharma Gold & Jewellers", "customer_id": "b37c10f7-5af1-4711-817b-b53849d7016c", "customer_name": "Meera Iyer", "grams": 0.7005}, {"jeweller_id": "demo-jeweller-001", "jeweller_name": "Sharma Gold & Jewellers", "customer_id": "2b6458cc-ad07-4062-b8d1-eabbc66c7432", "customer_name": "B", "grams": 10.0}]	generated	2026-10-31 12:29:46.17556+00
1cfc076b-7ae8-4941-b0d2-55c201ca042e	78fa2a24-780c-4e21-afab-a3e1456878d1	10	[{"jeweller_id": "demo-jeweller-001", "jeweller_name": "Sharma Gold & Jewellers", "customer_id": "2b6458cc-ad07-4062-b8d1-eabbc66c7432", "customer_name": "B", "grams": 10.0}]	generated	2026-10-31 12:30:31.623818+00
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customers (id, jeweller_id, phone, first_name, last_name, email, dob, gender, wallet_id, gold_grams, silver_grams, invested, wallet_balance, referral_code, referral_balance, referred_by, kyc_status, kyc_data, status, created_at, updated_at) FROM stdin;
41d1e25d-a0b9-4aba-8eaf-f86db84c90e0	demo-jeweller-001	9812345670	Diya	Patel				VW9BA41C99	1.9619	0	14000	0	VDG4F90B	0	\N	pending	{"full_name": "Diya Patel", "aadhaar": "953512406178", "pan": "EAKEH5991B", "dob": "1989-06-24", "submitted_at": "2026-10-29T17:20:10.289542+00:00"}	active	2026-09-21 17:20:10.2811+00	2026-10-29 17:20:10.291866+00
82db254e-16c1-447e-a5aa-dc4a74b47a8b	demo-jeweller-001	9823456781	Kabir	Singh				VW26A58F6A	0.7661	0	5500	0	VDGF55C9	0	\N	not_submitted	{}	active	2026-09-24 17:20:10.2811+00	2026-10-29 17:20:10.294284+00
b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	9834567892	Meera	Iyer				VWBA53DDA3	1.4405	0	20073.5	0	VDG66C84	0	\N	approved	{"full_name": "Meera Iyer", "aadhaar": "967639474945", "pan": "CEKAD3863L", "dob": "1995-06-20", "submitted_at": "2026-10-29T17:20:10.295151+00:00", "reviewed_by": "Rajesh Sharma", "reviewed_at": "2026-10-29T17:20:10.295157+00:00"}	active	2026-09-08 17:20:10.2811+00	2026-10-31 15:37:02.323779+00
222e4eab-ca73-4416-aa7b-2178a2f4bfa5	demo-jeweller-002	9845678903	Rohan	Gupta				VW6B3C665E	3.497	0	14039.32	0	VDG2F7A9	0	\N	approved	{"full_name": "Rohan Gupta", "aadhaar": "365029128486", "pan": "ABCDE9553F", "submitted_at": "2026-10-29T17:20:10.297107+00:00", "reviewed_by": "Amit Patel", "reviewed_at": "2026-10-29T17:20:10.297113+00:00"}	active	2026-09-30 17:20:10.2811+00	2026-10-29 17:20:10.297841+00
da1f8f82-7646-4c0d-97e3-866fb9ad3c9c	demo-jeweller-002	9856789014	Ananya	Reddy				VWA7808BF8	1.6018	0	25200.2	0	VDG5240C	0	\N	pending	{"full_name": "Ananya Reddy", "aadhaar": "284623663928", "pan": "ABCDE4150F", "submitted_at": "2026-10-29T17:20:10.297179+00:00"}	active	2026-09-24 17:20:10.2811+00	2026-10-29 17:20:10.297843+00
2b6458cc-ad07-4062-b8d1-eabbc66c7432	demo-jeweller-001	7016672614	B					VWE2A7C06B	20	0	278970	0	VDG4BA4E	0	\N	not_submitted	{}	active	2026-10-29 17:45:40.617643+00	2026-10-31 12:30:31.618117+00
a44a44be-7a5d-4dfc-9b40-bf8a46e44bb7	demo-jeweller-001	9876543210	Aarav	Sharma				VWF7DB64F3	0.4563	0	3574.52	0	VDGB174B	0	\N	approved	{"full_name": "Aarav Sharma", "aadhaar": "265406846313", "pan": "BLABK2581H", "dob": "1999-03-27", "submitted_at": "2026-10-29T17:20:10.281124+00:00", "reviewed_by": "Rajesh Sharma", "reviewed_at": "2026-10-29T17:20:10.281131+00:00"}	active	2026-09-30 17:20:10.2811+00	2026-10-31 15:35:46.20517+00
\.


--
-- Data for Name: faqs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.faqs (id, jeweller_id, question, answer, sort, created_at) FROM stdin;
\.


--
-- Data for Name: gifts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gifts (id, sender_id, recipient_id, jeweller_id, grams, rate, amount, theme, message, seen, created_at) FROM stdin;
\.


--
-- Data for Name: goals; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.goals (id, customer_id, name, occasion, target_grams, months, deadline, start_grams, created_at, metal) FROM stdin;
\.


--
-- Data for Name: jewellers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.jewellers (id, business_name, owner_name, phone, email, password_hash, pan, aadhaar, address, city, state, pincode, logo_url, primary_color, secondary_color, domain, admin_domain, gold_buy_markup_pct, gold_sell_discount_pct, silver_buy_markup_pct, silver_sell_discount_pct, gold_commission_per_g, silver_commission_per_g, min_redemption_grams, status, created_at, updated_at, gold22_commission_per_g, gold18_commission_per_g, app_name, bundle_id, theme_preset, splash_url, app_status, app_version, store_short, store_long, store_keywords, support_email) FROM stdin;
demo-jeweller-001	Sharma Gold & Jewellers	Rajesh Sharma	9999000001	sharma@vaultra.in	$2b$12$MMeli6cE/4bhMIQR6.d7kOApimrxLfqVhpA62YguIQcBJi5qhZA.m			Shop No. 12, Gold Market	Mumbai	Maharashtra	400001		#D4AF37	#1A1A2E			0	3	0	3	100	0	1	active	2026-10-29 17:20:10.27839+00	2026-10-31 09:38:16.787978+00	0	0					details_pending	1.0.0				
demo-jeweller-002	Patel Jewellery House	Amit Patel	9999000002	patel@vaultra.in	$2b$12$sa.F/YLYNGjih9jvHB8k0e6wyukgNtH6pnscBF3cPjoiVFuFl7Z2u			15, Jewellers Lane	Ahmedabad	Gujarat	380001		#B8860B	#2D2D44			0	3	0	3	0	0	0.5	active	2026-10-29 17:20:10.278397+00	2026-10-31 15:26:51.190949+00	0	0	Patel Gold	in.pateljewelleryhouse.gold	emerald_heritage		theme_selected	1.0.0	Buy 24K digital gold & silver from Patel Jewellery House starting ₹10.	Patel Gold is the official app of Patel Jewellery House in Ahmedabad.\n\n• Buy 24K 99.9% pure digital gold and 999 silver at live market rates\n• Every gram is backed by physical metal held in insured vaults\n• Start an Auto SIP from ₹100 and grow your savings in gold\n• Redeem as coins or jewellery at our store\n• Gift gold to family and friends in seconds\n• Live 24K, 22K and 18K rates for jewellery shopping\n• Secure OTP login, KYC verified and tax invoices for every purchase\n\nVisit Patel Jewellery House or contact us at 9999000002 for any help.	digital gold,gold savings,buy gold,gold SIP,silver,jewellery,patel jewellery house	patel@vaultra.in
b8a020fb-7073-48d2-a800-d7f3bef9a213	Digital Sense	kk	9992849995	admin	$2b$12$.BSJ.tiqzo2D7DoEDRv6MukJ6H9u2c9zXb2O0QTujzRdX130zyV3W				Ahmedabad	Gujarat			#b8892b	#1A1A2E			0	3	0	3	0	0	1	suspended	2026-10-31 12:07:34.80732+00	2026-10-31 12:08:21.367023+00	0	0					details_pending	1.0.0				
\.


--
-- Data for Name: master_admins; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.master_admins (id, username, password_hash, name, created_at) FROM stdin;
97effbae-d8c9-4c54-ba50-fae1d757cd34	admin	$2b$12$ZHLXtXTkFomLMfZsuiCp3OzMSfbiYyGx9h4olZQ7PNx5Io2X0/Pl.	Vaultra Super Admin	2026-10-29 17:20:10.280024+00
\.


--
-- Data for Name: mt5_bookings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mt5_bookings (id, metal, symbol, volume, grams, status, ticket, price, error, trigger, created_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications (id, customer_id, title, message, type, read, created_at) FROM stdin;
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (id, customer_id, jeweller_id, metal, grams, rate, amount, gst, total, status, provider, payment_id, method, paid_at, created_at) FROM stdin;
a658ad44-3027-40e9-ad2c-316ca3e6a36a	2b6458cc-ad07-4062-b8d1-eabbc66c7432	demo-jeweller-001	gold	10	13948.5	139485	4184.55	143669.55	paid	mock	pay_mock_9bdc622c8bf942	upi	2026-10-31 12:29:46.159299+00	2026-10-31 12:29:45.724636+00
0754ba93-002d-41b5-ac2b-750900df08c8	2b6458cc-ad07-4062-b8d1-eabbc66c7432	demo-jeweller-001	gold	10	13948.5	139485	4184.55	143669.55	paid	mock	pay_mock_056d7efea3c746	upi	2026-10-31 12:30:31.61766+00	2026-10-31 12:30:31.288794+00
c8657674-ef47-4efc-bc0f-d88054b0a31c	a44a44be-7a5d-4dfc-9b40-bf8a46e44bb7	demo-jeweller-001	gold	0.1008	13948.5	1406.5	43.5	1450	created	mock			\N	2026-10-31 15:19:01.085667+00
9358e6bc-0bbc-46d4-a917-6a0ea6a9c96b	a44a44be-7a5d-4dfc-9b40-bf8a46e44bb7	demo-jeweller-001	gold	0.1008	13948.5	1406.5	43.5	1450	created	mock			\N	2026-10-31 15:20:46.228083+00
926b0718-a990-4329-b396-77a51e3e4c97	a44a44be-7a5d-4dfc-9b40-bf8a46e44bb7	demo-jeweller-001	gold	0.0969	13948.5	1353	41.85	1394.85	created	mock			\N	2026-10-31 15:20:47.243954+00
1a645d02-4f66-466a-aebb-5306fdb06f08	a44a44be-7a5d-4dfc-9b40-bf8a46e44bb7	demo-jeweller-001	gold	0.1008	13948.5	1406.5	43.5	1450	created	mock			\N	2026-10-31 15:21:10.922683+00
97224681-dde2-4243-9fd5-37e0a174b7eb	a44a44be-7a5d-4dfc-9b40-bf8a46e44bb7	demo-jeweller-001	gold	0.0969	13948.5	1353	41.85	1394.85	created	mock			\N	2026-10-31 15:21:11.193263+00
bde6ac03-d075-4825-bff6-5392c9ceefc4	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	gold	1.1639	13948.5	16236.05	502.15	16738.2	paid	mock	pay_mock_eb967d70cf9f4f	upi	2026-10-31 15:21:16.583084+00	2026-10-31 15:21:16.456023+00
2a5172c6-796e-425e-a130-5090acc9a281	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	gold	0.0347	13948.5	485	15	500	paid	mock	pay_mock_4405c1b65ab84b	upi	2026-10-31 15:23:07.391766+00	2026-10-31 15:23:07.311805+00
703699a8-fa8e-4b7c-a5dc-e13e45d5040d	a44a44be-7a5d-4dfc-9b40-bf8a46e44bb7	demo-jeweller-001	gold	0.1008	13948.5	1406.5	43.5	1450	created	mock			\N	2026-10-31 15:29:50.084736+00
66e83a96-966f-425d-9e14-4b52ffd63e20	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	gold	1.1639	13948.5	16236.05	502.15	16738.2	paid	mock	pay_mock_bbf92e19bd1a48	upi	2026-10-31 15:29:51.309331+00	2026-10-31 15:29:51.16986+00
3337c0ef-3861-496e-924d-271c45cc9012	a44a44be-7a5d-4dfc-9b40-bf8a46e44bb7	demo-jeweller-001	gold	0.1008	13948.5	1406.5	43.5	1450	created	mock			\N	2026-10-31 15:30:02.314726+00
eacfce40-fb2e-47df-97df-e9bff23e4fab	a44a44be-7a5d-4dfc-9b40-bf8a46e44bb7	demo-jeweller-001	gold	0.1008	13948.5	1406.5	43.5	1450	created	mock			\N	2026-10-31 15:30:03.770038+00
291a5b3c-395f-4fa2-9fd8-bb8b5a24b5ac	a44a44be-7a5d-4dfc-9b40-bf8a46e44bb7	demo-jeweller-001	gold	0.0969	13948.5	1353	41.85	1394.85	created	mock			\N	2026-10-31 15:30:04.029746+00
a5076b62-b706-4d69-994d-ad1753114260	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	gold	1.1639	13948.5	16236.05	502.15	16738.2	paid	mock	pay_mock_7911eadf00a94d	upi	2026-10-31 15:31:18.619895+00	2026-10-31 15:31:18.497732+00
e9a2abe7-628f-4467-b9b7-c939df348139	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	gold	1.1639	13948.5	16236.05	502.15	16738.2	paid	mock	pay_mock_75f28e03fb3940	upi	2026-10-31 15:31:34.740521+00	2026-10-31 15:31:34.236295+00
bf88aa49-3a06-453e-83ee-b2a181c5096c	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	gold	1.1639	13948.5	16236.05	502.15	16738.2	paid	mock	pay_mock_a23981f2aee048	upi	2026-10-31 15:31:42.604785+00	2026-10-31 15:31:42.474718+00
a1640352-f0f1-4e44-81d3-2fb5d5e0ccb9	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	gold	1.1639	13948.5	16236.05	502.15	16738.2	paid	mock	pay_mock_d6d178e126054e	upi	2026-10-31 15:31:50.417592+00	2026-10-31 15:31:50.275489+00
56b9e3cc-947d-470a-8c0c-8d6114485f6a	a44a44be-7a5d-4dfc-9b40-bf8a46e44bb7	demo-jeweller-001	gold	0.1008	13948.5	1406.5	43.5	1450	paid	mock	pay_mock_972197797a0f49	upi	2026-10-31 15:33:01.476736+00	2026-10-31 15:33:01.392439+00
8c47661d-759d-447a-a44b-6fbb6da56455	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	gold	1.1639	13948.5	16236.05	502.15	16738.2	paid	mock	pay_mock_45ff23f1ecd44b	upi	2026-10-31 15:37:01.437632+00	2026-10-31 15:37:01.296155+00
\.


--
-- Data for Name: otp_challenges; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.otp_challenges (id, phone, jeweller_id, digest, attempts, used, created_at, expires_at) FROM stdin;
9c3760aa-ca0e-43d7-a1e2-81f32861f0f3	9876543210	demo-jeweller-001	30fa51be4d112b86a66da5e7f529a59fd923ecb9acc072e39514b8821c7d801e	0	t	2026-10-29 17:23:47.300205+00	2026-10-29 17:28:47.29925+00
d8c35d77-97f8-48fb-adcd-566af50e8a8c	9876543210	demo-jeweller-001	48261d72a2f8e5f7b077400bfa17c3956cd534171ed3808ca01eda9adc267c93	0	t	2026-10-29 17:23:48.027117+00	2026-10-29 17:28:48.02678+00
c8e811b9-c4c0-47fb-a152-b558e6363ecf	9876543210	demo-jeweller-001	c44172a90dda2ab274fd6b897638becf61143e428a7cd3fd33943926934363f1	0	t	2026-10-29 17:23:48.777942+00	2026-10-29 17:28:48.777654+00
30f85663-0a89-4723-b7ed-01ba5c69389b	9876543210	demo-jeweller-001	f070580ebd79f94ee1bfc8895e549b81cb45db12606e7e05608be9ae69e32b53	0	t	2026-10-29 17:25:20.993804+00	2026-10-29 17:30:20.992761+00
5f0d8b2c-e300-46ad-911f-0823286bc6a9	9876543210	demo-jeweller-001	91d132c3b9b50336a20bfacd5e74097b151dab78041facaea4714578b805353a	0	t	2026-10-29 17:25:21.05282+00	2026-10-29 17:30:21.05236+00
998abe10-3462-4700-9e11-8ea2be95f91d	9876543210	demo-jeweller-001	45d0403a03946bb4de78c154c6f7efbdede6a7bd62fa2d00d82ceb9652054d99	0	t	2026-10-29 17:27:18.825522+00	2026-10-29 17:32:18.825228+00
0adf8f19-d32d-4ffe-bf54-908c0f46155d	9876543210	demo-jeweller-001	aff83a924abe5e2380ee7988e51784e405a0cf50936cf21889827744ac920d2a	0	t	2026-10-29 17:27:39.537249+00	2026-10-29 17:32:39.536977+00
cf3a3e43-0379-4c68-95e9-f0830b2ecf77	9876543210	demo-jeweller-001	b3dd56beedd2eb123887ccb4c91725a1c4910fe96c7880cac3d57ed040da8404	0	t	2026-10-29 17:30:18.419283+00	2026-10-29 17:35:18.418293+00
0e3c9005-15b3-496b-8cef-1d630fae1549	9876543210	demo-jeweller-001	cf645157040f297a196c56628f386b9be33ca4c2ba58836ca8ca3246979309ec	0	t	2026-10-29 17:30:18.463294+00	2026-10-29 17:35:18.462987+00
ebaaf113-6b1b-45fe-8615-8d04b718cdfe	9876543210	demo-jeweller-001	cd36a4ca3de9c601db723b6c500eb46edc3482450bd13eda03dbd08ddac71607	0	t	2026-10-29 17:32:20.853788+00	2026-10-29 17:37:20.852981+00
192edac0-8707-4a6a-ac9f-ca211be56c20	9876543210	demo-jeweller-001	ffa2611b382c66c6d11c5c7cca67476d4905954d53edb1f55c47f40d0d8e4d75	0	t	2026-10-29 17:33:05.448279+00	2026-10-29 17:38:05.44718+00
fb9bab78-c880-4fa3-9b8f-ee7542888caf	9876543210	demo-jeweller-001	7de70d92832937880049e5e04ae4052dccd3b9a778359a7947304e8fbf9ec66e	0	t	2026-10-29 17:33:07.176729+00	2026-10-29 17:38:07.176439+00
659fff59-2135-4600-b217-b96e2953f471	9876543210	demo-jeweller-001	c85ef53cef0ad5ef2e894af679d2042edf9e40b8fef51c65c77eb87aca5bdac5	0	t	2026-10-29 17:33:07.489988+00	2026-10-29 17:38:07.489713+00
64598fac-dd00-4957-bd90-a788c31475b3	9876543210	demo-jeweller-001	7c2bd8ef2d7b52af389771036648ffff803c9dc409d37d86edad3fedf3308624	0	t	2026-10-29 17:33:14.868519+00	2026-10-29 17:38:14.868263+00
5b901c73-2e5d-4c2b-9e1f-b0aca9864086	9876543210	demo-jeweller-001	ced7192f2668ae10e068e73801718273286c285458f33a1abc555cbec99561c8	0	t	2026-10-29 17:33:32.201833+00	2026-10-29 17:38:32.200811+00
e1ad43d9-d4dd-44b0-90c8-fd455555653b	9876543210	demo-jeweller-001	63393c76570a95db003feef0ad7f1eda8845582dec6b5b1c43fc8cbf03116dea	0	t	2026-10-29 17:34:46.518738+00	2026-10-29 17:39:46.518257+00
a2d44e3d-bef0-4348-99b4-3983c447dc3c	7016672614	demo-jeweller-001	0eae3502f88f8e06e3e1516dc66a6282761ca9f729d248799ad19dee09b12090	0	t	2026-10-29 17:45:34.832682+00	2026-10-29 17:50:34.831568+00
fedcf681-2c4b-4fb0-b2a8-a9975ada3efc	9876543210	demo-jeweller-001	705ef7eddd7530b699e452fefe3ca1896d52255ccf1f6d7f00092b84c65c51a0	0	t	2026-10-31 09:33:47.374584+00	2026-10-31 09:38:47.373255+00
9e3f16df-b668-49c8-bd93-2135548f7897	9876543210	demo-jeweller-001	85b25dd98c1256b128ae4442f45bb944241c244d81b85a60db0fa7616b444c2c	0	t	2026-10-31 09:34:25.622143+00	2026-10-31 09:39:25.620905+00
f1ced213-a6db-49d8-85bc-eaa3436cc91d	9876543210	demo-jeweller-001	438412d855b5e57a665a546fd63e871b9d254929fa3e0f413c1a3c5bc84cd118	0	t	2026-10-31 09:36:14.874104+00	2026-10-31 09:41:14.873825+00
09cef9b2-b04d-40f9-abe1-61a6bf7fd308	9876543210	demo-jeweller-001	049e28a39d75e3e013fad2d6f321eed66bb06a66b6933cac6be66195c1ad84ee	0	t	2026-10-31 09:38:55.120845+00	2026-10-31 09:43:55.119747+00
696a3dcc-eb9e-4602-bd89-ed481b3eed01	9876543210	demo-jeweller-001	08a65272108418d71df155a8d72c115d8f30a6ab4e595d68e74932e9e23766dd	0	t	2026-10-31 09:39:12.972289+00	2026-10-31 09:44:12.971936+00
0fe6fbd7-7e18-4635-8d1d-cc5c730dbdec	9876543210	demo-jeweller-001	1a315414a04bb88d0861c0e4d018c44b2845977c8f49440e042cd6c0f4e34d23	0	t	2026-10-31 09:39:13.388724+00	2026-10-31 09:44:13.388358+00
05432993-67f3-45ae-a9ae-1286fc2c315d	9845678903	demo-jeweller-001	dd31d24fe1b936e7d5d8e62886f1539251c213f25f6a09fe995d8546a89bb16e	0	f	2026-10-31 10:17:17.490283+00	2026-10-31 10:22:17.489391+00
5d708e6b-b8f2-40b5-9422-e6319e0eb7ca	9845678903	demo-jeweller-001	ad91baa6cbc9970e95b7ea182e509033a978c1cfed67eb5bd2a76457653c4d3f	0	f	2026-10-31 10:17:48.558475+00	2026-10-31 10:22:48.558133+00
392d9773-372d-4338-88bd-5a35b2d9efe4	9845678903	demo-jeweller-001	e0102c9fddd6d9ccb512a1b9a16b22ed9a1e517273bfec9b5f884fe798c2f282	0	f	2026-10-31 10:17:48.689774+00	2026-10-31 10:22:48.689478+00
302e7488-de68-448c-9717-b77ef416c89c	9845678903	demo-jeweller-002	65e052981b67e397aeb10b0dfb04fd576a93ee142582f27b22443d3b82636eb2	0	f	2026-10-31 10:17:53.435705+00	2026-10-31 10:22:53.43537+00
d039e4ed-5361-45c2-b1d8-e79e75b2894d	9876543210	demo-jeweller-001	3015d491ded48a26a215207e4c145fb4fe6ff785071fa73c736f70d412890e6b	0	t	2026-10-31 10:18:12.240774+00	2026-10-31 10:23:12.240502+00
3351a8f3-1174-4bd3-a943-4ec7eec20b39	9845678903	demo-jeweller-002	ceaae004f68392527efec93578ad509e7dc2b70773d7a6e177aec872b4f2cea6	0	f	2026-10-31 10:20:15.666288+00	2026-10-31 10:25:15.665083+00
0a070192-050a-4677-8f36-e465f76fd73c	9845678903	demo-jeweller-002	f3540b94b8cc350592465312dc90ea9210d87275fc29a3ff71e0eabd9be63ef6	0	t	2026-10-31 10:21:05.855856+00	2026-10-31 10:26:05.854559+00
62d38878-b279-4786-a3b2-3b71d0f0de23	9876543210	demo-jeweller-001	262161e254cf1892cf83e4fa264ff3f57fd6a205a964532acdf4077f13d362cb	0	t	2026-10-31 10:21:06.395497+00	2026-10-31 10:26:06.39512+00
1755e374-71ab-47a6-8955-58911a1e6c4e	9845678903	demo-jeweller-002	6feaaabf61e4d33a7efc01583ee2e70b255260d213d8d80b1877794b8d80e6c4	0	f	2026-10-31 10:21:06.641525+00	2026-10-31 10:26:06.641175+00
945b4804-ad63-48d4-8203-32ed68bd53f2	9876543210	demo-jeweller-002	ca969a116c388dc633d5b4178bd961b9175109bc87ba3facc37b152b1946d98b	0	f	2026-10-31 10:21:06.98111+00	2026-10-31 10:26:06.980809+00
82ba30c2-42d1-4ad7-a925-7e747ff798e2	9845678903	demo-jeweller-002	81d7c9531a24293678c38b77fa9d0624f7980179c513d1c084c8e76c06ca2dd9	0	t	2026-10-31 10:21:07.128295+00	2026-10-31 10:26:07.12798+00
a412c347-5285-4051-b86d-cedf77a73fd5	9845678903	demo-jeweller-002	3fba60adca9c90025927e0e9a0347c0224394a7e4c4e3af042d0434249dcab0e	0	t	2026-10-31 10:21:07.500666+00	2026-10-31 10:26:07.500334+00
282aa930-e812-49d8-804d-dc86c1c43a3d	9845678903	demo-jeweller-002	a4a646f44cd1c4aa7581decfc61d2b22828e999541d691a7279b5072caf9d552	0	t	2026-10-31 10:22:22.06185+00	2026-10-31 10:27:22.06153+00
2dedd7b6-ab30-45de-8b98-b0c58fcc8de2	9845678903	demo-jeweller-002	2fe35532cd6b1b25b4631d763bc13bc9da7a42663fa543f7668ae4ced5786786	0	t	2026-10-31 10:22:22.462488+00	2026-10-31 10:27:22.462171+00
bc881cc4-5ccd-4b4e-b03f-1a18f8296530	9845678903	demo-jeweller-002	c412c5cfe0c1b025dddba13ec1a95e81514416de73a909637aaa1328519dfdaa	0	t	2026-10-31 10:23:00.255542+00	2026-10-31 10:28:00.255217+00
a33bfd73-ea09-4ae4-a250-c21124e1c514	9845678903	demo-jeweller-002	6d64c8d7b0a4bea3ede681fe168f49d07786493470bd5b1d207eb8ba7abecd03	0	t	2026-10-31 10:23:26.578019+00	2026-10-31 10:28:26.577744+00
6a63f676-5bcc-43d9-9466-9c4edf12c89c	9876543210	demo-jeweller-001	055d4ed85b2c1207d4e20b9a2a104e0500394eb40fd365773fd59aaa898906a6	0	t	2026-10-31 10:23:44.810374+00	2026-10-31 10:28:44.81007+00
3308a417-3abc-4ba7-ab91-4848891be388	9845678903	demo-jeweller-002	b0be6514e0ec142c5e817471783359ab62f359a3f5eb2399e796530b374559ab	0	t	2026-10-31 11:48:05.346229+00	2026-10-31 11:53:05.34524+00
8190397c-9d24-4dd1-9c38-bed3427a913e	7016672614	demo-jeweller-001	7ef13b0f4d4a88354a3cd5c24d7a52f45ac6cfa549079c60f4affd098ee6b613	0	t	2026-10-31 12:29:18.829916+00	2026-10-31 12:34:18.82966+00
e03d3772-d172-44f6-ba17-5a01159cd9cb	9876543210	demo-jeweller-001	0d0e807091d2fd0be00f01960a5017947c3dfffcbbedff5bcbdbea3f637bc608	0	t	2026-10-31 15:18:46.139727+00	2026-10-31 15:23:46.137936+00
3590605a-ae46-4b13-a38d-6c8fd46478ac	9876543210	demo-jeweller-001	a41febb561d98c19f5732ce971ede1acedc3a7fea2e6a028904b028d2193aa78	0	t	2026-10-31 15:18:52.458242+00	2026-10-31 15:23:52.457965+00
83b9847f-926c-4bfc-9479-0b92bf1f79a6	9876543210	demo-jeweller-001	87561e6087cc4cde8e8b51c202802a63a91f2c7e126289504e8f7196e66925b1	0	t	2026-10-31 15:19:00.976753+00	2026-10-31 15:24:00.976473+00
bb4a3102-415d-48a7-a3ad-068f95c5d7bf	9876543210	demo-jeweller-001	61b303c4055f2c75177c2009d5fe47e7ea757fadcb2eb94d19df335b96386c1b	0	t	2026-10-31 15:20:45.389751+00	2026-10-31 15:25:45.388805+00
cc3be302-0803-4de6-8f42-57928c00675d	9845678903	demo-jeweller-002	a6ad1c29dc37abb66d3a91d784db8c8e35bfd8bf0c04240134a41966df911d82	0	t	2026-10-31 15:20:50.374847+00	2026-10-31 15:25:50.374626+00
25fc2319-2385-41f1-a55f-e07236ee4b81	9834567892	demo-jeweller-001	b12b430b527448edbe8dc056d70a5f61aecb11c5b0f82ce6c1b88538324dc75d	0	t	2026-10-31 15:20:52.57425+00	2026-10-31 15:25:52.574041+00
b3a959a1-20aa-493c-8fa0-555cf4f92c21	9834567892	demo-jeweller-001	00b6f6d46fcf608813cbff7551a8c71531f314e478368c2349f0123b7344d74e	0	t	2026-10-31 15:20:58.766193+00	2026-10-31 15:25:58.765955+00
d41f6497-5cad-48ed-92e8-3fea127eb9ed	9876543210	demo-jeweller-001	09b861565b1ceae986ebac8428ff3b45c7d24d863c0a68ca4912d8db31a99ecf	0	t	2026-10-31 15:21:10.287857+00	2026-10-31 15:26:10.286972+00
3fecfdfc-9a0e-438f-b230-6b2140d551e9	9845678903	demo-jeweller-002	af3e6de3b476af9d45e9d60795b6f684ce8712fb4a014f643677059d069c43fa	0	t	2026-10-31 15:21:13.367518+00	2026-10-31 15:26:13.367283+00
7f43ca83-5730-48c9-9f5f-69fae5428052	9834567892	demo-jeweller-001	88fb04a56885ff16fbdcc0b409fc1d4d8ed0d63dd43ea1db1b5ae00cbe973b3e	0	t	2026-10-31 15:21:15.575021+00	2026-10-31 15:26:15.574823+00
fa362a8c-0f22-449c-abc0-9ed697f87bff	9834567892	demo-jeweller-001	464f7b3685424b585473822d0bbae807b26c9f83addb7167494012be138ded2b	0	t	2026-10-31 15:22:11.871439+00	2026-10-31 15:27:11.871189+00
be2bac94-c20c-406e-b2b0-ca9a162a5645	9834567892	demo-jeweller-001	5e6ec2a20c9967c1f31b0b1d5ca6f622efd57fdcdac1321b8889bbc1940149fd	0	t	2026-10-31 15:22:42.443217+00	2026-10-31 15:27:42.442976+00
447ed73e-1e99-4829-a530-08b6f52b75b7	9834567892	demo-jeweller-001	9d1422f170f0cf21cd24ff0ce1d051f13edb489e985b612610df6340f0c3cdb3	0	t	2026-10-31 15:23:02.220351+00	2026-10-31 15:28:02.219842+00
c6dc08dd-50ed-425a-8ba3-d152287b7418	9834567892	demo-jeweller-001	0c3becf1f7808d4d6197b98f6fe48204ce6d193c33bba69b45ef7c662d7806f7	0	t	2026-10-31 15:23:24.267808+00	2026-10-31 15:28:24.267567+00
f7b3b6a0-d2ae-47c5-a0d0-b05ad958257a	9834567892	demo-jeweller-001	ea07f7c6978d6e18dd81da9da1fa0471ed985f128662def3bb7e108fcc4c6f95	0	t	2026-10-31 15:26:29.807522+00	2026-10-31 15:31:29.807263+00
46f74fb3-7861-4021-ac2c-4091a1150faa	9845678903	demo-jeweller-002	b84c4fd841c6c0874fbc3f5333e029d7767d234de6fcb61b41a829677e7b09d1	0	t	2026-10-31 15:26:45.497212+00	2026-10-31 15:31:45.496961+00
43d97ae1-0f8a-41c1-901b-6400c352afcd	9876543210	demo-jeweller-001	9604c37e72ed98b6bdecbb6181823ff70204d75e525e7262d70944298f5886fa	0	t	2026-10-31 15:26:46.196028+00	2026-10-31 15:31:46.19582+00
19f1fcd1-dc0f-486c-8813-69384e479a1d	9845678903	demo-jeweller-002	ac647c3da50f55598ac93bb88ac8393b471ed7cbb8ca79f52a0a3a0858a44444	0	f	2026-10-31 15:26:46.59168+00	2026-10-31 15:31:46.591446+00
9ab625ed-f204-4c1e-83e8-7c83284573c6	9876543210	demo-jeweller-002	fe008df2db64ca5530040e1474b1d89e87c02dd9a7579c004e72728722ad7a59	0	f	2026-10-31 15:26:46.720891+00	2026-10-31 15:31:46.720731+00
aec5902e-d221-4ec9-b7cc-970a2a118d69	9876543210	demo-jeweller-001	04cafc832da440987adb0d7c2eba2ac3d8315e5fea0454c9359edfd0745560da	0	t	2026-10-31 15:26:46.850027+00	2026-10-31 15:31:46.849873+00
5ecb5f18-067e-40b0-88d3-b4bc1fb0ba6a	9845678903	demo-jeweller-002	5cfff5d2bdcc9bde8185b935c15171b8ce2aefe568cb2d13dce9cff324c33619	0	t	2026-10-31 15:26:46.841832+00	2026-10-31 15:31:46.841641+00
bdf3984b-098a-4fe4-8531-4b146f747356	9845678903	demo-jeweller-002	04025305b4f720c4cf66c3e4267c1895fe5d61d3d22676c3d1f23a8b2f9b388d	0	t	2026-10-31 15:26:47.404601+00	2026-10-31 15:31:47.404359+00
da6f4dfc-fbf8-4293-bc0d-2e0ca6f6cb6d	9876543210	demo-jeweller-001	64baf929e940b0f28ddd6b5738bb96ec63a19e92a3b8908d7dc73b670c9620ff	0	t	2026-10-31 15:29:44.856623+00	2026-10-31 15:34:44.855777+00
a6eea9db-5998-4a89-8b69-0a093c07d293	9876543210	demo-jeweller-001	ba95ba72c69bd3bc80e9548eb8d3751b3e097eb5a3f26f11559f170d56798fd9	0	t	2026-10-31 15:29:46.874892+00	2026-10-31 15:34:46.874661+00
03e747dd-56f6-4932-8076-5d05c8e70a42	9845678903	demo-jeweller-002	40ae471a757d21514fdda27edc5812e2b94f4550ea8bf610f56c373a355719f8	0	t	2026-10-31 15:29:47.99535+00	2026-10-31 15:34:47.995107+00
68318433-3725-4013-be7d-6a2417d0cfd8	9812345670	demo-jeweller-001	2272f0f1ba32f7cc0750d0fe77d6122b59d7541830870447876ee2e3b2081ffb	0	t	2026-10-31 15:29:49.378259+00	2026-10-31 15:34:49.37808+00
cd8564d3-67b4-4ba1-81ff-d083cbdbe48b	9834567892	demo-jeweller-001	27cb175867c5488aa750a9a4db29b1dc6eed786b61a8674a96883b3d7fb096b1	0	t	2026-10-31 15:29:50.282827+00	2026-10-31 15:34:50.282645+00
30678057-b36c-4b97-9690-7654b67e0a12	9876543210	demo-jeweller-001	a48a1eae002dd708bf0e81abd9e076d6529ddb4e93d557c2f47f3fb061e7f236	0	t	2026-10-31 15:30:00.315407+00	2026-10-31 15:35:00.315197+00
c185d878-0f6b-40c6-9483-d1afec9d503d	9812345670	demo-jeweller-001	d79035937224c462b2324b83cd9cd41a61b1c8f90c7f2e0905e724f23c1cee7f	0	t	2026-10-31 15:30:01.649423+00	2026-10-31 15:35:01.649168+00
e5c708eb-d693-460d-bd22-59dc00e066dc	9876543210	demo-jeweller-001	fe7adf9ac20630f27b24ec8d8d50cd7c192317291f9aa4f0620c728d01386a4d	0	t	2026-10-31 15:30:03.053825+00	2026-10-31 15:35:03.053586+00
6c46d0d0-70ab-45b3-ab7a-b58cb751e32d	9845678903	demo-jeweller-002	19b7b16f79a89b7363362a326ec33d580db648b5d04935c779909df72c72b221	0	t	2026-10-31 15:31:14.441876+00	2026-10-31 15:36:14.441633+00
b2dca66a-a7b7-4828-b2cf-99b69cf37372	9834567892	demo-jeweller-001	4f6e0ae582c0aed7e4c1111c826d9b31e1fb99cab486d8cdb575ed9e83e8fb08	0	t	2026-10-31 15:31:16.494698+00	2026-10-31 15:36:16.494444+00
0e6f1d49-d115-406c-93d8-16144ee1b60f	9834567892	demo-jeweller-001	7032e68609418757a3bb368d372a514951d2bd67ab60e8a42693e3913e3c0621	0	t	2026-10-31 15:31:26.951569+00	2026-10-31 15:36:26.950507+00
2064c723-9a3f-4a13-9a86-7ee8f8baab42	9834567892	demo-jeweller-001	9c088c91d6db0bd2bcc3a48dd8d96e54748f46b587c0faa0eea3371da360d567	0	t	2026-10-31 15:31:33.136662+00	2026-10-31 15:36:33.136366+00
1f229d2c-2f1f-4c9b-87fe-1854e1238005	9834567892	demo-jeweller-001	ec2d6973dd49ce137e59bc5ab17c674d0497354d249ca7bea74c8de96fcc82e6	0	t	2026-10-31 15:31:41.447814+00	2026-10-31 15:36:41.447545+00
b194b159-7858-4aed-a6d0-563c2e3534a1	9834567892	demo-jeweller-001	06cb987c039ccbed29cbcc4ea487d130dfabe5b7a35661109a4b24da19b4d3e0	0	t	2026-10-31 15:31:49.425799+00	2026-10-31 15:36:49.425555+00
602afee2-a794-4ff7-a915-c7e43e8a888b	9876543210	demo-jeweller-001	7ae9c5cee7ab5c7dcbc8da7060e1678d989c4b0d5e90614993c37f3dfdc70889	0	t	2026-10-31 15:32:50.722127+00	2026-10-31 15:37:50.721884+00
b7d72264-2a40-4be0-8da1-4a907c6e6c1f	9876543210	demo-jeweller-001	0af7974233d49f90b511ba1e2624ed0681e67f400980fe24c3f6e79efdd39453	0	t	2026-10-31 15:33:15.691443+00	2026-10-31 15:38:15.691189+00
7bde049d-ca55-4507-a7d0-a8e21454b401	9834567892	demo-jeweller-001	b95565164f05255a382f1b3cc8dba7c1fa284168361c2cca22e0b94b204f7619	0	t	2026-10-31 15:35:12.335773+00	2026-10-31 15:40:12.335515+00
9cf2a364-4d46-4223-b441-b46f21d7ec4d	9834567892	demo-jeweller-001	fa701e603ae78136e6d93b09ecf720d998f19ca42b7b25c03236e5769b69caf8	0	t	2026-10-31 15:36:59.885845+00	2026-10-31 15:41:59.885001+00
\.


--
-- Data for Name: pickups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pickups (id, customer_id, jeweller_id, transaction_id, item, grams, making_charges, otp, attempts, locked, status, collected_at, collected_by, created_at) FROM stdin;
4b42afad-6538-4c2a-b1da-97d7eecd9a90	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	\N	1g 24K Gold (vault)	1	0	684980	0	f	cancelled	\N		2026-10-31 15:21:16.903884+00
1fa77015-bf95-4114-82e5-1d0b742ff309	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	89e7667a-548d-44f3-8731-92ef62a18dbc	1g 24K Gold (vault)	1	0	124385	0	f	pending	\N		2026-10-31 15:21:17.494221+00
7b5ff212-1f6f-411b-baf4-efbe0cb08e5e	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	6339d4bc-addc-42bf-a68e-1beadcdc089d	1g 24K Gold (vault)	1	0	155524	0	f	pending	\N		2026-10-31 15:23:40.584405+00
518058fc-c949-4f3a-84bb-d963c70a4ec3	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	\N	1g 24K Gold (vault)	1	0	619058	0	f	cancelled	\N		2026-10-31 15:29:51.588716+00
33a2dbae-eb7c-4401-9d3e-7137dce8f37a	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	dc4826da-582a-4b9e-a089-177997b3c38e	1g 24K Gold (vault)	1	0	516446	0	f	pending	\N		2026-10-31 15:29:52.1073+00
9df0c01a-442c-4e9b-aaba-faf856ff2178	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	\N	1g 24K Gold (vault)	1	0	128804	0	f	cancelled	\N		2026-10-31 15:31:18.867141+00
2100db22-918c-46bb-97ba-c09311bbea17	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	e28c4b36-be1a-4579-8da9-fd8abc09d664	1g 24K Gold (vault)	1	0	367682	0	f	pending	\N		2026-10-31 15:31:19.379904+00
205123c5-b6c4-427a-a3d1-44c98bf386fe	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	\N	1g 24K Gold (vault)	1	0	510591	0	f	cancelled	\N		2026-10-31 15:31:34.996831+00
12a736e0-e9e6-4777-a478-c4f4de2f3674	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	9f4c8506-d81b-4420-bd9b-11357439f3cb	1g 24K Gold (vault)	1	0	466064	0	f	pending	\N		2026-10-31 15:31:35.656121+00
9d9646de-7317-47a5-9491-2c5e5fcb48a3	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	\N	1g 24K Gold (vault)	1	0	068965	0	f	cancelled	\N		2026-10-31 15:31:42.895884+00
c1a3ff27-7c44-4ee2-a00f-12608617bd6a	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	b5638258-eaf3-4aeb-81ef-8436aa429475	1g 24K Gold (vault)	1	0	087799	0	f	pending	\N		2026-10-31 15:31:43.418073+00
4b1b66b9-f062-4206-94d0-cb32e4ed27eb	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	\N	1g 24K Gold (vault)	1	0	337803	0	f	cancelled	\N		2026-10-31 15:31:50.685114+00
1c88fef6-fa40-4290-b80b-161e39bb7fb9	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	994b36a0-7df9-4120-a29c-84e0d0fde4a0	1g 24K Gold (vault)	1	0	061017	0	f	pending	\N		2026-10-31 15:31:51.190916+00
41bff2a3-be12-4ddd-8782-497cc7d71fc4	a44a44be-7a5d-4dfc-9b40-bf8a46e44bb7	demo-jeweller-001	58715725-02a3-4918-9cfb-1bfc3cce865b	1g 24K Gold (vault)	1	0	281780	0	f	pending	\N		2026-10-31 15:19:01.116926+00
c15287df-2031-42e4-9af7-2639f7f7b1e2	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	\N	1g 24K Gold (vault)	1	0	130891	0	f	cancelled	\N		2026-10-31 15:35:12.738613+00
2eadf263-25ad-461f-bd88-4f73e26d0231	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	\N	1g 24K Gold (vault)	1	0	968361	0	f	cancelled	\N		2026-10-31 15:37:01.691472+00
509840b7-0a58-45be-9411-9af95cd1c06e	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	4528c3f2-9f14-422b-af02-956710de712b	1g 24K Gold (vault)	1	0	334302	0	f	pending	\N		2026-10-31 15:37:02.201819+00
\.


--
-- Data for Name: pool_accumulator; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pool_accumulator (id, total_grams, threshold_grams, status, triggered_at, procured_at, created_at) FROM stdin;
99ad57ba-3279-4b85-a7df-38285e0bbc11	15.308	10	triggered	2026-10-31 12:29:46.164155+00	\N	2026-10-29 17:20:10.283388+00
78fa2a24-780c-4e21-afab-a3e1456878d1	10	10	triggered	2026-10-31 12:30:31.620429+00	\N	2026-10-31 12:29:46.176678+00
f2a2c955-c1a4-4ac8-be37-f0003c61120a	8.3173	10	accumulating	\N	\N	2026-10-31 12:30:31.624337+00
\.


--
-- Data for Name: pool_contributions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pool_contributions (id, pool_id, transaction_id, customer_id, jeweller_id, grams, created_at) FROM stdin;
00e031d9-c2c1-48c7-957a-002ea22e05f1	99ad57ba-3279-4b85-a7df-38285e0bbc11	23228a8e-449e-4537-9c72-e88a1742f0be	a44a44be-7a5d-4dfc-9b40-bf8a46e44bb7	demo-jeweller-001	0.6912	2026-10-29 17:20:10.290422+00
666084ff-caeb-4844-a320-39649a5f324f	99ad57ba-3279-4b85-a7df-38285e0bbc11	95fb4a30-1a33-4932-b26f-cae182e99e7d	a44a44be-7a5d-4dfc-9b40-bf8a46e44bb7	demo-jeweller-001	0.1398	2026-10-29 17:20:10.290424+00
b7a0622e-c74c-43e2-8c20-2540f4e9b771	99ad57ba-3279-4b85-a7df-38285e0bbc11	9857cdc2-117c-4239-a36d-9e7989bf20c8	a44a44be-7a5d-4dfc-9b40-bf8a46e44bb7	demo-jeweller-001	0.3489	2026-10-29 17:20:10.290425+00
92395091-ab8f-4b8e-94ce-9648dca674da	99ad57ba-3279-4b85-a7df-38285e0bbc11	824ed577-2969-4c96-aa6d-0779cd756ce8	a44a44be-7a5d-4dfc-9b40-bf8a46e44bb7	demo-jeweller-001	0.1412	2026-10-29 17:20:10.290425+00
de223fa0-1b81-414e-abd1-e9bbea69fd43	99ad57ba-3279-4b85-a7df-38285e0bbc11	6a3c6fe2-5fc2-4365-ba07-a0c7b0c16387	41d1e25d-a0b9-4aba-8eaf-f86db84c90e0	demo-jeweller-001	0.2818	2026-10-29 17:20:10.293464+00
f489ae0e-49c3-4b96-889a-bb6a77ea1459	99ad57ba-3279-4b85-a7df-38285e0bbc11	8bee719f-343e-414d-97f0-442a6f9aec27	41d1e25d-a0b9-4aba-8eaf-f86db84c90e0	demo-jeweller-001	0.6926	2026-10-29 17:20:10.293465+00
85de36dc-9922-4823-b2cc-c37507b500bd	99ad57ba-3279-4b85-a7df-38285e0bbc11	4b87c8f9-d877-499c-a3d2-e9b317931b11	41d1e25d-a0b9-4aba-8eaf-f86db84c90e0	demo-jeweller-001	0.2809	2026-10-29 17:20:10.293466+00
1054bf78-09cc-43b2-bb2e-17c1fa874130	99ad57ba-3279-4b85-a7df-38285e0bbc11	e686bfc6-3cd7-473b-a55c-1498f9d1e8b3	41d1e25d-a0b9-4aba-8eaf-f86db84c90e0	demo-jeweller-001	0.7066	2026-10-29 17:20:10.293467+00
ee194386-b91b-4194-9c36-c0661c18724b	99ad57ba-3279-4b85-a7df-38285e0bbc11	8dca3297-067a-4c8a-b342-650af3b4f8a2	82db254e-16c1-447e-a5aa-dc4a74b47a8b	demo-jeweller-001	0.1383	2026-10-29 17:20:10.295616+00
432058f1-63f4-4767-9c21-da3efd45374f	99ad57ba-3279-4b85-a7df-38285e0bbc11	928df523-99b4-4c8a-9f4f-4c8a89df4c43	82db254e-16c1-447e-a5aa-dc4a74b47a8b	demo-jeweller-001	0.2772	2026-10-29 17:20:10.295617+00
4ed73f9f-f575-43cb-9004-13fdac934b30	99ad57ba-3279-4b85-a7df-38285e0bbc11	9ecbd960-3131-44ac-9c2e-ab17d1acdd93	82db254e-16c1-447e-a5aa-dc4a74b47a8b	demo-jeweller-001	0.3506	2026-10-29 17:20:10.295618+00
ff02cee4-604f-45a4-80c4-a2499257aa5a	99ad57ba-3279-4b85-a7df-38285e0bbc11	4febbe7c-2540-44e3-94ba-68f85282b642	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	0.2773	2026-10-29 17:20:10.298398+00
bca3b58b-4caf-4c80-a742-61e3a245a224	99ad57ba-3279-4b85-a7df-38285e0bbc11	4131bac1-86bc-4746-9333-c666132fd029	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	0.2811	2026-10-29 17:20:10.2984+00
21b8397e-f7f3-44b4-8248-53b874fa9373	99ad57ba-3279-4b85-a7df-38285e0bbc11	75a58078-e794-469c-a25e-4fe0d5e2a994	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	0.7005	2026-10-29 17:20:10.298401+00
583a8baa-9de8-4b7e-9903-36526046cd13	99ad57ba-3279-4b85-a7df-38285e0bbc11	dc541801-513d-4fcf-8004-d7f875981abe	2b6458cc-ad07-4062-b8d1-eabbc66c7432	demo-jeweller-001	10	2026-10-31 12:29:46.165581+00
b028fdb0-9294-448a-b320-58326f42c7f1	78fa2a24-780c-4e21-afab-a3e1456878d1	b5da192e-33d3-4dc7-b605-2c13e72c3a0d	2b6458cc-ad07-4062-b8d1-eabbc66c7432	demo-jeweller-001	10	2026-10-31 12:30:31.620986+00
537266cc-30c2-4423-850a-b71951d0aae2	f2a2c955-c1a4-4ac8-be37-f0003c61120a	1f7a068a-59eb-49ac-8d6f-41cb830c6db9	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	1.1639	2026-10-31 15:21:16.589021+00
03994831-036a-4938-bde6-fd05ec16fbd2	f2a2c955-c1a4-4ac8-be37-f0003c61120a	f26b252d-4aa0-4dcf-8a00-723f5ccc697b	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	0.0347	2026-10-31 15:23:07.393971+00
46ab18a0-7cf5-4102-b711-a4ea7d61fa40	f2a2c955-c1a4-4ac8-be37-f0003c61120a	a9a6d9f2-88f9-4354-82f7-33846b27ff11	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	1.1639	2026-10-31 15:29:51.315396+00
880163b9-983f-4a71-b3c1-db8838254141	f2a2c955-c1a4-4ac8-be37-f0003c61120a	97b2e608-e67d-41fb-a050-b555c362f7ad	a44a44be-7a5d-4dfc-9b40-bf8a46e44bb7	demo-jeweller-001	0.0347	2026-10-31 15:30:00.698706+00
cd1bc2ce-4f96-4842-be5e-0fab330c5b6a	f2a2c955-c1a4-4ac8-be37-f0003c61120a	c5c2bf33-a967-4de6-a6eb-75796ecb0907	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	1.1639	2026-10-31 15:31:18.623857+00
b2c5e456-b1a0-4910-b5b8-54cfee753d87	f2a2c955-c1a4-4ac8-be37-f0003c61120a	f3c7534f-558f-46eb-896f-6f2f91d0bbd8	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	1.1639	2026-10-31 15:31:34.746885+00
a7756c7c-f7a6-41a5-91bf-31cc1757e5a0	f2a2c955-c1a4-4ac8-be37-f0003c61120a	f294f43c-e6f8-4723-baa3-6020fd4381bc	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	1.1639	2026-10-31 15:31:42.606977+00
028bf65b-46d5-4bbd-b3c3-05b8b3d1a80d	f2a2c955-c1a4-4ac8-be37-f0003c61120a	4948f461-6a33-4d9b-9994-58329821557c	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	1.1639	2026-10-31 15:31:50.420709+00
98221d89-48c5-4f89-8d8d-1bd34db89c8b	f2a2c955-c1a4-4ac8-be37-f0003c61120a	be5718f5-c623-476f-aede-b91fbd29d542	a44a44be-7a5d-4dfc-9b40-bf8a46e44bb7	demo-jeweller-001	0.1008	2026-10-31 15:33:01.479014+00
44a32e4f-3d95-4132-ab87-65e9a1311af2	f2a2c955-c1a4-4ac8-be37-f0003c61120a	53f4d23b-a734-490e-a22f-656e4956b23b	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	1.1639	2026-10-31 15:37:01.443859+00
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products (id, jeweller_id, name, category, grams, making_charges, making_pct, image_url, tag, description, is_active, created_at, purity) FROM stdin;
c3515e35-dc58-411b-a6a3-a221450315c9	demo-jeweller-001	Heritage 24K Necklace	necklaces	12.5	4850	12		Trending	Exquisite Heritage 24K Necklace in 24K 99.9% pure gold. Weight: 12.5g. BIS Hallmarked.	t	2026-10-29 17:20:10.284403+00	22K
f2adc2ee-761f-4ec9-a45d-645cbf2c33ba	demo-jeweller-001	Classic Solitaire Ring	rings	3.4	1150	12		New	Exquisite Classic Solitaire Ring in 24K 99.9% pure gold. Weight: 3.4g. BIS Hallmarked.	t	2026-10-29 17:20:10.284407+00	22K
8384fd53-c28e-4d45-8cc6-dc867f075525	demo-jeweller-001	Rope Twist Chain	chains	6.8	1980	12		Trending	Exquisite Rope Twist Chain in 24K 99.9% pure gold. Weight: 6.8g. BIS Hallmarked.	t	2026-10-29 17:20:10.284407+00	22K
cd661d0a-3ac1-4baa-a31c-f42c610d8552	demo-jeweller-001	Royal Kada	kadas	15	5200	12		Premium	Exquisite Royal Kada in 24K 99.9% pure gold. Weight: 15.0g. BIS Hallmarked.	t	2026-10-29 17:20:10.284408+00	22K
ea2e8948-c241-4dd7-a593-13e2fcfb24a6	demo-jeweller-001	Lakshmi Pendant Set	pendant-sets	9.6	3400	12		Festive	Exquisite Lakshmi Pendant Set in 24K 99.9% pure gold. Weight: 9.6g. BIS Hallmarked.	t	2026-10-29 17:20:10.284409+00	22K
0bc97d0d-5b9e-4c60-98ec-082bf6d026c9	demo-jeweller-001	Gold Dial Watch	watches	18	7900	12		Luxury	Exquisite Gold Dial Watch in 24K 99.9% pure gold. Weight: 18.0g. BIS Hallmarked.	t	2026-10-29 17:20:10.28441+00	22K
72e1b4f3-cf74-439f-b0a5-bee51b6850cb	demo-jeweller-001	Tanmaniya Mangalsutra	necklaces	7.1	2300	12		Classic	Exquisite Tanmaniya Mangalsutra in 24K 99.9% pure gold. Weight: 7.1g. BIS Hallmarked.	t	2026-10-29 17:20:10.28441+00	22K
73ca1326-ef53-4271-a728-ddd82b9c886e	demo-jeweller-002	Heritage 24K Necklace	necklaces	12.5	4850	12		Trending	Exquisite Heritage 24K Necklace in 24K 99.9% pure gold. Weight: 12.5g. BIS Hallmarked.	t	2026-10-29 17:20:10.284411+00	22K
842599c5-f135-4b55-bcb3-cbafb1689b09	demo-jeweller-002	Minimalist Gold Bangle	bangles	8.2	2650	12		Bestseller	Exquisite Minimalist Gold Bangle in 24K 99.9% pure gold. Weight: 8.2g. BIS Hallmarked.	t	2026-10-29 17:20:10.284412+00	22K
14009c99-d550-433d-8a60-84fd875d1b8c	demo-jeweller-002	Classic Solitaire Ring	rings	3.4	1150	12		New	Exquisite Classic Solitaire Ring in 24K 99.9% pure gold. Weight: 3.4g. BIS Hallmarked.	t	2026-10-29 17:20:10.284412+00	22K
f8efc8b6-1c3e-4103-bfaf-32e7a73cb23a	demo-jeweller-002	Rope Twist Chain	chains	6.8	1980	12		Trending	Exquisite Rope Twist Chain in 24K 99.9% pure gold. Weight: 6.8g. BIS Hallmarked.	t	2026-10-29 17:20:10.284413+00	22K
753b7b8f-c932-4642-9455-220e9dd9ec6a	demo-jeweller-002	Royal Kada	kadas	15	5200	12		Premium	Exquisite Royal Kada in 24K 99.9% pure gold. Weight: 15.0g. BIS Hallmarked.	t	2026-10-29 17:20:10.284414+00	22K
35aeb3f0-471a-44c1-9056-3d2bf59b8693	demo-jeweller-002	Lakshmi Pendant Set	pendant-sets	9.6	3400	12		Festive	Exquisite Lakshmi Pendant Set in 24K 99.9% pure gold. Weight: 9.6g. BIS Hallmarked.	t	2026-10-29 17:20:10.284414+00	22K
fd3fb337-95f5-46fe-a51c-85098cb85973	demo-jeweller-002	Gold Dial Watch	watches	18	7900	12		Luxury	Exquisite Gold Dial Watch in 24K 99.9% pure gold. Weight: 18.0g. BIS Hallmarked.	t	2026-10-29 17:20:10.284415+00	22K
5c1bc9a1-4459-4689-8618-bce78ef665e7	demo-jeweller-002	Tanmaniya Mangalsutra	necklaces	7.1	2300	12		Classic	Exquisite Tanmaniya Mangalsutra in 24K 99.9% pure gold. Weight: 7.1g. BIS Hallmarked.	t	2026-10-29 17:20:10.284416+00	22K
40a805d9-2427-4ce7-a882-af2cd43f84a5	demo-jeweller-001	Minimalist Gold Bangle	bangles	8.2	2650	24		Bestseller	Exquisite Minimalist Gold Bangle in 24K 99.9% pure gold. Weight: 8.2g. BIS Hallmarked.	t	2026-10-29 17:20:10.284406+00	22K
1c000827-767c-47c1-93c3-9235e486a5ad	b8a020fb-7073-48d2-a800-d7f3bef9a213	Heritage 24K Necklace	necklaces	12.5	4850	12		Trending	Exquisite Heritage 24K Necklace in 24K 99.9% pure gold. Weight: 12.5g. BIS Hallmarked.	t	2026-10-31 12:07:34.808727+00	22K
1307c988-a479-4719-8646-df1ac4f9514d	b8a020fb-7073-48d2-a800-d7f3bef9a213	Minimalist Gold Bangle	bangles	8.2	2650	12		Bestseller	Exquisite Minimalist Gold Bangle in 24K 99.9% pure gold. Weight: 8.2g. BIS Hallmarked.	t	2026-10-31 12:07:34.808729+00	22K
fb10ec58-9057-4484-ab0c-86ffc2163360	b8a020fb-7073-48d2-a800-d7f3bef9a213	Classic Solitaire Ring	rings	3.4	1150	12		New	Exquisite Classic Solitaire Ring in 24K 99.9% pure gold. Weight: 3.4g. BIS Hallmarked.	t	2026-10-31 12:07:34.80873+00	22K
3490ade0-814f-4d4a-9eaf-e4bc18ded5be	b8a020fb-7073-48d2-a800-d7f3bef9a213	Rope Twist Chain	chains	6.8	1980	12		Trending	Exquisite Rope Twist Chain in 24K 99.9% pure gold. Weight: 6.8g. BIS Hallmarked.	t	2026-10-31 12:07:34.808731+00	22K
b740a645-6bf7-4f5a-805c-6738eb0998d9	b8a020fb-7073-48d2-a800-d7f3bef9a213	Royal Kada	kadas	15	5200	12		Premium	Exquisite Royal Kada in 24K 99.9% pure gold. Weight: 15.0g. BIS Hallmarked.	t	2026-10-31 12:07:34.808732+00	22K
d8618a33-c4f6-4031-9f0e-629b693bd27d	b8a020fb-7073-48d2-a800-d7f3bef9a213	Lakshmi Pendant Set	pendant-sets	9.6	3400	12		Festive	Exquisite Lakshmi Pendant Set in 24K 99.9% pure gold. Weight: 9.6g. BIS Hallmarked.	t	2026-10-31 12:07:34.808733+00	22K
c86d9b82-5e4b-4918-80b1-a630395c9ed0	b8a020fb-7073-48d2-a800-d7f3bef9a213	Gold Dial Watch	watches	18	7900	12		Luxury	Exquisite Gold Dial Watch in 24K 99.9% pure gold. Weight: 18.0g. BIS Hallmarked.	t	2026-10-31 12:07:34.808734+00	22K
e2189731-a410-4f03-afb7-0181ee3a66b7	b8a020fb-7073-48d2-a800-d7f3bef9a213	Tanmaniya Mangalsutra	necklaces	7.1	2300	12		Classic	Exquisite Tanmaniya Mangalsutra in 24K 99.9% pure gold. Weight: 7.1g. BIS Hallmarked.	t	2026-10-31 12:07:34.808734+00	22K
\.


--
-- Data for Name: quotes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quotes (id, jeweller_id, metal, buy, sell, expires_at, created_at) FROM stdin;
fe40a4cb-2e49-4adf-bdda-62a4847b1c19	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 07:42:05.518243+00	2026-10-31 07:37:05.519541+00
505cdf43-dea7-4afa-b67f-b420beea4e9b	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 07:42:14.565108+00	2026-10-31 07:37:14.566168+00
fc1eab76-166c-42f2-9d79-0e0974b94521	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 07:42:35.453229+00	2026-10-31 07:37:35.453633+00
5f0fc4e3-bb53-40ce-b4bb-0d6d1d987936	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 07:42:37.902338+00	2026-10-31 07:37:37.902703+00
d11e019d-d94f-407c-9f2f-864f78b04f43	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 07:43:53.701868+00	2026-10-31 07:38:53.7022+00
ea5808ab-5616-4316-84c8-6888c3250b21	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 07:47:48.393478+00	2026-10-31 07:42:48.393811+00
f2f3da7f-59ba-4469-a143-e492ca3555ff	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 07:53:01.571096+00	2026-10-31 07:48:01.571422+00
e7ad9481-87ad-4fb9-98e5-f91e1ab6ff91	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 07:58:12.47002+00	2026-10-31 07:53:12.470338+00
5829a80c-6f74-4ca1-94e0-bea0a0ad9d66	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 07:59:00.196993+00	2026-10-31 07:54:00.197335+00
fd7d4ba1-5775-42ff-8372-bc743e973fc5	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 08:04:09.599596+00	2026-10-31 07:59:09.599896+00
d7495128-f627-400d-8593-6abc959abc26	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 08:09:17.090038+00	2026-10-31 08:04:17.090343+00
ad4aec89-e5bf-440c-8d8d-91d9a29d1c28	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 08:14:30.778763+00	2026-10-31 08:09:30.77906+00
0e108f93-cadf-436b-8619-797345b7fc4b	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 08:19:43.823511+00	2026-10-31 08:14:43.823822+00
566230c8-5c17-4948-9a37-4c78c809aaa7	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 08:20:00.444648+00	2026-10-31 08:15:00.444928+00
9e590457-5a9a-4f38-8c4a-d44648cb27bf	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 08:25:12.986072+00	2026-10-31 08:20:12.986353+00
bfcb9a52-e223-43f0-ae6e-961c5d1e6a2b	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 08:30:26.561922+00	2026-10-31 08:25:26.562196+00
65fb92dd-8329-42cb-9db5-c14e6e2939a7	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 08:35:40.152825+00	2026-10-31 08:30:40.153149+00
09158961-dad7-4d1a-a7b9-5bac76e9cb6a	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 08:40:54.101878+00	2026-10-31 08:35:54.10216+00
fac73eef-c792-47b3-9da4-76a4157c3c58	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 08:41:00.23661+00	2026-10-31 08:36:00.236901+00
5b44b316-a69e-43b2-9b5e-cb8a199c8076	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 08:46:13.046589+00	2026-10-31 08:41:13.046888+00
ddf3a4b0-3194-47f0-8395-1c78a8007da5	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 08:51:24.839689+00	2026-10-31 08:46:24.839984+00
5f0cca84-a904-422b-bd09-9fc432a29fb2	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 08:53:57.383426+00	2026-10-31 08:48:57.383724+00
d34039ab-dced-4cd0-87ba-82615a6cea5a	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 09:32:05.51369+00	2026-10-31 09:27:05.51508+00
f86ac75f-9a7a-43b0-b4f8-6f0547725464	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 09:32:06.274584+00	2026-10-31 09:27:06.27497+00
358b3c84-b242-44e8-b094-93db9bb47cb5	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 09:36:20.875265+00	2026-10-31 09:31:20.876319+00
c6a2cca3-06d7-423e-8d6c-3f2fc2d33b64	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 09:39:17.625253+00	2026-10-31 09:34:17.626603+00
e37765df-5f1d-47c6-9e10-c355ee41f472	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 09:39:26.659801+00	2026-10-31 09:34:26.660759+00
5086d1b2-48e0-46a7-8ded-39ad5a8fe466	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 09:39:48.546088+00	2026-10-31 09:34:48.546441+00
3aa4f11e-0aef-43e9-b79a-da28cb52d2d3	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 09:40:30.606593+00	2026-10-31 09:35:30.606916+00
8b2094d0-cdfd-4700-8717-68b8c9275478	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 09:41:13.354673+00	2026-10-31 09:36:13.354985+00
0863b012-9cf8-43c3-a6dd-1680db5383f2	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 09:41:24.943246+00	2026-10-31 09:36:24.94358+00
4b49654f-877e-4f60-98d2-db0b286495f7	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 09:43:54.938782+00	2026-10-31 09:38:54.939808+00
1bb86ae8-4fea-4ea2-bbed-b206044afad5	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 09:44:13.537151+00	2026-10-31 09:39:13.537514+00
1ec7a88c-39dd-428e-82b6-a4b9e1bbbd7a	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 09:49:09.72914+00	2026-10-31 09:44:09.729511+00
7f75c736-b158-42f3-8966-58d4643b52ec	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 09:59:09.806004+00	2026-10-31 09:54:09.806341+00
edcbae92-0146-4d88-9b2b-d3e54262fb6e	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 10:03:06.547626+00	2026-10-31 09:58:06.547966+00
0a84fb23-d1f9-43d8-8f64-408db46344f1	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 10:03:52.075799+00	2026-10-31 09:58:52.076122+00
4e4c4cf3-f08f-43cd-bf82-6c70aaf1f243	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 10:13:51.586836+00	2026-10-31 10:08:51.587157+00
5515f232-e791-4f38-bce4-0e8eb52f84b6	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 10:19:16.744998+00	2026-10-31 10:14:16.746212+00
5332da61-f478-45e4-bb0d-82c532d2378e	demo-jeweller-002	gold	13848.5	13433.05	2026-10-31 10:19:20.326666+00	2026-10-31 10:14:20.327027+00
8966b7c8-3c41-4b02-9c95-ada45b5aa439	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 10:21:44.121129+00	2026-10-31 10:16:44.122166+00
073ffe91-eeeb-471f-a91e-6f2caa2b6dee	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 10:21:46.061533+00	2026-10-31 10:16:46.061842+00
d92330bb-6a4a-4514-87e8-bfebaf92f731	demo-jeweller-002	gold	13848.5	13433.05	2026-10-31 10:21:50.828999+00	2026-10-31 10:16:50.829529+00
0dbbdce8-3991-44d4-aef2-84c61bee4a23	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 10:21:55.806559+00	2026-10-31 10:16:55.806918+00
86f0a43b-93fe-4de0-ae68-62d58d5a4d68	demo-jeweller-002	gold	13848.5	13433.05	2026-10-31 10:21:55.866501+00	2026-10-31 10:16:55.866846+00
333a6fb4-5d12-4920-aeea-896a193d1ee4	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 10:22:15.472636+00	2026-10-31 10:17:15.472941+00
b43e04b2-3d60-478d-8dba-d55baed2316d	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 10:23:00.7472+00	2026-10-31 10:18:00.74754+00
c1fb0484-e7fd-4bf7-8424-3afe7b79c53e	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 10:23:10.280129+00	2026-10-31 10:18:10.280479+00
8f8017c2-1262-4d2b-a219-aee948e8eb7f	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 10:23:13.842013+00	2026-10-31 10:18:13.842329+00
c9d46f5d-bba4-4f2f-8409-300471261728	demo-jeweller-002	gold	13848.5	13433.05	2026-10-31 10:23:17.307619+00	2026-10-31 10:18:17.307938+00
f12da840-3d07-4947-9efc-8baaf1fc44b7	demo-jeweller-002	gold	13848.5	13433.05	2026-10-31 10:26:08.305806+00	2026-10-31 10:21:08.306825+00
c31f475f-39df-4d7c-987e-2979736cacbb	demo-jeweller-002	gold	13848.5	13433.05	2026-10-31 10:27:22.315213+00	2026-10-31 10:22:22.315578+00
fa339ee9-cebd-4cf4-8dde-cd5b5d7896ea	demo-jeweller-002	gold	13848.5	13433.05	2026-10-31 10:27:23.224+00	2026-10-31 10:22:23.22433+00
51850678-1d5a-4dee-b277-28ac7e4da6e5	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 10:27:41.04051+00	2026-10-31 10:22:41.040814+00
b3a5711c-2522-42d0-9965-6e79888be4d2	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 10:27:54.387837+00	2026-10-31 10:22:54.388148+00
2d1c80b6-33fe-47f9-886a-f85bd3142678	demo-jeweller-002	gold	13848.5	13433.05	2026-10-31 10:27:57.021141+00	2026-10-31 10:22:57.021463+00
abdbd8ac-9e74-449d-a8df-58107725d3f6	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 10:28:19.862203+00	2026-10-31 10:23:19.86254+00
c2466397-f52c-45f3-87d0-4a14ebfc506a	demo-jeweller-002	gold	13848.5	13433.05	2026-10-31 10:28:22.493722+00	2026-10-31 10:23:22.494015+00
3e48e0e6-984b-47d5-b8cc-7de623322c13	demo-jeweller-002	gold	13848.5	13433.05	2026-10-31 10:28:27.17069+00	2026-10-31 10:23:27.17098+00
755c2b6e-283e-4480-9f06-7877a17e4c82	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 10:28:40.884393+00	2026-10-31 10:23:40.884721+00
8d2b5204-f097-4237-b3c5-723341137ab8	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 10:28:45.3982+00	2026-10-31 10:23:45.398508+00
c6be36bb-77ca-4217-b16f-ebac7b9af6c8	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 10:33:02.858728+00	2026-10-31 10:28:02.85906+00
fdf15c72-2c12-42c2-914d-d8805f7b76bd	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 10:43:03.035208+00	2026-10-31 10:38:03.035606+00
f368294f-7788-48e7-ac6e-e9e8d4bb22d7	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 10:53:02.984281+00	2026-10-31 10:48:02.984617+00
1ab60b10-9614-4b3f-be62-376aa9f6d5e1	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 11:03:03.953101+00	2026-10-31 10:58:03.953471+00
f7d76174-5aa3-4d7a-bbe0-318d31a22da9	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 11:03:56.333386+00	2026-10-31 10:58:56.333732+00
39cebc48-6bee-4953-b0e6-c184e15d93a8	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 11:35:37.190125+00	2026-10-31 11:30:37.19103+00
a578b884-c0ee-4496-931f-d648e59cacb5	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 11:44:54.873325+00	2026-10-31 11:39:54.873657+00
bdadd321-4ad4-4ff1-b105-56d8aceb869b	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 12:01:41.410858+00	2026-10-31 11:56:41.411754+00
652cd2b3-892a-4418-bbfc-70031a0ff5af	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 12:08:27.949744+00	2026-10-31 12:03:27.950049+00
c25eba2b-2b52-48ef-960f-dffdeb159f34	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 12:17:15.733699+00	2026-10-31 12:12:15.733981+00
e1b9b09b-7d4b-4d55-859c-46f854541315	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 12:27:18.878406+00	2026-10-31 12:22:18.878944+00
0960c4b2-ff6c-4bd9-90bf-8533f22db874	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 12:32:57.260409+00	2026-10-31 12:27:57.260693+00
a56d556b-7574-41bf-9076-8783397a7f65	demo-jeweller-002	gold	13848.5	13433.05	2026-10-31 12:33:52.613925+00	2026-10-31 12:28:52.614197+00
1649a325-0bfd-4f4b-9fff-83c6efb67c2a	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 12:33:55.654831+00	2026-10-31 12:28:55.655113+00
d5daff3e-b46d-44ec-83f6-48562de41bff	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 12:38:18.995147+00	2026-10-31 12:33:18.99544+00
c5a21e4a-e9bf-4945-964a-a24f5defa799	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 12:43:27.666362+00	2026-10-31 12:38:27.666649+00
f60f875c-4dbd-4cd0-b2f9-0247045a647e	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 12:48:59.810393+00	2026-10-31 12:43:59.81069+00
8be84ea8-0327-4395-a1df-ed5f914a531b	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 12:51:16.118556+00	2026-10-31 12:46:16.118846+00
95c5bd6c-0d61-4b34-899a-60e22ab2a3f9	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 12:56:29.980658+00	2026-10-31 12:51:29.980944+00
0f797894-ae84-409d-92f1-1c09871a8926	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 13:04:17.914779+00	2026-10-31 12:59:17.915059+00
2f553ddd-373f-4577-9709-5ecb2d3bd88f	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 13:14:17.660248+00	2026-10-31 13:09:17.660541+00
34587396-71e9-47a0-abe8-313c4f8258f9	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 13:24:17.914303+00	2026-10-31 13:19:17.9146+00
1993f4e6-70a0-4c23-b27c-c6fbf52e4bd5	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 13:34:14.884351+00	2026-10-31 13:29:14.884628+00
5f8315dc-d44c-48e9-9b37-d790e401a7b5	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 13:59:27.268696+00	2026-10-31 13:54:27.268983+00
73cf215d-7010-464a-a0d7-33c046dcadad	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 14:04:38.090446+00	2026-10-31 13:59:38.090729+00
e20371a0-d118-4de2-89ec-7b21a0a3c088	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 14:09:49.467902+00	2026-10-31 14:04:49.46818+00
0d16ad68-f284-4a24-8835-df59c2291ba5	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 14:15:00.860488+00	2026-10-31 14:10:00.860791+00
696ae891-186f-49fc-8f7e-6069fb68bd94	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 14:20:11.856453+00	2026-10-31 14:15:11.856729+00
e8203be2-3e57-4688-803f-8de7af2bc058	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 14:34:41.451643+00	2026-10-31 14:29:41.451919+00
220db4de-e7fa-4098-93e3-cb78e58f5df0	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 14:39:52.194366+00	2026-10-31 14:34:52.194653+00
b652ab27-6d67-4694-8dda-035b886ac121	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 14:59:54.179466+00	2026-10-31 14:54:54.179741+00
3846f10b-57c1-4a91-938e-c9ed6fd9356b	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:05:04.21777+00	2026-10-31 15:00:04.218046+00
327cfaf1-1885-4611-82d6-34fc99ae198a	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:10:14.295771+00	2026-10-31 15:05:14.296045+00
f10fa2cb-d082-48ab-828d-495e614f22c8	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:15:24.276926+00	2026-10-31 15:10:24.277197+00
80534592-5e53-415b-b6af-37e525200749	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:20:33.579671+00	2026-10-31 15:15:33.579951+00
b5c7fd17-7e53-40dc-8282-2032806a82ec	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:17:56.592916+00	2026-10-31 15:15:56.593853+00
40f5e73b-988c-4ffa-9777-a16c8ec34827	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:18:08.557196+00	2026-10-31 15:16:08.557533+00
919ceb83-1aab-4518-a6c2-698119c969e0	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:18:20.566968+00	2026-10-31 15:16:20.567904+00
9142e517-2293-4111-936a-9fbb8eb6ab6b	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:18:32.735167+00	2026-10-31 15:16:32.736289+00
481ca781-8b43-4320-b093-e7f8a5559ccf	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:18:47.7547+00	2026-10-31 15:16:47.755635+00
3846deb7-be00-46f5-9469-918713b2da6f	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:19:04.725912+00	2026-10-31 15:17:04.726196+00
a5f7761e-1b37-40fd-b711-5b8318bae6ef	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:19:04.928668+00	2026-10-31 15:17:04.928939+00
f5ba56c2-8eb5-4963-bf9f-5db3d28a6544	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:19:04.982779+00	2026-10-31 15:17:04.982996+00
5c13b3bd-b7e7-46c1-85ea-a1d6b2e386fb	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:19:05.624269+00	2026-10-31 15:17:05.624555+00
0177f865-12c4-41b8-8103-dcf1336cba06	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:19:10.172644+00	2026-10-31 15:17:10.172947+00
bc179d30-0677-4f98-8707-5ca677db0557	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:19:25.594389+00	2026-10-31 15:17:25.594692+00
e5536792-0793-49fc-8196-4a024a42bb75	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:20:26.337942+00	2026-10-31 15:18:26.338885+00
2cf6578c-cc7d-457b-965d-801b4f8b6b1e	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:20:46.215124+00	2026-10-31 15:18:46.215379+00
b372c80e-d439-4c1f-adf8-f9164575ea0e	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:21:01.050956+00	2026-10-31 15:19:01.051186+00
73b3165b-f8ee-442f-b9b9-a373140a6fd6	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:22:30.259976+00	2026-10-31 15:20:30.260933+00
5ac61015-4f2f-401b-bf92-322075a97c46	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:22:45.910142+00	2026-10-31 15:20:45.911181+00
f0d3c680-7df0-44a4-a113-31cc894da846	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:22:46.055718+00	2026-10-31 15:20:46.056013+00
3db00d79-2d87-4cd4-9603-e384f3faa556	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:22:46.355672+00	2026-10-31 15:20:46.355921+00
94d707c6-412b-4c17-9ff9-09b72bf9aa7c	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:22:47.335655+00	2026-10-31 15:20:47.335886+00
1e9be2ff-2969-4fee-be7d-9d14300181b9	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:22:47.895528+00	2026-10-31 15:20:47.895806+00
26a7abdc-a0bf-4f77-bdda-a7f501687e0d	demo-jeweller-001	silver	179.13	173.76	2026-10-31 15:22:48.189015+00	2026-10-31 15:20:48.189247+00
f21243f5-ff6e-4d4a-9aa1-77aaae3f3c11	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:22:50.967887+00	2026-10-31 15:20:50.968132+00
d1b00285-de5e-4c1f-9747-64d13f91316e	demo-jeweller-002	gold	13848.5	13433.05	2026-10-31 15:22:51.620374+00	2026-10-31 15:20:51.620583+00
efa95711-347e-41f8-9e33-ef02721f0504	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:22:52.053245+00	2026-10-31 15:20:52.053503+00
a817e0c7-11ca-4765-8f56-b96d50dcbaf0	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:22:53.30672+00	2026-10-31 15:20:53.30697+00
d95709b7-27c1-4413-b05f-2e7715193f4f	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:23:10.67254+00	2026-10-31 15:21:10.673533+00
b684e9c8-a81e-49d0-b8b4-8816708cf82a	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:23:10.794884+00	2026-10-31 15:21:10.795122+00
fad565c9-fd1a-4362-a98a-27843d916688	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:23:11.055571+00	2026-10-31 15:21:11.055835+00
809b17e2-8e48-4553-a256-7e4fe0f7504f	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:23:11.317245+00	2026-10-31 15:21:11.317505+00
1c351f0c-f9f0-49c3-b79e-477e3cbcd701	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:23:11.364348+00	2026-10-31 15:21:11.364548+00
0562f6dd-9fb3-4a8a-8f09-ae1f5b9ebdb3	demo-jeweller-001	silver	179.13	173.76	2026-10-31 15:23:11.591726+00	2026-10-31 15:21:11.591946+00
e3e36d49-41cb-4374-8ff0-3d4bc82bd3fb	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:23:13.896704+00	2026-10-31 15:21:13.89691+00
9082844e-ae43-4fbf-83aa-ae9df7637c9a	demo-jeweller-002	gold	13848.5	13433.05	2026-10-31 15:23:14.527512+00	2026-10-31 15:21:14.527717+00
02d16805-e714-43fd-8c16-d6dc56fc03b2	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:23:15.06972+00	2026-10-31 15:21:15.069979+00
966dfa55-4282-4aa4-b65d-cfc2b2bcfa42	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:23:16.323383+00	2026-10-31 15:21:16.323639+00
89213be6-0c17-4897-bc9a-4581a7da8221	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:24:12.183291+00	2026-10-31 15:22:12.183575+00
018918c9-4a2e-457f-bed4-090243dce81b	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:24:42.796702+00	2026-10-31 15:22:42.796955+00
63603978-9537-4365-9f2a-4889873e6682	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:25:02.545236+00	2026-10-31 15:23:02.545511+00
f234f8c0-f06e-4d6e-af25-8a8666f9c583	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:25:15.557707+00	2026-10-31 15:23:15.55797+00
bbee86ca-d720-41f7-9b4a-bc4110ec37f0	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:25:24.634474+00	2026-10-31 15:23:24.634723+00
1d783e66-0c2b-4649-9645-c4f8d6160e1d	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:28:08.393941+00	2026-10-31 15:26:08.394212+00
6e4df969-85e8-4753-b0ac-d42c69a71c3b	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:28:30.208639+00	2026-10-31 15:26:30.208911+00
d0f9f5b2-c409-4090-a43f-2497b05941f9	demo-jeweller-002	gold	13858.5	13433.05	2026-10-31 15:28:47.109366+00	2026-10-31 15:26:47.109595+00
aed9673f-7cee-47d3-aef2-2081a5d8918c	demo-jeweller-002	gold	13858.5	13433.05	2026-10-31 15:28:48.178633+00	2026-10-31 15:26:48.178872+00
a5d6759a-f91e-47fb-ba51-27744053a8fe	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:30:14.32753+00	2026-10-31 15:28:14.329432+00
eb6b868a-2401-4b01-a215-4bd3bf3953ac	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:30:26.334854+00	2026-10-31 15:28:26.335821+00
4d633f2b-78ed-4436-8d2a-073423307101	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:30:47.313409+00	2026-10-31 15:28:47.314548+00
ad84865a-7d00-40c3-9b41-628d0ba03b19	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:31:44.542287+00	2026-10-31 15:29:44.543191+00
804fe9fa-80f5-404b-a9c6-7ff75b9b7ca7	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:31:45.844576+00	2026-10-31 15:29:45.844799+00
71f13dc8-8faf-4513-807d-cdff9b0e8c2c	demo-jeweller-001	silver	179.13	173.76	2026-10-31 15:31:46.109132+00	2026-10-31 15:29:46.109388+00
1b1ad304-7910-4f90-9dcb-ff2b4293e781	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:31:48.626335+00	2026-10-31 15:29:48.626589+00
bcd0b96b-7193-4cc7-b695-9202fc7dc890	demo-jeweller-002	gold	13848.5	13433.05	2026-10-31 15:31:49.345105+00	2026-10-31 15:29:49.345328+00
48899314-29c0-4c42-97cd-1b1ab16efc53	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:31:49.718968+00	2026-10-31 15:29:49.7192+00
8f4c45fc-d200-427a-b924-d7c25c940c15	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:31:49.95215+00	2026-10-31 15:29:49.952374+00
aef295b9-378a-4903-8354-6e85fbd64e0c	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:31:51.027103+00	2026-10-31 15:29:51.02738+00
2d3e0e81-a4bb-4087-89c6-abeba13edbb4	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:32:02.167535+00	2026-10-31 15:30:02.167799+00
10270fce-b381-4c05-bf19-4035d2d6f1c9	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:32:03.52069+00	2026-10-31 15:30:03.520916+00
c108eb2f-ac7c-4676-879c-b1b0711d09f5	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:32:03.642746+00	2026-10-31 15:30:03.64293+00
8158c383-b359-4ffc-a54a-a8730e5e1c5e	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:32:03.884951+00	2026-10-31 15:30:03.885154+00
e172d419-ab77-427a-9cce-9963150854c6	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:32:04.159888+00	2026-10-31 15:30:04.160083+00
73386ca7-363e-466b-b0a8-e7c16f2e39ca	demo-jeweller-001	silver	179.13	173.76	2026-10-31 15:33:12.675705+00	2026-10-31 15:31:12.675969+00
472302cb-9fa7-49fd-86ca-49a36de497e9	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:33:14.983925+00	2026-10-31 15:31:14.984162+00
0e17238d-ef21-4361-b449-e4274fbf70a3	demo-jeweller-002	gold	13848.5	13433.05	2026-10-31 15:33:15.607882+00	2026-10-31 15:31:15.60808+00
f0e38d30-afbe-4519-bc4b-e38fae0cf9b4	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:33:15.985536+00	2026-10-31 15:31:15.985814+00
b03c39db-c318-4b27-9274-1d69e2874e40	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:33:18.375728+00	2026-10-31 15:31:18.375998+00
5691fa49-6cd6-4644-92ca-23d809233c16	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:33:33.905751+00	2026-10-31 15:31:33.906591+00
8ed9c649-0fed-441a-8b34-8fca3272d180	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:33:42.168822+00	2026-10-31 15:31:42.169078+00
a8467c26-c775-4f91-bbdf-5f1b08e73066	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:33:50.149052+00	2026-10-31 15:31:50.149303+00
55f6ae00-818a-4fec-9c8a-62612d1c9fe8	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:34:51.329897+00	2026-10-31 15:32:51.330138+00
1b147678-17c3-4215-a938-8f107ba98199	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:34:59.548807+00	2026-10-31 15:32:59.549074+00
3195f0e0-464f-4d6e-814f-836338a4ad9e	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:35:16.299578+00	2026-10-31 15:33:16.29983+00
e94b64bf-0329-4ed8-b08b-0f65d533d71f	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:37:08.114691+00	2026-10-31 15:35:08.114956+00
95dd155f-448c-48d8-9d9b-13a5a3f4bd53	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:38:05.095098+00	2026-10-31 15:36:05.095958+00
b664caa8-ba84-422a-9138-f262807f4b79	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:39:01.161553+00	2026-10-31 15:37:01.161854+00
7056bc49-f71d-4feb-8525-8a76b27bb70f	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:40:08.289743+00	2026-10-31 15:38:08.290022+00
b32540c3-4ad5-41c6-bcf7-a7377d40656f	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:42:11.061993+00	2026-10-31 15:40:11.062271+00
15d0eb9d-2002-4b38-9a75-647b88dc8531	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:44:20.872631+00	2026-10-31 15:42:20.872917+00
d0ea6b76-8f9e-4c5a-9a48-d6fba61cf1de	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:46:23.84696+00	2026-10-31 15:44:23.847226+00
a4400242-df53-4a2d-899f-9681c4b931db	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:47:04.937597+00	2026-10-31 15:45:04.938695+00
88830a3c-1645-4995-8ce5-c60f6015b484	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:47:28.880487+00	2026-10-31 15:45:28.881443+00
7388fc65-31d2-48fb-8463-f8dc134350e5	demo-jeweller-001	gold	13948.5	13433.05	2026-10-31 15:47:41.001593+00	2026-10-31 15:45:41.002566+00
\.


--
-- Data for Name: sips; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sips (id, customer_id, jeweller_id, amount, frequency, status, installments, grams_accumulated, next_run, created_at, metal) FROM stdin;
1c4aea44-65f2-4d37-bfd6-4ed6f7530244	a44a44be-7a5d-4dfc-9b40-bf8a46e44bb7	demo-jeweller-001	500	monthly	cancelled	0	0	2026-11-28 17:33:05.790649+00	2026-10-29 17:33:05.791638+00	gold
89bb404c-553f-41eb-8510-3e9731f654b2	a44a44be-7a5d-4dfc-9b40-bf8a46e44bb7	demo-jeweller-001	500	monthly	cancelled	0	0	2026-11-28 17:33:15.127391+00	2026-10-29 17:33:15.1277+00	gold
af3e5603-b4ba-4949-a9b8-a261de173b02	a44a44be-7a5d-4dfc-9b40-bf8a46e44bb7	demo-jeweller-001	500	monthly	cancelled	0	0	2026-11-30 15:29:47.217482+00	2026-10-31 15:29:47.218349+00	gold
27f7c0b7-efe8-4b8d-b210-35f737c09a77	a44a44be-7a5d-4dfc-9b40-bf8a46e44bb7	demo-jeweller-001	500	monthly	cancelled	1	0.0347	2026-11-30 15:30:00.695783+00	2026-10-31 15:30:00.570627+00	gold
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.transactions (id, invoice_no, customer_id, jeweller_id, type, metal, grams, rate, amount, gst, total, method, status, note, extra, pool_contribution, created_at) FROM stdin;
23228a8e-449e-4537-9c72-e88a1742f0be	VDG26102919917	a44a44be-7a5d-4dfc-9b40-bf8a46e44bb7	demo-jeweller-001	sip	gold	0.6912	7233.73	5000	150	5150	upi	completed		{}	t	2026-10-10 17:20:10.2811+00
95fb4a30-1a33-4932-b26f-cae182e99e7d	VDG26102954802	a44a44be-7a5d-4dfc-9b40-bf8a46e44bb7	demo-jeweller-001	sip	gold	0.1398	7152.21	1000	30	1030	upi	completed		{}	t	2026-10-22 17:20:10.2811+00
9857cdc2-117c-4239-a36d-9e7989bf20c8	VDG26102953729	a44a44be-7a5d-4dfc-9b40-bf8a46e44bb7	demo-jeweller-001	buy	gold	0.3489	7163.46	2500	75	2575	upi	completed		{}	t	2026-10-27 17:20:10.2811+00
824ed577-2969-4c96-aa6d-0779cd756ce8	VDG26102963510	a44a44be-7a5d-4dfc-9b40-bf8a46e44bb7	demo-jeweller-001	sip	gold	0.1412	7080.87	1000	30	1030	upi	completed		{}	t	2026-10-07 17:20:10.2811+00
6a3c6fe2-5fc2-4365-ba07-a0c7b0c16387	VDG26102955773	41d1e25d-a0b9-4aba-8eaf-f86db84c90e0	demo-jeweller-001	sip	gold	0.2818	7096.98	2000	60	2060	upi	completed		{}	t	2026-10-26 17:20:10.2811+00
8bee719f-343e-414d-97f0-442a6f9aec27	VDG26102963075	41d1e25d-a0b9-4aba-8eaf-f86db84c90e0	demo-jeweller-001	buy	gold	0.6926	7218.72	5000	150	5150	upi	completed		{}	t	2026-10-03 17:20:10.2811+00
4b87c8f9-d877-499c-a3d2-e9b317931b11	VDG26102914742	41d1e25d-a0b9-4aba-8eaf-f86db84c90e0	demo-jeweller-001	buy	gold	0.2809	7119.66	2000	60	2060	upi	completed		{}	t	2026-10-18 17:20:10.2811+00
e686bfc6-3cd7-473b-a55c-1498f9d1e8b3	VDG26102971601	41d1e25d-a0b9-4aba-8eaf-f86db84c90e0	demo-jeweller-001	buy	gold	0.7066	7076.05	5000	150	5150	upi	completed		{}	t	2026-10-11 17:20:10.2811+00
8dca3297-067a-4c8a-b342-650af3b4f8a2	VDG26102917575	82db254e-16c1-447e-a5aa-dc4a74b47a8b	demo-jeweller-001	buy	gold	0.1383	7227.1	1000	30	1030	upi	completed		{}	t	2026-10-09 17:20:10.2811+00
928df523-99b4-4c8a-9f4f-4c8a89df4c43	VDG26102980806	82db254e-16c1-447e-a5aa-dc4a74b47a8b	demo-jeweller-001	buy	gold	0.2772	7214.08	2000	60	2060	upi	completed		{}	t	2026-10-24 17:20:10.2811+00
9ecbd960-3131-44ac-9c2e-ab17d1acdd93	VDG26102948296	82db254e-16c1-447e-a5aa-dc4a74b47a8b	demo-jeweller-001	buy	gold	0.3506	7130.31	2500	75	2575	upi	completed		{}	t	2026-10-27 17:20:10.2811+00
4febbe7c-2540-44e3-94ba-68f85282b642	VDG26102983770	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	buy	gold	0.2773	7211.86	2000	60	2060	upi	completed		{}	t	2026-10-11 17:20:10.2811+00
4131bac1-86bc-4746-9333-c666132fd029	VDG26102992131	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	buy	gold	0.2811	7112.43	2000	60	2060	upi	completed		{}	t	2026-10-04 17:20:10.2811+00
75a58078-e794-469c-a25e-4fe0d5e2a994	VDG26102930141	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	sip	gold	0.7005	7137.23	5000	150	5150	upi	completed		{}	t	2026-10-10 17:20:10.2811+00
dc541801-513d-4fcf-8004-d7f875981abe	VDG26103117267	2b6458cc-ad07-4062-b8d1-eabbc66c7432	demo-jeweller-001	buy	gold	10	13948.5	139485	4184.55	143669.55	upi	completed		{"order_id": "a658ad44-3027-40e9-ad2c-316ca3e6a36a", "payment_id": "pay_mock_9bdc622c8bf942", "commission": 1000.0, "base_rate": 13848.5}	t	2026-10-31 12:29:46.162016+00
b5da192e-33d3-4dc7-b605-2c13e72c3a0d	VDG26103185943	2b6458cc-ad07-4062-b8d1-eabbc66c7432	demo-jeweller-001	buy	gold	10	13948.5	139485	4184.55	143669.55	upi	completed		{"order_id": "0754ba93-002d-41b5-ac2b-750900df08c8", "payment_id": "pay_mock_056d7efea3c746", "commission": 1000.0, "base_rate": 13848.5}	t	2026-10-31 12:30:31.619074+00
1f7a068a-59eb-49ac-8d6f-41cb830c6db9	VDG26103175465	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	buy	gold	1.1639	13948.5	16236.05	502.15	16738.2	upi	completed		{"order_id": "bde6ac03-d075-4825-bff6-5392c9ceefc4", "payment_id": "pay_mock_eb967d70cf9f4f", "commission": 116.39, "base_rate": 13848.5}	t	2026-10-31 15:21:16.585837+00
89e7667a-548d-44f3-8731-92ef62a18dbc	VDG26103173715	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	redemption	gold	1	13948.5	13948.5	0	0	vault_gold	processing	1g 24K Gold (vault) · Accepted by store	{"item": "1g 24K Gold (vault)"}	f	2026-10-31 15:21:17.619984+00
f26b252d-4aa0-4dcf-8a00-723f5ccc697b	VDG26103136822	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	buy	gold	0.0347	13948.5	485	15	500	upi	completed		{"order_id": "2a5172c6-796e-425e-a130-5090acc9a281", "payment_id": "pay_mock_4405c1b65ab84b", "commission": 3.47, "base_rate": 13848.5}	t	2026-10-31 15:23:07.392795+00
6339d4bc-addc-42bf-a68e-1beadcdc089d	VDG26103132996	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	redemption	gold	1	13948.5	13948.5	0	0	vault_gold	processing	1g 24K Gold (vault) · Accepted by store	{"item": "1g 24K Gold (vault)"}	f	2026-10-31 15:24:25.232366+00
a9a6d9f2-88f9-4354-82f7-33846b27ff11	VDG26103191315	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	buy	gold	1.1639	13948.5	16236.05	502.15	16738.2	upi	completed		{"order_id": "66e83a96-966f-425d-9e14-4b52ffd63e20", "payment_id": "pay_mock_bbf92e19bd1a48", "commission": 116.39, "base_rate": 13848.5}	t	2026-10-31 15:29:51.31213+00
dc4826da-582a-4b9e-a089-177997b3c38e	VDG26103164538	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	redemption	gold	1	13948.5	13948.5	0	0	vault_gold	processing	1g 24K Gold (vault) · Accepted by store	{"item": "1g 24K Gold (vault)"}	f	2026-10-31 15:29:52.2423+00
97b2e608-e67d-41fb-a050-b555c362f7ad	VDG26103167802	a44a44be-7a5d-4dfc-9b40-bf8a46e44bb7	demo-jeweller-001	sip	gold	0.0347	13948.5	485	15	500	upi_autopay	completed	Monthly SIP installment	{"sip_id": "27f7c0b7-efe8-4b8d-b210-35f737c09a77"}	t	2026-10-31 15:30:00.697437+00
c5c2bf33-a967-4de6-a6eb-75796ecb0907	VDG26103149350	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	buy	gold	1.1639	13948.5	16236.05	502.15	16738.2	upi	completed		{"order_id": "a5076b62-b706-4d69-994d-ad1753114260", "payment_id": "pay_mock_7911eadf00a94d", "commission": 116.39, "base_rate": 13848.5}	t	2026-10-31 15:31:18.622031+00
e28c4b36-be1a-4579-8da9-fd8abc09d664	VDG26103161394	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	redemption	gold	1	13948.5	13948.5	0	0	vault_gold	processing	1g 24K Gold (vault) · Accepted by store	{"item": "1g 24K Gold (vault)"}	f	2026-10-31 15:31:19.516083+00
f3c7534f-558f-46eb-896f-6f2f91d0bbd8	VDG26103149101	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	buy	gold	1.1639	13948.5	16236.05	502.15	16738.2	upi	completed		{"order_id": "e9a2abe7-628f-4467-b9b7-c939df348139", "payment_id": "pay_mock_75f28e03fb3940", "commission": 116.39, "base_rate": 13848.5}	t	2026-10-31 15:31:34.743336+00
9f4c8506-d81b-4420-bd9b-11357439f3cb	VDG26103142552	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	redemption	gold	1	13948.5	13948.5	0	0	vault_gold	processing	1g 24K Gold (vault) · Accepted by store	{"item": "1g 24K Gold (vault)"}	f	2026-10-31 15:31:35.931685+00
f294f43c-e6f8-4723-baa3-6020fd4381bc	VDG26103138851	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	buy	gold	1.1639	13948.5	16236.05	502.15	16738.2	upi	completed		{"order_id": "bf88aa49-3a06-453e-83ee-b2a181c5096c", "payment_id": "pay_mock_a23981f2aee048", "commission": 116.39, "base_rate": 13848.5}	t	2026-10-31 15:31:42.60578+00
b5638258-eaf3-4aeb-81ef-8436aa429475	VDG26103192993	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	redemption	gold	1	13948.5	13948.5	0	0	vault_gold	processing	1g 24K Gold (vault) · Accepted by store	{"item": "1g 24K Gold (vault)"}	f	2026-10-31 15:31:43.542915+00
4948f461-6a33-4d9b-9994-58329821557c	VDG26103132584	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	buy	gold	1.1639	13948.5	16236.05	502.15	16738.2	upi	completed		{"order_id": "a1640352-f0f1-4e44-81d3-2fb5d5e0ccb9", "payment_id": "pay_mock_d6d178e126054e", "commission": 116.39, "base_rate": 13848.5}	t	2026-10-31 15:31:50.418796+00
994b36a0-7df9-4120-a29c-84e0d0fde4a0	VDG26103110287	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	redemption	gold	1	13948.5	13948.5	0	0	vault_gold	processing	1g 24K Gold (vault) · Accepted by store	{"item": "1g 24K Gold (vault)"}	f	2026-10-31 15:31:51.326129+00
be5718f5-c623-476f-aede-b91fbd29d542	VDG26103114474	a44a44be-7a5d-4dfc-9b40-bf8a46e44bb7	demo-jeweller-001	buy	gold	0.1008	13948.5	1406.5	43.5	1450	upi	completed		{"order_id": "56b9e3cc-947d-470a-8c0c-8d6114485f6a", "payment_id": "pay_mock_972197797a0f49", "commission": 10.08, "base_rate": 13848.5}	t	2026-10-31 15:33:01.477731+00
58715725-02a3-4918-9cfb-1bfc3cce865b	VDG26103180059	a44a44be-7a5d-4dfc-9b40-bf8a46e44bb7	demo-jeweller-001	redemption	gold	1	13948.5	13948.5	0	0	vault_gold	processing	1g 24K Gold (vault) · Accepted by store	{"item": "1g 24K Gold (vault)"}	f	2026-10-31 15:35:46.20557+00
53f4d23b-a734-490e-a22f-656e4956b23b	VDG26103150349	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	buy	gold	1.1639	13948.5	16236.05	502.15	16738.2	upi	completed		{"order_id": "8c47661d-759d-447a-a44b-6fbb6da56455", "payment_id": "pay_mock_45ff23f1ecd44b", "commission": 116.39, "base_rate": 13848.5}	t	2026-10-31 15:37:01.440415+00
4528c3f2-9f14-422b-af02-956710de712b	VDG26103116995	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	redemption	gold	1	13948.5	13948.5	0	0	vault_gold	processing	1g 24K Gold (vault) · Accepted by store	{"item": "1g 24K Gold (vault)"}	f	2026-10-31 15:37:02.324486+00
\.


--
-- Data for Name: uploads; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.uploads (id, owner, path, content_type, size, created_at) FROM stdin;
c6f24b38-8f9b-402b-bffd-56d4e5d3175c	platform	vaultra-digigold/uploads/platform/d06d5c400d1043e9871bff00519ec1c0.png	image/png	762	2026-10-31 09:34:27.667206+00
7fcd0133-9232-46fc-9990-1e56697fd2ef	platform	vaultra-digigold/uploads/platform/f93e501c7ecb4dc5889f5f821a8fdcfd.png	image/png	3042	2026-10-31 09:37:32.929181+00
e93eaa1a-4183-4d88-bcad-398dec80c470	platform	vaultra-digigold/uploads/platform/41fd50180b2a4c8e84306370cd6b579c.png	image/png	762	2026-10-31 15:26:49.465341+00
\.


--
-- Data for Name: wallet_transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.wallet_transactions (id, customer_id, type, amount, description, created_at) FROM stdin;
\.


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: alerts alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_pkey PRIMARY KEY (id);


--
-- Name: app_settings app_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.app_settings
    ADD CONSTRAINT app_settings_pkey PRIMARY KEY (key);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: banners banners_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.banners
    ADD CONSTRAINT banners_pkey PRIMARY KEY (id);


--
-- Name: bifurcation_invoices bifurcation_invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bifurcation_invoices
    ADD CONSTRAINT bifurcation_invoices_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: customers customers_referral_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_referral_code_key UNIQUE (referral_code);


--
-- Name: customers customers_wallet_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_wallet_id_key UNIQUE (wallet_id);


--
-- Name: faqs faqs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faqs
    ADD CONSTRAINT faqs_pkey PRIMARY KEY (id);


--
-- Name: gifts gifts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gifts
    ADD CONSTRAINT gifts_pkey PRIMARY KEY (id);


--
-- Name: goals goals_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.goals
    ADD CONSTRAINT goals_pkey PRIMARY KEY (id);


--
-- Name: jewellers jewellers_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jewellers
    ADD CONSTRAINT jewellers_email_key UNIQUE (email);


--
-- Name: jewellers jewellers_phone_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jewellers
    ADD CONSTRAINT jewellers_phone_key UNIQUE (phone);


--
-- Name: jewellers jewellers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jewellers
    ADD CONSTRAINT jewellers_pkey PRIMARY KEY (id);


--
-- Name: master_admins master_admins_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.master_admins
    ADD CONSTRAINT master_admins_pkey PRIMARY KEY (id);


--
-- Name: master_admins master_admins_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.master_admins
    ADD CONSTRAINT master_admins_username_key UNIQUE (username);


--
-- Name: mt5_bookings mt5_bookings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mt5_bookings
    ADD CONSTRAINT mt5_bookings_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: otp_challenges otp_challenges_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.otp_challenges
    ADD CONSTRAINT otp_challenges_pkey PRIMARY KEY (id);


--
-- Name: pickups pickups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pickups
    ADD CONSTRAINT pickups_pkey PRIMARY KEY (id);


--
-- Name: pool_accumulator pool_accumulator_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pool_accumulator
    ADD CONSTRAINT pool_accumulator_pkey PRIMARY KEY (id);


--
-- Name: pool_contributions pool_contributions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pool_contributions
    ADD CONSTRAINT pool_contributions_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: quotes quotes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT quotes_pkey PRIMARY KEY (id);


--
-- Name: sips sips_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sips
    ADD CONSTRAINT sips_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: uploads uploads_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.uploads
    ADD CONSTRAINT uploads_pkey PRIMARY KEY (id);


--
-- Name: wallet_transactions wallet_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wallet_transactions
    ADD CONSTRAINT wallet_transactions_pkey PRIMARY KEY (id);


--
-- Name: ix_audit_logs_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_audit_logs_created_at ON public.audit_logs USING btree (created_at);


--
-- Name: ix_audit_logs_jeweller_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_audit_logs_jeweller_id ON public.audit_logs USING btree (jeweller_id);


--
-- Name: ix_banners_jeweller_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_banners_jeweller_id ON public.banners USING btree (jeweller_id);


--
-- Name: ix_customer_jeweller_phone; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_customer_jeweller_phone ON public.customers USING btree (jeweller_id, phone);


--
-- Name: ix_faqs_jeweller_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_faqs_jeweller_id ON public.faqs USING btree (jeweller_id);


--
-- Name: ix_txn_customer_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_txn_customer_date ON public.transactions USING btree (customer_id, created_at);


--
-- Name: ix_txn_jeweller_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_txn_jeweller_date ON public.transactions USING btree (jeweller_id, created_at);


--
-- Name: alerts alerts_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: alerts alerts_jeweller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_jeweller_id_fkey FOREIGN KEY (jeweller_id) REFERENCES public.jewellers(id);


--
-- Name: banners banners_jeweller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.banners
    ADD CONSTRAINT banners_jeweller_id_fkey FOREIGN KEY (jeweller_id) REFERENCES public.jewellers(id);


--
-- Name: bifurcation_invoices bifurcation_invoices_pool_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bifurcation_invoices
    ADD CONSTRAINT bifurcation_invoices_pool_id_fkey FOREIGN KEY (pool_id) REFERENCES public.pool_accumulator(id);


--
-- Name: customers customers_jeweller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_jeweller_id_fkey FOREIGN KEY (jeweller_id) REFERENCES public.jewellers(id);


--
-- Name: customers customers_referred_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_referred_by_fkey FOREIGN KEY (referred_by) REFERENCES public.customers(id);


--
-- Name: faqs faqs_jeweller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faqs
    ADD CONSTRAINT faqs_jeweller_id_fkey FOREIGN KEY (jeweller_id) REFERENCES public.jewellers(id);


--
-- Name: gifts gifts_jeweller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gifts
    ADD CONSTRAINT gifts_jeweller_id_fkey FOREIGN KEY (jeweller_id) REFERENCES public.jewellers(id);


--
-- Name: gifts gifts_recipient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gifts
    ADD CONSTRAINT gifts_recipient_id_fkey FOREIGN KEY (recipient_id) REFERENCES public.customers(id);


--
-- Name: gifts gifts_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gifts
    ADD CONSTRAINT gifts_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES public.customers(id);


--
-- Name: goals goals_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.goals
    ADD CONSTRAINT goals_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: notifications notifications_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: orders orders_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: orders orders_jeweller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_jeweller_id_fkey FOREIGN KEY (jeweller_id) REFERENCES public.jewellers(id);


--
-- Name: otp_challenges otp_challenges_jeweller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.otp_challenges
    ADD CONSTRAINT otp_challenges_jeweller_id_fkey FOREIGN KEY (jeweller_id) REFERENCES public.jewellers(id);


--
-- Name: pickups pickups_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pickups
    ADD CONSTRAINT pickups_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: pickups pickups_jeweller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pickups
    ADD CONSTRAINT pickups_jeweller_id_fkey FOREIGN KEY (jeweller_id) REFERENCES public.jewellers(id);


--
-- Name: pickups pickups_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pickups
    ADD CONSTRAINT pickups_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES public.transactions(id);


--
-- Name: pool_contributions pool_contributions_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pool_contributions
    ADD CONSTRAINT pool_contributions_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: pool_contributions pool_contributions_jeweller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pool_contributions
    ADD CONSTRAINT pool_contributions_jeweller_id_fkey FOREIGN KEY (jeweller_id) REFERENCES public.jewellers(id);


--
-- Name: pool_contributions pool_contributions_pool_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pool_contributions
    ADD CONSTRAINT pool_contributions_pool_id_fkey FOREIGN KEY (pool_id) REFERENCES public.pool_accumulator(id);


--
-- Name: pool_contributions pool_contributions_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pool_contributions
    ADD CONSTRAINT pool_contributions_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES public.transactions(id);


--
-- Name: products products_jeweller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_jeweller_id_fkey FOREIGN KEY (jeweller_id) REFERENCES public.jewellers(id);


--
-- Name: quotes quotes_jeweller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT quotes_jeweller_id_fkey FOREIGN KEY (jeweller_id) REFERENCES public.jewellers(id);


--
-- Name: sips sips_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sips
    ADD CONSTRAINT sips_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: sips sips_jeweller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sips
    ADD CONSTRAINT sips_jeweller_id_fkey FOREIGN KEY (jeweller_id) REFERENCES public.jewellers(id);


--
-- Name: transactions transactions_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: transactions transactions_jeweller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_jeweller_id_fkey FOREIGN KEY (jeweller_id) REFERENCES public.jewellers(id);


--
-- Name: wallet_transactions wallet_transactions_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wallet_transactions
    ADD CONSTRAINT wallet_transactions_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- PostgreSQL database dump complete
--

\unrestrict 2YHCTDHbh8AjRX2Umxh8D95xUgra8KQwTWF044YpmIJXPgbvAKUSWC3yQB3OgOJ

