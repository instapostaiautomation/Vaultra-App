--
-- PostgreSQL database dump
--

\restrict natpGd7rHVyc16oXa7W6xKCEJeve2FoeQ6nifJQntX8nGTtZQhs2qDdZMjAlE7p

-- Dumped from database version 15.19 (Debian 15.19-0+deb12u1)
-- Dumped by pg_dump version 15.19 (Debian 15.19-0+deb12u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alerts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alerts (
    id character varying NOT NULL,
    customer_id character varying NOT NULL,
    jeweller_id character varying NOT NULL,
    target double precision,
    metal character varying(10),
    alert_type character varying(10),
    buy_amount double precision,
    status character varying(20),
    triggered_at timestamp with time zone,
    triggered_price double precision,
    created_at timestamp with time zone
);


ALTER TABLE public.alerts OWNER TO postgres;

--
-- Name: app_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.app_settings (
    key character varying(100) NOT NULL,
    value text
);


ALTER TABLE public.app_settings OWNER TO postgres;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_logs (
    id character varying NOT NULL,
    actor_type character varying(20),
    actor_id character varying,
    actor_name character varying(200),
    jeweller_id character varying,
    action character varying(80),
    target character varying(200),
    detail json,
    created_at timestamp with time zone
);


ALTER TABLE public.audit_logs OWNER TO postgres;

--
-- Name: banners; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.banners (
    id character varying NOT NULL,
    jeweller_id character varying,
    title character varying(120),
    subtitle character varying(200),
    eyebrow character varying(60),
    image_url text,
    link character varying(60),
    sort integer,
    is_active boolean,
    created_at timestamp with time zone
);


ALTER TABLE public.banners OWNER TO postgres;

--
-- Name: bifurcation_invoices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bifurcation_invoices (
    id character varying NOT NULL,
    pool_id character varying NOT NULL,
    total_grams double precision,
    details json,
    status character varying(20),
    created_at timestamp with time zone
);


ALTER TABLE public.bifurcation_invoices OWNER TO postgres;

--
-- Name: customers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customers (
    id character varying NOT NULL,
    jeweller_id character varying NOT NULL,
    phone character varying(15) NOT NULL,
    first_name character varying(100),
    last_name character varying(100),
    email character varying(200),
    dob character varying(20),
    gender character varying(10),
    wallet_id character varying(20) NOT NULL,
    gold_grams double precision,
    silver_grams double precision,
    invested double precision,
    wallet_balance double precision,
    referral_code character varying(10) NOT NULL,
    referral_balance double precision,
    referred_by character varying,
    kyc_status character varying(20),
    kyc_data json,
    status character varying(20),
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.customers OWNER TO postgres;

--
-- Name: faqs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.faqs (
    id character varying NOT NULL,
    jeweller_id character varying,
    question text NOT NULL,
    answer text NOT NULL,
    sort integer,
    created_at timestamp with time zone
);


ALTER TABLE public.faqs OWNER TO postgres;

--
-- Name: gifts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gifts (
    id character varying NOT NULL,
    sender_id character varying NOT NULL,
    recipient_id character varying NOT NULL,
    jeweller_id character varying NOT NULL,
    grams double precision,
    rate double precision,
    amount double precision,
    theme character varying(30),
    message text,
    seen boolean,
    created_at timestamp with time zone
);


ALTER TABLE public.gifts OWNER TO postgres;

--
-- Name: goals; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.goals (
    id character varying NOT NULL,
    customer_id character varying NOT NULL,
    name character varying(100) NOT NULL,
    occasion character varying(50),
    target_grams double precision,
    months integer,
    deadline timestamp with time zone,
    start_grams double precision,
    created_at timestamp with time zone
);


ALTER TABLE public.goals OWNER TO postgres;

--
-- Name: jewellers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.jewellers (
    id character varying NOT NULL,
    business_name character varying(200) NOT NULL,
    owner_name character varying(200) NOT NULL,
    phone character varying(15) NOT NULL,
    email character varying(200) NOT NULL,
    password_hash character varying(200) NOT NULL,
    pan character varying(10),
    aadhaar character varying(12),
    address text,
    city character varying(100),
    state character varying(100),
    pincode character varying(6),
    logo_url character varying(500),
    primary_color character varying(7),
    secondary_color character varying(7),
    domain character varying(200),
    admin_domain character varying(200),
    gold_buy_markup_pct double precision,
    gold_sell_discount_pct double precision,
    silver_buy_markup_pct double precision,
    silver_sell_discount_pct double precision,
    gold_commission_per_g double precision,
    silver_commission_per_g double precision,
    min_redemption_grams double precision,
    status character varying(20),
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.jewellers OWNER TO postgres;

--
-- Name: master_admins; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.master_admins (
    id character varying NOT NULL,
    username character varying(100) NOT NULL,
    password_hash character varying(200) NOT NULL,
    name character varying(200),
    created_at timestamp with time zone
);


ALTER TABLE public.master_admins OWNER TO postgres;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications (
    id character varying NOT NULL,
    customer_id character varying NOT NULL,
    title character varying(200) NOT NULL,
    message text,
    type character varying(30),
    read boolean,
    created_at timestamp with time zone
);


ALTER TABLE public.notifications OWNER TO postgres;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    id character varying NOT NULL,
    customer_id character varying NOT NULL,
    jeweller_id character varying NOT NULL,
    metal character varying(10),
    grams double precision,
    rate double precision,
    amount double precision,
    gst double precision,
    total double precision,
    status character varying(20),
    provider character varying(20),
    payment_id character varying(100),
    method character varying(30),
    paid_at timestamp with time zone,
    created_at timestamp with time zone
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: otp_challenges; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.otp_challenges (
    id character varying NOT NULL,
    phone character varying(15) NOT NULL,
    jeweller_id character varying NOT NULL,
    digest character varying(100) NOT NULL,
    attempts integer,
    used boolean,
    created_at timestamp with time zone,
    expires_at timestamp with time zone NOT NULL
);


ALTER TABLE public.otp_challenges OWNER TO postgres;

--
-- Name: pickups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pickups (
    id character varying NOT NULL,
    customer_id character varying NOT NULL,
    jeweller_id character varying NOT NULL,
    transaction_id character varying NOT NULL,
    item character varying(200) NOT NULL,
    grams double precision,
    making_charges double precision,
    otp character varying(6) NOT NULL,
    attempts integer,
    locked boolean,
    status character varying(20),
    collected_at timestamp with time zone,
    collected_by character varying(100),
    created_at timestamp with time zone
);


ALTER TABLE public.pickups OWNER TO postgres;

--
-- Name: pool_accumulator; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pool_accumulator (
    id character varying NOT NULL,
    total_grams double precision,
    threshold_grams double precision,
    status character varying(20),
    triggered_at timestamp with time zone,
    procured_at timestamp with time zone,
    created_at timestamp with time zone
);


ALTER TABLE public.pool_accumulator OWNER TO postgres;

--
-- Name: pool_contributions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pool_contributions (
    id character varying NOT NULL,
    pool_id character varying NOT NULL,
    transaction_id character varying NOT NULL,
    customer_id character varying NOT NULL,
    jeweller_id character varying NOT NULL,
    grams double precision,
    created_at timestamp with time zone
);


ALTER TABLE public.pool_contributions OWNER TO postgres;

--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    id character varying NOT NULL,
    jeweller_id character varying NOT NULL,
    name character varying(200) NOT NULL,
    category character varying(50),
    grams double precision,
    making_charges double precision,
    making_pct double precision,
    image_url character varying(500),
    tag character varying(50),
    description text,
    is_active boolean,
    created_at timestamp with time zone
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: quotes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quotes (
    id character varying NOT NULL,
    jeweller_id character varying NOT NULL,
    metal character varying(10),
    buy double precision,
    sell double precision,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone
);


ALTER TABLE public.quotes OWNER TO postgres;

--
-- Name: sips; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sips (
    id character varying NOT NULL,
    customer_id character varying NOT NULL,
    jeweller_id character varying NOT NULL,
    amount double precision,
    frequency character varying(10),
    status character varying(20),
    installments integer,
    grams_accumulated double precision,
    next_run timestamp with time zone,
    created_at timestamp with time zone
);


ALTER TABLE public.sips OWNER TO postgres;

--
-- Name: transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.transactions (
    id character varying NOT NULL,
    invoice_no character varying(20) NOT NULL,
    customer_id character varying NOT NULL,
    jeweller_id character varying NOT NULL,
    type character varying(30) NOT NULL,
    metal character varying(10),
    grams double precision,
    rate double precision,
    amount double precision,
    gst double precision,
    total double precision,
    method character varying(30),
    status character varying(20),
    note text,
    extra json,
    pool_contribution boolean,
    created_at timestamp with time zone
);


ALTER TABLE public.transactions OWNER TO postgres;

--
-- Name: uploads; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.uploads (
    id character varying NOT NULL,
    owner character varying(80),
    path text NOT NULL,
    content_type character varying(80),
    size integer,
    created_at timestamp with time zone
);


ALTER TABLE public.uploads OWNER TO postgres;

--
-- Name: wallet_transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.wallet_transactions (
    id character varying NOT NULL,
    customer_id character varying NOT NULL,
    type character varying(20) NOT NULL,
    amount double precision,
    description text,
    created_at timestamp with time zone
);


ALTER TABLE public.wallet_transactions OWNER TO postgres;

--
-- Data for Name: alerts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alerts (id, customer_id, jeweller_id, target, metal, alert_type, buy_amount, status, triggered_at, triggered_price, created_at) FROM stdin;
\.


--
-- Data for Name: app_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.app_settings (key, value) FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_logs (id, actor_type, actor_id, actor_name, jeweller_id, action, target, detail, created_at) FROM stdin;
8a21f831-1e1c-43b0-aa7d-f3ab3dff4a71	jeweller	demo-jeweller-001	Sharma Gold & Jewellers	demo-jeweller-001	banner.add	TEST_Audit Shop Banner	{}	2026-10-29 08:45:45.966553+00
a67a936a-6082-4cb2-afb2-2bcff2a2f101	jeweller	demo-jeweller-001	Sharma Gold & Jewellers	demo-jeweller-001	banner.delete	TEST_Audit Shop Banner	{}	2026-10-29 08:45:46.094656+00
9ac6968d-6773-4f4e-8d5b-b88dc7dc55a1	jeweller	demo-jeweller-001	Sharma Gold & Jewellers	demo-jeweller-001	faq.add	TEST_Audit shop question?	{}	2026-10-29 08:45:46.371658+00
95999017-5516-4cb9-a179-fac71e8b18b6	jeweller	demo-jeweller-001	Sharma Gold & Jewellers	demo-jeweller-001	faq.delete	TEST_Audit shop question?	{}	2026-10-29 08:45:46.531901+00
ac90109b-6a29-4019-b5d0-603eecc23c84	master	80bbceaf-3908-43eb-ad29-9183086ba73d	Vaultra Super Admin	\N	banner.add	TEST_Audit Master Banner	{}	2026-10-29 08:45:50.099426+00
987c8100-1e2c-4de9-96a5-fabe996e0ad5	master	80bbceaf-3908-43eb-ad29-9183086ba73d	Vaultra Super Admin	\N	banner.delete	TEST_Audit Master Banner	{}	2026-10-29 08:45:50.218655+00
0108aa8f-7786-48ce-a60b-a85c8c19be5a	master	80bbceaf-3908-43eb-ad29-9183086ba73d	Vaultra Super Admin	\N	faq.add	TEST_Audit master question?	{}	2026-10-29 08:45:50.493984+00
0da2c27a-dc08-448f-8f23-be59c66db6bd	master	80bbceaf-3908-43eb-ad29-9183086ba73d	Vaultra Super Admin	\N	faq.delete	TEST_Audit master question?	{}	2026-10-29 08:45:50.630043+00
7db05aec-4558-4654-a5db-8a45456844f1	jeweller	demo-jeweller-001	Sharma Gold & Jewellers	demo-jeweller-001	product.add	TEST_NoTag Ring	{"grams": 2.0, "making_pct": 12.0}	2026-10-29 08:46:02.821604+00
fdc84b22-9c79-4ce8-8c26-3f9fe6911ab6	jeweller	demo-jeweller-001	Sharma Gold & Jewellers	demo-jeweller-001	banner.add	TEST_UI Remove Banner	{}	2026-10-29 08:46:58.523069+00
e05e0a8f-58cf-429f-8810-3af1020b5262	jeweller	demo-jeweller-001	Sharma Gold & Jewellers	demo-jeweller-001	faq.add	TEST_UI shop FAQ question?	{}	2026-10-29 08:47:42.607459+00
48922074-5b92-49f7-9c7b-f740d317c27d	jeweller	demo-jeweller-001	Sharma Gold & Jewellers	demo-jeweller-001	faq.delete	TEST_UI shop FAQ question?	{}	2026-10-29 08:47:44.623955+00
12e2a26d-655e-43b3-9719-b00f7cd8110d	jeweller	demo-jeweller-001	Sharma Gold & Jewellers	demo-jeweller-001	banner.delete	TEST_UI Remove Banner	{}	2026-10-29 08:47:46.658034+00
f266441e-6642-438b-b9be-5e5b3b2117e9	jeweller	demo-jeweller-001	Sharma Gold & Jewellers	demo-jeweller-001	product.delete	TEST_NoTag Ring	{}	2026-10-29 08:47:51.208256+00
494b84e4-79d2-4be5-8751-7223772a661e	master	80bbceaf-3908-43eb-ad29-9183086ba73d	Vaultra Super Admin	\N	faq.add	TEST_UI master FAQ question?	{}	2026-10-29 08:48:23.438429+00
056a8b46-9562-4df7-bcf0-7a9b04619b06	master	80bbceaf-3908-43eb-ad29-9183086ba73d	Vaultra Super Admin	\N	faq.delete	TEST_UI master FAQ question?	{}	2026-10-29 08:48:25.45971+00
\.


--
-- Data for Name: banners; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.banners (id, jeweller_id, title, subtitle, eyebrow, image_url, link, sort, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: bifurcation_invoices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bifurcation_invoices (id, pool_id, total_grams, details, status, created_at) FROM stdin;
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customers (id, jeweller_id, phone, first_name, last_name, email, dob, gender, wallet_id, gold_grams, silver_grams, invested, wallet_balance, referral_code, referral_balance, referred_by, kyc_status, kyc_data, status, created_at, updated_at) FROM stdin;
3397cd11-0326-46e9-b1d3-3a199ce64483	demo-jeweller-001	9876543210	Aarav	Sharma				VWDAAD5858	1.0538	0	7500	0	VDGFA3BB	0	\N	approved	{"full_name": "Aarav Sharma", "aadhaar": "649636246576", "pan": "AKFAB4049L", "dob": "1997-01-23", "submitted_at": "2026-10-29T08:44:42.086404+00:00", "reviewed_by": "Rajesh Sharma", "reviewed_at": "2026-10-29T08:44:42.086411+00:00"}	active	2026-09-13 08:44:42.086379+00	2026-10-29 08:44:42.091764+00
11804b66-742c-4276-84b0-8c551bd7ea0f	demo-jeweller-001	9812345670	Diya	Patel				VW19E62AE9	0.7029	0	5000	0	VDGD2482	0	\N	pending	{"full_name": "Diya Patel", "aadhaar": "256699052156", "pan": "GCDCL8499B", "dob": "1981-02-15", "submitted_at": "2026-10-29T08:44:42.094640+00:00"}	active	2026-08-31 08:44:42.086379+00	2026-10-29 08:44:42.096848+00
2488ddae-8765-4327-894b-73208b811de0	demo-jeweller-001	9823456781	Kabir	Singh				VWD163F47F	0.841	0	6000	0	VDG4C66E	0	\N	not_submitted	{}	active	2026-10-07 08:44:42.086379+00	2026-10-29 08:44:42.099094+00
2b96efa9-139a-4414-a8b4-40c7e0321aad	demo-jeweller-001	9834567892	Meera	Iyer				VW6B387A9C	0.6323	0	4500	0	VDGFF282	0	\N	approved	{"full_name": "Meera Iyer", "aadhaar": "913410197833", "pan": "JCDDL4118P", "dob": "1981-01-18", "submitted_at": "2026-10-29T08:44:42.099981+00:00", "reviewed_by": "Rajesh Sharma", "reviewed_at": "2026-10-29T08:44:42.099987+00:00"}	active	2026-08-31 08:44:42.086379+00	2026-10-29 08:44:42.101064+00
6febefdd-6862-43da-b426-b69c75310bce	demo-jeweller-002	9845678903	Rohan	Gupta				VWC77D241E	2.7891	0	19063.83	0	VDG8990F	0	\N	approved	{"full_name": "Rohan Gupta", "aadhaar": "527091619203", "pan": "ABCDE3109F", "submitted_at": "2026-10-29T08:44:42.101825+00:00", "reviewed_by": "Amit Patel", "reviewed_at": "2026-10-29T08:44:42.101831+00:00"}	active	2026-10-17 08:44:42.086379+00	2026-10-29 08:44:42.10243+00
ff795329-2fe3-4c7b-b3c2-d6baba07583b	demo-jeweller-002	9856789014	Ananya	Reddy				VW1646D4BA	4.5172	0	10585.86	0	VDGB7D32	0	\N	pending	{"full_name": "Ananya Reddy", "aadhaar": "572329591814", "pan": "ABCDE1858F", "submitted_at": "2026-10-29T08:44:42.101885+00:00"}	active	2026-10-13 08:44:42.086379+00	2026-10-29 08:44:42.102432+00
\.


--
-- Data for Name: faqs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.faqs (id, jeweller_id, question, answer, sort, created_at) FROM stdin;
\.


--
-- Data for Name: gifts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gifts (id, sender_id, recipient_id, jeweller_id, grams, rate, amount, theme, message, seen, created_at) FROM stdin;
\.


--
-- Data for Name: goals; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.goals (id, customer_id, name, occasion, target_grams, months, deadline, start_grams, created_at) FROM stdin;
\.


--
-- Data for Name: jewellers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.jewellers (id, business_name, owner_name, phone, email, password_hash, pan, aadhaar, address, city, state, pincode, logo_url, primary_color, secondary_color, domain, admin_domain, gold_buy_markup_pct, gold_sell_discount_pct, silver_buy_markup_pct, silver_sell_discount_pct, gold_commission_per_g, silver_commission_per_g, min_redemption_grams, status, created_at, updated_at) FROM stdin;
demo-jeweller-001	Sharma Gold & Jewellers	Rajesh Sharma	9999000001	sharma@vaultra.in	$2b$12$GsKXDXCnUPQIKlD5hOfumO3MKpxG8jaJfWS95.2eu8wdsHpqJud3i			Shop No. 12, Gold Market	Mumbai	Maharashtra	400001		#D4AF37	#1A1A2E			0	3	0	3	0	0	1	active	2026-10-29 08:44:42.083727+00	2026-10-29 08:44:42.083731+00
demo-jeweller-002	Patel Jewellery House	Amit Patel	9999000002	patel@vaultra.in	$2b$12$qaDtiHeCAYKiK/87TfLzvumhvAW1FNX2T2qNLr2MqRrQ5qYQix/nS			15, Jewellers Lane	Ahmedabad	Gujarat	380001		#B8860B	#2D2D44			0	3	0	3	0	0	0.5	active	2026-10-29 08:44:42.083733+00	2026-10-29 08:44:42.083734+00
\.


--
-- Data for Name: master_admins; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.master_admins (id, username, password_hash, name, created_at) FROM stdin;
80bbceaf-3908-43eb-ad29-9183086ba73d	admin	$2b$12$YU7BVyUPx2p1/DfOBpulneRxz0IxaJ9VTuJuFEOhbSJwqoRVSiTvO	Vaultra Super Admin	2026-10-29 08:44:42.085305+00
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications (id, customer_id, title, message, type, read, created_at) FROM stdin;
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (id, customer_id, jeweller_id, metal, grams, rate, amount, gst, total, status, provider, payment_id, method, paid_at, created_at) FROM stdin;
\.


--
-- Data for Name: otp_challenges; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.otp_challenges (id, phone, jeweller_id, digest, attempts, used, created_at, expires_at) FROM stdin;
2fd76a20-e362-4fca-b849-97bba22441f3	9876543210	demo-jeweller-001	7ca6d2dc4ff9acdf90011d495bce97ecaa42a1c12e1fb478e891fd2d078bc9d4	0	t	2026-10-29 08:46:18.05414+00	2026-10-29 08:51:18.053396+00
dffa2f4a-e9a6-4a9d-9b19-ef5b19207251	9876543210	demo-jeweller-001	91e31590a9e4fc95e5f636a715e765e55015799e73478e73514e87eb3ee22c97	0	t	2026-10-29 08:47:12.802573+00	2026-10-29 08:52:12.802306+00
\.


--
-- Data for Name: pickups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pickups (id, customer_id, jeweller_id, transaction_id, item, grams, making_charges, otp, attempts, locked, status, collected_at, collected_by, created_at) FROM stdin;
\.


--
-- Data for Name: pool_accumulator; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pool_accumulator (id, total_grams, threshold_grams, status, triggered_at, procured_at, created_at) FROM stdin;
69f54061-255b-4b5c-9105-105820624b8d	3.2299	10	accumulating	\N	\N	2026-10-29 08:44:42.088685+00
\.


--
-- Data for Name: pool_contributions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pool_contributions (id, pool_id, transaction_id, customer_id, jeweller_id, grams, created_at) FROM stdin;
48a27e56-e83d-4029-b18d-1009493a67b0	69f54061-255b-4b5c-9105-105820624b8d	f2399889-b44c-45a6-8f1d-ea24adfc53cb	3397cd11-0326-46e9-b1d3-3a199ce64483	demo-jeweller-001	0.2807	2026-10-29 08:44:42.095473+00
b748001b-9e9c-4f2f-a0c8-0f9b148a24a2	69f54061-255b-4b5c-9105-105820624b8d	2e2ae4e9-7af8-47ae-a81d-b727ae7633ca	3397cd11-0326-46e9-b1d3-3a199ce64483	demo-jeweller-001	0.139	2026-10-29 08:44:42.095475+00
08e0b653-cc77-47fd-9731-cabc77ee17c8	69f54061-255b-4b5c-9105-105820624b8d	70c050ba-8488-4490-91ce-f583acbb1cc7	3397cd11-0326-46e9-b1d3-3a199ce64483	demo-jeweller-001	0.2809	2026-10-29 08:44:42.095475+00
8680bd0e-7824-44c4-91ea-5117202f2374	69f54061-255b-4b5c-9105-105820624b8d	5c8c1da4-211b-4756-b3f0-e4497d05930b	3397cd11-0326-46e9-b1d3-3a199ce64483	demo-jeweller-001	0.3532	2026-10-29 08:44:42.095476+00
a2c7e294-5851-438f-afb9-35ab7f5ca2e0	69f54061-255b-4b5c-9105-105820624b8d	03dc0b13-992d-4d2f-8f03-bcf6faeeaab1	11804b66-742c-4276-84b0-8c551bd7ea0f	demo-jeweller-001	0.2807	2026-10-29 08:44:42.098314+00
fa375439-9fd8-41aa-8069-519c500aec29	69f54061-255b-4b5c-9105-105820624b8d	53458920-bda2-4e5d-be76-5a38cc763bc0	11804b66-742c-4276-84b0-8c551bd7ea0f	demo-jeweller-001	0.1397	2026-10-29 08:44:42.098316+00
564c15af-9e89-4e1c-b74d-aa351c40f0ae	69f54061-255b-4b5c-9105-105820624b8d	cd095d03-8ee1-47ca-a1e4-46b9bff3f18b	11804b66-742c-4276-84b0-8c551bd7ea0f	demo-jeweller-001	0.2825	2026-10-29 08:44:42.098317+00
d265c8f1-b0c8-41eb-bf70-ba7ad2a39af1	69f54061-255b-4b5c-9105-105820624b8d	bdefc0b9-dd0e-4b99-9289-48171ff849ed	2488ddae-8765-4327-894b-73208b811de0	demo-jeweller-001	0.3539	2026-10-29 08:44:42.100437+00
aac0d5c6-3077-4af3-9af6-089613e8931d	69f54061-255b-4b5c-9105-105820624b8d	e3ae4f28-27cd-4880-91c0-7a32a8c47a21	2488ddae-8765-4327-894b-73208b811de0	demo-jeweller-001	0.1407	2026-10-29 08:44:42.100438+00
ee4be35e-6faf-4028-b46b-2da166c7a0f4	69f54061-255b-4b5c-9105-105820624b8d	01457081-dcbd-42a0-9aba-288c9a4e55c8	2488ddae-8765-4327-894b-73208b811de0	demo-jeweller-001	0.3464	2026-10-29 08:44:42.100439+00
aeac1fe9-bcb6-4a2b-af5f-15c3de101f1a	69f54061-255b-4b5c-9105-105820624b8d	e335876c-6f27-4aa0-b0c5-d829cb8f737e	2b96efa9-139a-4414-a8b4-40c7e0321aad	demo-jeweller-001	0.3517	2026-10-29 08:44:42.102905+00
33f9be59-7847-4615-9790-45d48d4dc2f0	69f54061-255b-4b5c-9105-105820624b8d	27b8136d-f50e-4ecb-bdd8-a77b08652af3	2b96efa9-139a-4414-a8b4-40c7e0321aad	demo-jeweller-001	0.2806	2026-10-29 08:44:42.102906+00
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products (id, jeweller_id, name, category, grams, making_charges, making_pct, image_url, tag, description, is_active, created_at) FROM stdin;
72865346-da27-4315-8822-7dbf1f02cedc	demo-jeweller-001	Heritage 24K Necklace	necklaces	12.5	4850	12		Trending	Exquisite Heritage 24K Necklace in 24K 99.9% pure gold. Weight: 12.5g. BIS Hallmarked.	t	2026-10-29 08:44:42.089688+00
748f031e-0e7d-4a18-b246-b0a054edf9f1	demo-jeweller-001	Minimalist Gold Bangle	bangles	8.2	2650	12		Bestseller	Exquisite Minimalist Gold Bangle in 24K 99.9% pure gold. Weight: 8.2g. BIS Hallmarked.	t	2026-10-29 08:44:42.08969+00
3f3ab367-949e-4ccb-9866-907d42194330	demo-jeweller-001	Classic Solitaire Ring	rings	3.4	1150	12		New	Exquisite Classic Solitaire Ring in 24K 99.9% pure gold. Weight: 3.4g. BIS Hallmarked.	t	2026-10-29 08:44:42.089691+00
f28892ee-10b6-41b8-a144-fabddb396fa7	demo-jeweller-001	Rope Twist Chain	chains	6.8	1980	12		Trending	Exquisite Rope Twist Chain in 24K 99.9% pure gold. Weight: 6.8g. BIS Hallmarked.	t	2026-10-29 08:44:42.089692+00
9b58c0e6-31c0-4e07-a2f5-e9c727ae7eb5	demo-jeweller-001	Royal Kada	kadas	15	5200	12		Premium	Exquisite Royal Kada in 24K 99.9% pure gold. Weight: 15.0g. BIS Hallmarked.	t	2026-10-29 08:44:42.089693+00
b1e41434-0dd7-4a00-bbc3-219eb37bc47e	demo-jeweller-001	Lakshmi Pendant Set	pendant-sets	9.6	3400	12		Festive	Exquisite Lakshmi Pendant Set in 24K 99.9% pure gold. Weight: 9.6g. BIS Hallmarked.	t	2026-10-29 08:44:42.089693+00
1f2e225f-135a-404b-9e93-65fe951d55ba	demo-jeweller-001	Gold Dial Watch	watches	18	7900	12		Luxury	Exquisite Gold Dial Watch in 24K 99.9% pure gold. Weight: 18.0g. BIS Hallmarked.	t	2026-10-29 08:44:42.089694+00
b829f615-5eac-4857-a931-e662f34e0f5e	demo-jeweller-001	Tanmaniya Mangalsutra	necklaces	7.1	2300	12		Classic	Exquisite Tanmaniya Mangalsutra in 24K 99.9% pure gold. Weight: 7.1g. BIS Hallmarked.	t	2026-10-29 08:44:42.089695+00
c3f56a77-7103-4e62-b86a-cafe63b4cba6	demo-jeweller-002	Heritage 24K Necklace	necklaces	12.5	4850	12		Trending	Exquisite Heritage 24K Necklace in 24K 99.9% pure gold. Weight: 12.5g. BIS Hallmarked.	t	2026-10-29 08:44:42.089695+00
4f2a2837-680e-481e-a32b-bef2c0ea4d99	demo-jeweller-002	Minimalist Gold Bangle	bangles	8.2	2650	12		Bestseller	Exquisite Minimalist Gold Bangle in 24K 99.9% pure gold. Weight: 8.2g. BIS Hallmarked.	t	2026-10-29 08:44:42.089696+00
42c029a2-0e2d-4187-a554-1173e5fda0e7	demo-jeweller-002	Classic Solitaire Ring	rings	3.4	1150	12		New	Exquisite Classic Solitaire Ring in 24K 99.9% pure gold. Weight: 3.4g. BIS Hallmarked.	t	2026-10-29 08:44:42.089697+00
63f623d2-7baa-452b-9127-4c1c18f1125c	demo-jeweller-002	Rope Twist Chain	chains	6.8	1980	12		Trending	Exquisite Rope Twist Chain in 24K 99.9% pure gold. Weight: 6.8g. BIS Hallmarked.	t	2026-10-29 08:44:42.089697+00
82acfddc-c8c4-4d46-b4f4-a4bd0b20b457	demo-jeweller-002	Royal Kada	kadas	15	5200	12		Premium	Exquisite Royal Kada in 24K 99.9% pure gold. Weight: 15.0g. BIS Hallmarked.	t	2026-10-29 08:44:42.089698+00
2a6d8901-2845-47d9-b3bd-78b9f4cb8f01	demo-jeweller-002	Lakshmi Pendant Set	pendant-sets	9.6	3400	12		Festive	Exquisite Lakshmi Pendant Set in 24K 99.9% pure gold. Weight: 9.6g. BIS Hallmarked.	t	2026-10-29 08:44:42.089699+00
e2e5d63b-272a-4bdc-8e6c-473d10ef03b3	demo-jeweller-002	Gold Dial Watch	watches	18	7900	12		Luxury	Exquisite Gold Dial Watch in 24K 99.9% pure gold. Weight: 18.0g. BIS Hallmarked.	t	2026-10-29 08:44:42.089699+00
3808a8fc-2686-4354-9105-63a46c240b68	demo-jeweller-002	Tanmaniya Mangalsutra	necklaces	7.1	2300	12		Classic	Exquisite Tanmaniya Mangalsutra in 24K 99.9% pure gold. Weight: 7.1g. BIS Hallmarked.	t	2026-10-29 08:44:42.0897+00
c683367e-962d-44a5-a731-81b699e89ccb	demo-jeweller-001	TEST_NoTag Ring	rings	2	0	12				f	2026-10-29 08:46:02.822457+00
\.


--
-- Data for Name: quotes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quotes (id, jeweller_id, metal, buy, sell, expires_at, created_at) FROM stdin;
7f0cd988-2ce4-4ba9-ac3c-6a350433835f	demo-jeweller-001	gold	7274.32	7056.09	2026-10-29 08:51:18.685679+00	2026-10-29 08:46:18.686482+00
e92078b0-864b-4a05-8522-a4611efec816	demo-jeweller-001	gold	7284.82	7066.28	2026-10-29 08:53:35.686894+00	2026-10-29 08:48:35.687163+00
\.


--
-- Data for Name: sips; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sips (id, customer_id, jeweller_id, amount, frequency, status, installments, grams_accumulated, next_run, created_at) FROM stdin;
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.transactions (id, invoice_no, customer_id, jeweller_id, type, metal, grams, rate, amount, gst, total, method, status, note, extra, pool_contribution, created_at) FROM stdin;
f2399889-b44c-45a6-8f1d-ea24adfc53cb	VDG26102913418	3397cd11-0326-46e9-b1d3-3a199ce64483	demo-jeweller-001	sip	gold	0.2807	7124.25	2000	60	2060	upi	completed		{}	t	2026-10-10 08:44:42.086379+00
2e2ae4e9-7af8-47ae-a81d-b727ae7633ca	VDG26102977307	3397cd11-0326-46e9-b1d3-3a199ce64483	demo-jeweller-001	buy	gold	0.139	7193.81	1000	30	1030	upi	completed		{}	t	2026-10-02 08:44:42.086379+00
70c050ba-8488-4490-91ce-f583acbb1cc7	VDG26102937659	3397cd11-0326-46e9-b1d3-3a199ce64483	demo-jeweller-001	buy	gold	0.2809	7118.29	2000	60	2060	upi	completed		{}	t	2026-10-25 08:44:42.086379+00
5c8c1da4-211b-4756-b3f0-e4497d05930b	VDG26102937634	3397cd11-0326-46e9-b1d3-3a199ce64483	demo-jeweller-001	buy	gold	0.3532	7076.84	2500	75	2575	upi	completed		{}	t	2026-10-26 08:44:42.086379+00
03dc0b13-992d-4d2f-8f03-bcf6faeeaab1	VDG26102993655	11804b66-742c-4276-84b0-8c551bd7ea0f	demo-jeweller-001	buy	gold	0.2807	7124.94	2000	60	2060	upi	completed		{}	t	2026-10-28 08:44:42.086379+00
53458920-bda2-4e5d-be76-5a38cc763bc0	VDG26102913829	11804b66-742c-4276-84b0-8c551bd7ea0f	demo-jeweller-001	sip	gold	0.1397	7155.8	1000	30	1030	upi	completed		{}	t	2026-10-28 08:44:42.086379+00
cd095d03-8ee1-47ca-a1e4-46b9bff3f18b	VDG26102982104	11804b66-742c-4276-84b0-8c551bd7ea0f	demo-jeweller-001	buy	gold	0.2825	7078.42	2000	60	2060	upi	completed		{}	t	2026-10-13 08:44:42.086379+00
bdefc0b9-dd0e-4b99-9289-48171ff849ed	VDG26102982586	2488ddae-8765-4327-894b-73208b811de0	demo-jeweller-001	buy	gold	0.3539	7062.6	2500	75	2575	upi	completed		{}	t	2026-10-15 08:44:42.086379+00
e3ae4f28-27cd-4880-91c0-7a32a8c47a21	VDG26102924570	2488ddae-8765-4327-894b-73208b811de0	demo-jeweller-001	sip	gold	0.1407	7102.61	1000	30	1030	upi	completed		{}	t	2026-10-19 08:44:42.086379+00
01457081-dcbd-42a0-9aba-288c9a4e55c8	VDG26102929617	2488ddae-8765-4327-894b-73208b811de0	demo-jeweller-001	buy	gold	0.3464	7217.08	2500	75	2575	upi	completed		{}	t	2026-10-01 08:44:42.086379+00
e335876c-6f27-4aa0-b0c5-d829cb8f737e	VDG26102951392	2b96efa9-139a-4414-a8b4-40c7e0321aad	demo-jeweller-001	sip	gold	0.3517	7108	2500	75	2575	upi	completed		{}	t	2026-10-02 08:44:42.086379+00
27b8136d-f50e-4ecb-bdd8-a77b08652af3	VDG26102914293	2b96efa9-139a-4414-a8b4-40c7e0321aad	demo-jeweller-001	buy	gold	0.2806	7125.78	2000	60	2060	upi	completed		{}	t	2026-10-09 08:44:42.086379+00
\.


--
-- Data for Name: uploads; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.uploads (id, owner, path, content_type, size, created_at) FROM stdin;
0228ce75-2507-487a-a53e-26ace1f27fbd	demo-jeweller-001	vaultra-digigold/uploads/demo-jeweller-001/db9a1bf3cd97484ca9d8e0142dc35fd6.png	image/png	74	2026-10-29 08:45:45.768228+00
6b7f0732-6473-4401-be19-30a7d9fc97c4	platform	vaultra-digigold/uploads/platform/916b78b55d084aa9889862f6fa778524.png	image/png	74	2026-10-29 08:45:49.954748+00
89d10f54-46d1-434e-9446-5f5858a90655	demo-jeweller-001	vaultra-digigold/uploads/demo-jeweller-001/27f187eeb76341dca560c21ffa997559.png	image/png	6	2026-10-29 08:46:58.391253+00
\.


--
-- Data for Name: wallet_transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.wallet_transactions (id, customer_id, type, amount, description, created_at) FROM stdin;
\.


--
-- Name: alerts alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_pkey PRIMARY KEY (id);


--
-- Name: app_settings app_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.app_settings
    ADD CONSTRAINT app_settings_pkey PRIMARY KEY (key);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: banners banners_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.banners
    ADD CONSTRAINT banners_pkey PRIMARY KEY (id);


--
-- Name: bifurcation_invoices bifurcation_invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bifurcation_invoices
    ADD CONSTRAINT bifurcation_invoices_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: customers customers_referral_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_referral_code_key UNIQUE (referral_code);


--
-- Name: customers customers_wallet_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_wallet_id_key UNIQUE (wallet_id);


--
-- Name: faqs faqs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faqs
    ADD CONSTRAINT faqs_pkey PRIMARY KEY (id);


--
-- Name: gifts gifts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gifts
    ADD CONSTRAINT gifts_pkey PRIMARY KEY (id);


--
-- Name: goals goals_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.goals
    ADD CONSTRAINT goals_pkey PRIMARY KEY (id);


--
-- Name: jewellers jewellers_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jewellers
    ADD CONSTRAINT jewellers_email_key UNIQUE (email);


--
-- Name: jewellers jewellers_phone_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jewellers
    ADD CONSTRAINT jewellers_phone_key UNIQUE (phone);


--
-- Name: jewellers jewellers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jewellers
    ADD CONSTRAINT jewellers_pkey PRIMARY KEY (id);


--
-- Name: master_admins master_admins_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.master_admins
    ADD CONSTRAINT master_admins_pkey PRIMARY KEY (id);


--
-- Name: master_admins master_admins_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.master_admins
    ADD CONSTRAINT master_admins_username_key UNIQUE (username);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: otp_challenges otp_challenges_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.otp_challenges
    ADD CONSTRAINT otp_challenges_pkey PRIMARY KEY (id);


--
-- Name: pickups pickups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pickups
    ADD CONSTRAINT pickups_pkey PRIMARY KEY (id);


--
-- Name: pool_accumulator pool_accumulator_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pool_accumulator
    ADD CONSTRAINT pool_accumulator_pkey PRIMARY KEY (id);


--
-- Name: pool_contributions pool_contributions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pool_contributions
    ADD CONSTRAINT pool_contributions_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: quotes quotes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT quotes_pkey PRIMARY KEY (id);


--
-- Name: sips sips_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sips
    ADD CONSTRAINT sips_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: uploads uploads_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.uploads
    ADD CONSTRAINT uploads_pkey PRIMARY KEY (id);


--
-- Name: wallet_transactions wallet_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wallet_transactions
    ADD CONSTRAINT wallet_transactions_pkey PRIMARY KEY (id);


--
-- Name: ix_audit_logs_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_audit_logs_created_at ON public.audit_logs USING btree (created_at);


--
-- Name: ix_audit_logs_jeweller_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_audit_logs_jeweller_id ON public.audit_logs USING btree (jeweller_id);


--
-- Name: ix_banners_jeweller_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_banners_jeweller_id ON public.banners USING btree (jeweller_id);


--
-- Name: ix_customer_jeweller_phone; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_customer_jeweller_phone ON public.customers USING btree (jeweller_id, phone);


--
-- Name: ix_faqs_jeweller_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_faqs_jeweller_id ON public.faqs USING btree (jeweller_id);


--
-- Name: ix_txn_customer_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_txn_customer_date ON public.transactions USING btree (customer_id, created_at);


--
-- Name: ix_txn_jeweller_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_txn_jeweller_date ON public.transactions USING btree (jeweller_id, created_at);


--
-- Name: alerts alerts_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: alerts alerts_jeweller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_jeweller_id_fkey FOREIGN KEY (jeweller_id) REFERENCES public.jewellers(id);


--
-- Name: banners banners_jeweller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.banners
    ADD CONSTRAINT banners_jeweller_id_fkey FOREIGN KEY (jeweller_id) REFERENCES public.jewellers(id);


--
-- Name: bifurcation_invoices bifurcation_invoices_pool_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bifurcation_invoices
    ADD CONSTRAINT bifurcation_invoices_pool_id_fkey FOREIGN KEY (pool_id) REFERENCES public.pool_accumulator(id);


--
-- Name: customers customers_jeweller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_jeweller_id_fkey FOREIGN KEY (jeweller_id) REFERENCES public.jewellers(id);


--
-- Name: customers customers_referred_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_referred_by_fkey FOREIGN KEY (referred_by) REFERENCES public.customers(id);


--
-- Name: faqs faqs_jeweller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faqs
    ADD CONSTRAINT faqs_jeweller_id_fkey FOREIGN KEY (jeweller_id) REFERENCES public.jewellers(id);


--
-- Name: gifts gifts_jeweller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gifts
    ADD CONSTRAINT gifts_jeweller_id_fkey FOREIGN KEY (jeweller_id) REFERENCES public.jewellers(id);


--
-- Name: gifts gifts_recipient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gifts
    ADD CONSTRAINT gifts_recipient_id_fkey FOREIGN KEY (recipient_id) REFERENCES public.customers(id);


--
-- Name: gifts gifts_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gifts
    ADD CONSTRAINT gifts_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES public.customers(id);


--
-- Name: goals goals_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.goals
    ADD CONSTRAINT goals_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: notifications notifications_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: orders orders_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: orders orders_jeweller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_jeweller_id_fkey FOREIGN KEY (jeweller_id) REFERENCES public.jewellers(id);


--
-- Name: otp_challenges otp_challenges_jeweller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.otp_challenges
    ADD CONSTRAINT otp_challenges_jeweller_id_fkey FOREIGN KEY (jeweller_id) REFERENCES public.jewellers(id);


--
-- Name: pickups pickups_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pickups
    ADD CONSTRAINT pickups_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: pickups pickups_jeweller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pickups
    ADD CONSTRAINT pickups_jeweller_id_fkey FOREIGN KEY (jeweller_id) REFERENCES public.jewellers(id);


--
-- Name: pickups pickups_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pickups
    ADD CONSTRAINT pickups_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES public.transactions(id);


--
-- Name: pool_contributions pool_contributions_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pool_contributions
    ADD CONSTRAINT pool_contributions_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: pool_contributions pool_contributions_jeweller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pool_contributions
    ADD CONSTRAINT pool_contributions_jeweller_id_fkey FOREIGN KEY (jeweller_id) REFERENCES public.jewellers(id);


--
-- Name: pool_contributions pool_contributions_pool_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pool_contributions
    ADD CONSTRAINT pool_contributions_pool_id_fkey FOREIGN KEY (pool_id) REFERENCES public.pool_accumulator(id);


--
-- Name: pool_contributions pool_contributions_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pool_contributions
    ADD CONSTRAINT pool_contributions_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES public.transactions(id);


--
-- Name: products products_jeweller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_jeweller_id_fkey FOREIGN KEY (jeweller_id) REFERENCES public.jewellers(id);


--
-- Name: quotes quotes_jeweller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT quotes_jeweller_id_fkey FOREIGN KEY (jeweller_id) REFERENCES public.jewellers(id);


--
-- Name: sips sips_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sips
    ADD CONSTRAINT sips_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: sips sips_jeweller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sips
    ADD CONSTRAINT sips_jeweller_id_fkey FOREIGN KEY (jeweller_id) REFERENCES public.jewellers(id);


--
-- Name: transactions transactions_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: transactions transactions_jeweller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_jeweller_id_fkey FOREIGN KEY (jeweller_id) REFERENCES public.jewellers(id);


--
-- Name: wallet_transactions wallet_transactions_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wallet_transactions
    ADD CONSTRAINT wallet_transactions_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- PostgreSQL database dump complete
--

\unrestrict natpGd7rHVyc16oXa7W6xKCEJeve2FoeQ6nifJQntX8nGTtZQhs2qDdZMjAlE7p

