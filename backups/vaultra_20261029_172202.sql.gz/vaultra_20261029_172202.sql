--
-- PostgreSQL database dump
--

\restrict aJgFC8OaYf05tlzeuWoflg2ciVGrJi8gsU8X51wIDIcml2H3a6MZZPxgD4n0vzy

-- Dumped from database version 15.19 (Debian 15.19-0+deb12u1)
-- Dumped by pg_dump version 15.19 (Debian 15.19-0+deb12u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alerts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alerts (
    id character varying NOT NULL,
    customer_id character varying NOT NULL,
    jeweller_id character varying NOT NULL,
    target double precision,
    metal character varying(10),
    alert_type character varying(10),
    buy_amount double precision,
    status character varying(20),
    triggered_at timestamp with time zone,
    triggered_price double precision,
    created_at timestamp with time zone
);


ALTER TABLE public.alerts OWNER TO postgres;

--
-- Name: app_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.app_settings (
    key character varying(100) NOT NULL,
    value text
);


ALTER TABLE public.app_settings OWNER TO postgres;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_logs (
    id character varying NOT NULL,
    actor_type character varying(20),
    actor_id character varying,
    actor_name character varying(200),
    jeweller_id character varying,
    action character varying(80),
    target character varying(200),
    detail json,
    created_at timestamp with time zone
);


ALTER TABLE public.audit_logs OWNER TO postgres;

--
-- Name: banners; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.banners (
    id character varying NOT NULL,
    jeweller_id character varying,
    title character varying(120),
    subtitle character varying(200),
    eyebrow character varying(60),
    image_url text,
    link character varying(60),
    sort integer,
    is_active boolean,
    created_at timestamp with time zone
);


ALTER TABLE public.banners OWNER TO postgres;

--
-- Name: bifurcation_invoices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bifurcation_invoices (
    id character varying NOT NULL,
    pool_id character varying NOT NULL,
    total_grams double precision,
    details json,
    status character varying(20),
    created_at timestamp with time zone
);


ALTER TABLE public.bifurcation_invoices OWNER TO postgres;

--
-- Name: customers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customers (
    id character varying NOT NULL,
    jeweller_id character varying NOT NULL,
    phone character varying(15) NOT NULL,
    first_name character varying(100),
    last_name character varying(100),
    email character varying(200),
    dob character varying(20),
    gender character varying(10),
    wallet_id character varying(20) NOT NULL,
    gold_grams double precision,
    silver_grams double precision,
    invested double precision,
    wallet_balance double precision,
    referral_code character varying(10) NOT NULL,
    referral_balance double precision,
    referred_by character varying,
    kyc_status character varying(20),
    kyc_data json,
    status character varying(20),
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.customers OWNER TO postgres;

--
-- Name: faqs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.faqs (
    id character varying NOT NULL,
    jeweller_id character varying,
    question text NOT NULL,
    answer text NOT NULL,
    sort integer,
    created_at timestamp with time zone
);


ALTER TABLE public.faqs OWNER TO postgres;

--
-- Name: gifts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gifts (
    id character varying NOT NULL,
    sender_id character varying NOT NULL,
    recipient_id character varying NOT NULL,
    jeweller_id character varying NOT NULL,
    grams double precision,
    rate double precision,
    amount double precision,
    theme character varying(30),
    message text,
    seen boolean,
    created_at timestamp with time zone
);


ALTER TABLE public.gifts OWNER TO postgres;

--
-- Name: goals; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.goals (
    id character varying NOT NULL,
    customer_id character varying NOT NULL,
    name character varying(100) NOT NULL,
    occasion character varying(50),
    target_grams double precision,
    months integer,
    deadline timestamp with time zone,
    start_grams double precision,
    created_at timestamp with time zone
);


ALTER TABLE public.goals OWNER TO postgres;

--
-- Name: jewellers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.jewellers (
    id character varying NOT NULL,
    business_name character varying(200) NOT NULL,
    owner_name character varying(200) NOT NULL,
    phone character varying(15) NOT NULL,
    email character varying(200) NOT NULL,
    password_hash character varying(200) NOT NULL,
    pan character varying(10),
    aadhaar character varying(12),
    address text,
    city character varying(100),
    state character varying(100),
    pincode character varying(6),
    logo_url character varying(500),
    primary_color character varying(7),
    secondary_color character varying(7),
    domain character varying(200),
    admin_domain character varying(200),
    gold_buy_markup_pct double precision,
    gold_sell_discount_pct double precision,
    silver_buy_markup_pct double precision,
    silver_sell_discount_pct double precision,
    gold_commission_per_g double precision,
    silver_commission_per_g double precision,
    min_redemption_grams double precision,
    status character varying(20),
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.jewellers OWNER TO postgres;

--
-- Name: master_admins; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.master_admins (
    id character varying NOT NULL,
    username character varying(100) NOT NULL,
    password_hash character varying(200) NOT NULL,
    name character varying(200),
    created_at timestamp with time zone
);


ALTER TABLE public.master_admins OWNER TO postgres;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications (
    id character varying NOT NULL,
    customer_id character varying NOT NULL,
    title character varying(200) NOT NULL,
    message text,
    type character varying(30),
    read boolean,
    created_at timestamp with time zone
);


ALTER TABLE public.notifications OWNER TO postgres;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    id character varying NOT NULL,
    customer_id character varying NOT NULL,
    jeweller_id character varying NOT NULL,
    metal character varying(10),
    grams double precision,
    rate double precision,
    amount double precision,
    gst double precision,
    total double precision,
    status character varying(20),
    provider character varying(20),
    payment_id character varying(100),
    method character varying(30),
    paid_at timestamp with time zone,
    created_at timestamp with time zone
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: otp_challenges; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.otp_challenges (
    id character varying NOT NULL,
    phone character varying(15) NOT NULL,
    jeweller_id character varying NOT NULL,
    digest character varying(100) NOT NULL,
    attempts integer,
    used boolean,
    created_at timestamp with time zone,
    expires_at timestamp with time zone NOT NULL
);


ALTER TABLE public.otp_challenges OWNER TO postgres;

--
-- Name: pickups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pickups (
    id character varying NOT NULL,
    customer_id character varying NOT NULL,
    jeweller_id character varying NOT NULL,
    transaction_id character varying NOT NULL,
    item character varying(200) NOT NULL,
    grams double precision,
    making_charges double precision,
    otp character varying(6) NOT NULL,
    attempts integer,
    locked boolean,
    status character varying(20),
    collected_at timestamp with time zone,
    collected_by character varying(100),
    created_at timestamp with time zone
);


ALTER TABLE public.pickups OWNER TO postgres;

--
-- Name: pool_accumulator; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pool_accumulator (
    id character varying NOT NULL,
    total_grams double precision,
    threshold_grams double precision,
    status character varying(20),
    triggered_at timestamp with time zone,
    procured_at timestamp with time zone,
    created_at timestamp with time zone
);


ALTER TABLE public.pool_accumulator OWNER TO postgres;

--
-- Name: pool_contributions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pool_contributions (
    id character varying NOT NULL,
    pool_id character varying NOT NULL,
    transaction_id character varying NOT NULL,
    customer_id character varying NOT NULL,
    jeweller_id character varying NOT NULL,
    grams double precision,
    created_at timestamp with time zone
);


ALTER TABLE public.pool_contributions OWNER TO postgres;

--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    id character varying NOT NULL,
    jeweller_id character varying NOT NULL,
    name character varying(200) NOT NULL,
    category character varying(50),
    grams double precision,
    making_charges double precision,
    making_pct double precision,
    image_url character varying(500),
    tag character varying(50),
    description text,
    is_active boolean,
    created_at timestamp with time zone
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: quotes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quotes (
    id character varying NOT NULL,
    jeweller_id character varying NOT NULL,
    metal character varying(10),
    buy double precision,
    sell double precision,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone
);


ALTER TABLE public.quotes OWNER TO postgres;

--
-- Name: sips; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sips (
    id character varying NOT NULL,
    customer_id character varying NOT NULL,
    jeweller_id character varying NOT NULL,
    amount double precision,
    frequency character varying(10),
    status character varying(20),
    installments integer,
    grams_accumulated double precision,
    next_run timestamp with time zone,
    created_at timestamp with time zone
);


ALTER TABLE public.sips OWNER TO postgres;

--
-- Name: transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.transactions (
    id character varying NOT NULL,
    invoice_no character varying(20) NOT NULL,
    customer_id character varying NOT NULL,
    jeweller_id character varying NOT NULL,
    type character varying(30) NOT NULL,
    metal character varying(10),
    grams double precision,
    rate double precision,
    amount double precision,
    gst double precision,
    total double precision,
    method character varying(30),
    status character varying(20),
    note text,
    extra json,
    pool_contribution boolean,
    created_at timestamp with time zone
);


ALTER TABLE public.transactions OWNER TO postgres;

--
-- Name: uploads; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.uploads (
    id character varying NOT NULL,
    owner character varying(80),
    path text NOT NULL,
    content_type character varying(80),
    size integer,
    created_at timestamp with time zone
);


ALTER TABLE public.uploads OWNER TO postgres;

--
-- Name: wallet_transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.wallet_transactions (
    id character varying NOT NULL,
    customer_id character varying NOT NULL,
    type character varying(20) NOT NULL,
    amount double precision,
    description text,
    created_at timestamp with time zone
);


ALTER TABLE public.wallet_transactions OWNER TO postgres;

--
-- Data for Name: alerts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alerts (id, customer_id, jeweller_id, target, metal, alert_type, buy_amount, status, triggered_at, triggered_price, created_at) FROM stdin;
\.


--
-- Data for Name: app_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.app_settings (key, value) FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_logs (id, actor_type, actor_id, actor_name, jeweller_id, action, target, detail, created_at) FROM stdin;
\.


--
-- Data for Name: banners; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.banners (id, jeweller_id, title, subtitle, eyebrow, image_url, link, sort, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: bifurcation_invoices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bifurcation_invoices (id, pool_id, total_grams, details, status, created_at) FROM stdin;
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customers (id, jeweller_id, phone, first_name, last_name, email, dob, gender, wallet_id, gold_grams, silver_grams, invested, wallet_balance, referral_code, referral_balance, referred_by, kyc_status, kyc_data, status, created_at, updated_at) FROM stdin;
a44a44be-7a5d-4dfc-9b40-bf8a46e44bb7	demo-jeweller-001	9876543210	Aarav	Sharma				VWF7DB64F3	1.3211	0	9500	0	VDGB174B	0	\N	approved	{"full_name": "Aarav Sharma", "aadhaar": "265406846313", "pan": "BLABK2581H", "dob": "1999-03-27", "submitted_at": "2026-10-29T17:20:10.281124+00:00", "reviewed_by": "Rajesh Sharma", "reviewed_at": "2026-10-29T17:20:10.281131+00:00"}	active	2026-09-30 17:20:10.2811+00	2026-10-29 17:20:10.286532+00
41d1e25d-a0b9-4aba-8eaf-f86db84c90e0	demo-jeweller-001	9812345670	Diya	Patel				VW9BA41C99	1.9619	0	14000	0	VDG4F90B	0	\N	pending	{"full_name": "Diya Patel", "aadhaar": "953512406178", "pan": "EAKEH5991B", "dob": "1989-06-24", "submitted_at": "2026-10-29T17:20:10.289542+00:00"}	active	2026-09-21 17:20:10.2811+00	2026-10-29 17:20:10.291866+00
82db254e-16c1-447e-a5aa-dc4a74b47a8b	demo-jeweller-001	9823456781	Kabir	Singh				VW26A58F6A	0.7661	0	5500	0	VDGF55C9	0	\N	not_submitted	{}	active	2026-09-24 17:20:10.2811+00	2026-10-29 17:20:10.294284+00
b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	9834567892	Meera	Iyer				VWBA53DDA3	1.2589	0	9000	0	VDG66C84	0	\N	approved	{"full_name": "Meera Iyer", "aadhaar": "967639474945", "pan": "CEKAD3863L", "dob": "1995-06-20", "submitted_at": "2026-10-29T17:20:10.295151+00:00", "reviewed_by": "Rajesh Sharma", "reviewed_at": "2026-10-29T17:20:10.295157+00:00"}	active	2026-09-08 17:20:10.2811+00	2026-10-29 17:20:10.296294+00
222e4eab-ca73-4416-aa7b-2178a2f4bfa5	demo-jeweller-002	9845678903	Rohan	Gupta				VW6B3C665E	3.497	0	14039.32	0	VDG2F7A9	0	\N	approved	{"full_name": "Rohan Gupta", "aadhaar": "365029128486", "pan": "ABCDE9553F", "submitted_at": "2026-10-29T17:20:10.297107+00:00", "reviewed_by": "Amit Patel", "reviewed_at": "2026-10-29T17:20:10.297113+00:00"}	active	2026-09-30 17:20:10.2811+00	2026-10-29 17:20:10.297841+00
da1f8f82-7646-4c0d-97e3-866fb9ad3c9c	demo-jeweller-002	9856789014	Ananya	Reddy				VWA7808BF8	1.6018	0	25200.2	0	VDG5240C	0	\N	pending	{"full_name": "Ananya Reddy", "aadhaar": "284623663928", "pan": "ABCDE4150F", "submitted_at": "2026-10-29T17:20:10.297179+00:00"}	active	2026-09-24 17:20:10.2811+00	2026-10-29 17:20:10.297843+00
\.


--
-- Data for Name: faqs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.faqs (id, jeweller_id, question, answer, sort, created_at) FROM stdin;
\.


--
-- Data for Name: gifts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gifts (id, sender_id, recipient_id, jeweller_id, grams, rate, amount, theme, message, seen, created_at) FROM stdin;
\.


--
-- Data for Name: goals; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.goals (id, customer_id, name, occasion, target_grams, months, deadline, start_grams, created_at) FROM stdin;
\.


--
-- Data for Name: jewellers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.jewellers (id, business_name, owner_name, phone, email, password_hash, pan, aadhaar, address, city, state, pincode, logo_url, primary_color, secondary_color, domain, admin_domain, gold_buy_markup_pct, gold_sell_discount_pct, silver_buy_markup_pct, silver_sell_discount_pct, gold_commission_per_g, silver_commission_per_g, min_redemption_grams, status, created_at, updated_at) FROM stdin;
demo-jeweller-001	Sharma Gold & Jewellers	Rajesh Sharma	9999000001	sharma@vaultra.in	$2b$12$MMeli6cE/4bhMIQR6.d7kOApimrxLfqVhpA62YguIQcBJi5qhZA.m			Shop No. 12, Gold Market	Mumbai	Maharashtra	400001		#D4AF37	#1A1A2E			0	3	0	3	0	0	1	active	2026-10-29 17:20:10.27839+00	2026-10-29 17:20:10.278395+00
demo-jeweller-002	Patel Jewellery House	Amit Patel	9999000002	patel@vaultra.in	$2b$12$sa.F/YLYNGjih9jvHB8k0e6wyukgNtH6pnscBF3cPjoiVFuFl7Z2u			15, Jewellers Lane	Ahmedabad	Gujarat	380001		#B8860B	#2D2D44			0	3	0	3	0	0	0.5	active	2026-10-29 17:20:10.278397+00	2026-10-29 17:20:10.278397+00
\.


--
-- Data for Name: master_admins; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.master_admins (id, username, password_hash, name, created_at) FROM stdin;
97effbae-d8c9-4c54-ba50-fae1d757cd34	admin	$2b$12$ZHLXtXTkFomLMfZsuiCp3OzMSfbiYyGx9h4olZQ7PNx5Io2X0/Pl.	Vaultra Super Admin	2026-10-29 17:20:10.280024+00
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications (id, customer_id, title, message, type, read, created_at) FROM stdin;
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (id, customer_id, jeweller_id, metal, grams, rate, amount, gst, total, status, provider, payment_id, method, paid_at, created_at) FROM stdin;
\.


--
-- Data for Name: otp_challenges; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.otp_challenges (id, phone, jeweller_id, digest, attempts, used, created_at, expires_at) FROM stdin;
\.


--
-- Data for Name: pickups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pickups (id, customer_id, jeweller_id, transaction_id, item, grams, making_charges, otp, attempts, locked, status, collected_at, collected_by, created_at) FROM stdin;
\.


--
-- Data for Name: pool_accumulator; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pool_accumulator (id, total_grams, threshold_grams, status, triggered_at, procured_at, created_at) FROM stdin;
99ad57ba-3279-4b85-a7df-38285e0bbc11	5.308	10	accumulating	\N	\N	2026-10-29 17:20:10.283388+00
\.


--
-- Data for Name: pool_contributions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pool_contributions (id, pool_id, transaction_id, customer_id, jeweller_id, grams, created_at) FROM stdin;
00e031d9-c2c1-48c7-957a-002ea22e05f1	99ad57ba-3279-4b85-a7df-38285e0bbc11	23228a8e-449e-4537-9c72-e88a1742f0be	a44a44be-7a5d-4dfc-9b40-bf8a46e44bb7	demo-jeweller-001	0.6912	2026-10-29 17:20:10.290422+00
666084ff-caeb-4844-a320-39649a5f324f	99ad57ba-3279-4b85-a7df-38285e0bbc11	95fb4a30-1a33-4932-b26f-cae182e99e7d	a44a44be-7a5d-4dfc-9b40-bf8a46e44bb7	demo-jeweller-001	0.1398	2026-10-29 17:20:10.290424+00
b7a0622e-c74c-43e2-8c20-2540f4e9b771	99ad57ba-3279-4b85-a7df-38285e0bbc11	9857cdc2-117c-4239-a36d-9e7989bf20c8	a44a44be-7a5d-4dfc-9b40-bf8a46e44bb7	demo-jeweller-001	0.3489	2026-10-29 17:20:10.290425+00
92395091-ab8f-4b8e-94ce-9648dca674da	99ad57ba-3279-4b85-a7df-38285e0bbc11	824ed577-2969-4c96-aa6d-0779cd756ce8	a44a44be-7a5d-4dfc-9b40-bf8a46e44bb7	demo-jeweller-001	0.1412	2026-10-29 17:20:10.290425+00
de223fa0-1b81-414e-abd1-e9bbea69fd43	99ad57ba-3279-4b85-a7df-38285e0bbc11	6a3c6fe2-5fc2-4365-ba07-a0c7b0c16387	41d1e25d-a0b9-4aba-8eaf-f86db84c90e0	demo-jeweller-001	0.2818	2026-10-29 17:20:10.293464+00
f489ae0e-49c3-4b96-889a-bb6a77ea1459	99ad57ba-3279-4b85-a7df-38285e0bbc11	8bee719f-343e-414d-97f0-442a6f9aec27	41d1e25d-a0b9-4aba-8eaf-f86db84c90e0	demo-jeweller-001	0.6926	2026-10-29 17:20:10.293465+00
85de36dc-9922-4823-b2cc-c37507b500bd	99ad57ba-3279-4b85-a7df-38285e0bbc11	4b87c8f9-d877-499c-a3d2-e9b317931b11	41d1e25d-a0b9-4aba-8eaf-f86db84c90e0	demo-jeweller-001	0.2809	2026-10-29 17:20:10.293466+00
1054bf78-09cc-43b2-bb2e-17c1fa874130	99ad57ba-3279-4b85-a7df-38285e0bbc11	e686bfc6-3cd7-473b-a55c-1498f9d1e8b3	41d1e25d-a0b9-4aba-8eaf-f86db84c90e0	demo-jeweller-001	0.7066	2026-10-29 17:20:10.293467+00
ee194386-b91b-4194-9c36-c0661c18724b	99ad57ba-3279-4b85-a7df-38285e0bbc11	8dca3297-067a-4c8a-b342-650af3b4f8a2	82db254e-16c1-447e-a5aa-dc4a74b47a8b	demo-jeweller-001	0.1383	2026-10-29 17:20:10.295616+00
432058f1-63f4-4767-9c21-da3efd45374f	99ad57ba-3279-4b85-a7df-38285e0bbc11	928df523-99b4-4c8a-9f4f-4c8a89df4c43	82db254e-16c1-447e-a5aa-dc4a74b47a8b	demo-jeweller-001	0.2772	2026-10-29 17:20:10.295617+00
4ed73f9f-f575-43cb-9004-13fdac934b30	99ad57ba-3279-4b85-a7df-38285e0bbc11	9ecbd960-3131-44ac-9c2e-ab17d1acdd93	82db254e-16c1-447e-a5aa-dc4a74b47a8b	demo-jeweller-001	0.3506	2026-10-29 17:20:10.295618+00
ff02cee4-604f-45a4-80c4-a2499257aa5a	99ad57ba-3279-4b85-a7df-38285e0bbc11	4febbe7c-2540-44e3-94ba-68f85282b642	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	0.2773	2026-10-29 17:20:10.298398+00
bca3b58b-4caf-4c80-a742-61e3a245a224	99ad57ba-3279-4b85-a7df-38285e0bbc11	4131bac1-86bc-4746-9333-c666132fd029	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	0.2811	2026-10-29 17:20:10.2984+00
21b8397e-f7f3-44b4-8248-53b874fa9373	99ad57ba-3279-4b85-a7df-38285e0bbc11	75a58078-e794-469c-a25e-4fe0d5e2a994	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	0.7005	2026-10-29 17:20:10.298401+00
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products (id, jeweller_id, name, category, grams, making_charges, making_pct, image_url, tag, description, is_active, created_at) FROM stdin;
c3515e35-dc58-411b-a6a3-a221450315c9	demo-jeweller-001	Heritage 24K Necklace	necklaces	12.5	4850	12		Trending	Exquisite Heritage 24K Necklace in 24K 99.9% pure gold. Weight: 12.5g. BIS Hallmarked.	t	2026-10-29 17:20:10.284403+00
40a805d9-2427-4ce7-a882-af2cd43f84a5	demo-jeweller-001	Minimalist Gold Bangle	bangles	8.2	2650	12		Bestseller	Exquisite Minimalist Gold Bangle in 24K 99.9% pure gold. Weight: 8.2g. BIS Hallmarked.	t	2026-10-29 17:20:10.284406+00
f2adc2ee-761f-4ec9-a45d-645cbf2c33ba	demo-jeweller-001	Classic Solitaire Ring	rings	3.4	1150	12		New	Exquisite Classic Solitaire Ring in 24K 99.9% pure gold. Weight: 3.4g. BIS Hallmarked.	t	2026-10-29 17:20:10.284407+00
8384fd53-c28e-4d45-8cc6-dc867f075525	demo-jeweller-001	Rope Twist Chain	chains	6.8	1980	12		Trending	Exquisite Rope Twist Chain in 24K 99.9% pure gold. Weight: 6.8g. BIS Hallmarked.	t	2026-10-29 17:20:10.284407+00
cd661d0a-3ac1-4baa-a31c-f42c610d8552	demo-jeweller-001	Royal Kada	kadas	15	5200	12		Premium	Exquisite Royal Kada in 24K 99.9% pure gold. Weight: 15.0g. BIS Hallmarked.	t	2026-10-29 17:20:10.284408+00
ea2e8948-c241-4dd7-a593-13e2fcfb24a6	demo-jeweller-001	Lakshmi Pendant Set	pendant-sets	9.6	3400	12		Festive	Exquisite Lakshmi Pendant Set in 24K 99.9% pure gold. Weight: 9.6g. BIS Hallmarked.	t	2026-10-29 17:20:10.284409+00
0bc97d0d-5b9e-4c60-98ec-082bf6d026c9	demo-jeweller-001	Gold Dial Watch	watches	18	7900	12		Luxury	Exquisite Gold Dial Watch in 24K 99.9% pure gold. Weight: 18.0g. BIS Hallmarked.	t	2026-10-29 17:20:10.28441+00
72e1b4f3-cf74-439f-b0a5-bee51b6850cb	demo-jeweller-001	Tanmaniya Mangalsutra	necklaces	7.1	2300	12		Classic	Exquisite Tanmaniya Mangalsutra in 24K 99.9% pure gold. Weight: 7.1g. BIS Hallmarked.	t	2026-10-29 17:20:10.28441+00
73ca1326-ef53-4271-a728-ddd82b9c886e	demo-jeweller-002	Heritage 24K Necklace	necklaces	12.5	4850	12		Trending	Exquisite Heritage 24K Necklace in 24K 99.9% pure gold. Weight: 12.5g. BIS Hallmarked.	t	2026-10-29 17:20:10.284411+00
842599c5-f135-4b55-bcb3-cbafb1689b09	demo-jeweller-002	Minimalist Gold Bangle	bangles	8.2	2650	12		Bestseller	Exquisite Minimalist Gold Bangle in 24K 99.9% pure gold. Weight: 8.2g. BIS Hallmarked.	t	2026-10-29 17:20:10.284412+00
14009c99-d550-433d-8a60-84fd875d1b8c	demo-jeweller-002	Classic Solitaire Ring	rings	3.4	1150	12		New	Exquisite Classic Solitaire Ring in 24K 99.9% pure gold. Weight: 3.4g. BIS Hallmarked.	t	2026-10-29 17:20:10.284412+00
f8efc8b6-1c3e-4103-bfaf-32e7a73cb23a	demo-jeweller-002	Rope Twist Chain	chains	6.8	1980	12		Trending	Exquisite Rope Twist Chain in 24K 99.9% pure gold. Weight: 6.8g. BIS Hallmarked.	t	2026-10-29 17:20:10.284413+00
753b7b8f-c932-4642-9455-220e9dd9ec6a	demo-jeweller-002	Royal Kada	kadas	15	5200	12		Premium	Exquisite Royal Kada in 24K 99.9% pure gold. Weight: 15.0g. BIS Hallmarked.	t	2026-10-29 17:20:10.284414+00
35aeb3f0-471a-44c1-9056-3d2bf59b8693	demo-jeweller-002	Lakshmi Pendant Set	pendant-sets	9.6	3400	12		Festive	Exquisite Lakshmi Pendant Set in 24K 99.9% pure gold. Weight: 9.6g. BIS Hallmarked.	t	2026-10-29 17:20:10.284414+00
fd3fb337-95f5-46fe-a51c-85098cb85973	demo-jeweller-002	Gold Dial Watch	watches	18	7900	12		Luxury	Exquisite Gold Dial Watch in 24K 99.9% pure gold. Weight: 18.0g. BIS Hallmarked.	t	2026-10-29 17:20:10.284415+00
5c1bc9a1-4459-4689-8618-bce78ef665e7	demo-jeweller-002	Tanmaniya Mangalsutra	necklaces	7.1	2300	12		Classic	Exquisite Tanmaniya Mangalsutra in 24K 99.9% pure gold. Weight: 7.1g. BIS Hallmarked.	t	2026-10-29 17:20:10.284416+00
\.


--
-- Data for Name: quotes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quotes (id, jeweller_id, metal, buy, sell, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: sips; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sips (id, customer_id, jeweller_id, amount, frequency, status, installments, grams_accumulated, next_run, created_at) FROM stdin;
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.transactions (id, invoice_no, customer_id, jeweller_id, type, metal, grams, rate, amount, gst, total, method, status, note, extra, pool_contribution, created_at) FROM stdin;
23228a8e-449e-4537-9c72-e88a1742f0be	VDG26102919917	a44a44be-7a5d-4dfc-9b40-bf8a46e44bb7	demo-jeweller-001	sip	gold	0.6912	7233.73	5000	150	5150	upi	completed		{}	t	2026-10-10 17:20:10.2811+00
95fb4a30-1a33-4932-b26f-cae182e99e7d	VDG26102954802	a44a44be-7a5d-4dfc-9b40-bf8a46e44bb7	demo-jeweller-001	sip	gold	0.1398	7152.21	1000	30	1030	upi	completed		{}	t	2026-10-22 17:20:10.2811+00
9857cdc2-117c-4239-a36d-9e7989bf20c8	VDG26102953729	a44a44be-7a5d-4dfc-9b40-bf8a46e44bb7	demo-jeweller-001	buy	gold	0.3489	7163.46	2500	75	2575	upi	completed		{}	t	2026-10-27 17:20:10.2811+00
824ed577-2969-4c96-aa6d-0779cd756ce8	VDG26102963510	a44a44be-7a5d-4dfc-9b40-bf8a46e44bb7	demo-jeweller-001	sip	gold	0.1412	7080.87	1000	30	1030	upi	completed		{}	t	2026-10-07 17:20:10.2811+00
6a3c6fe2-5fc2-4365-ba07-a0c7b0c16387	VDG26102955773	41d1e25d-a0b9-4aba-8eaf-f86db84c90e0	demo-jeweller-001	sip	gold	0.2818	7096.98	2000	60	2060	upi	completed		{}	t	2026-10-26 17:20:10.2811+00
8bee719f-343e-414d-97f0-442a6f9aec27	VDG26102963075	41d1e25d-a0b9-4aba-8eaf-f86db84c90e0	demo-jeweller-001	buy	gold	0.6926	7218.72	5000	150	5150	upi	completed		{}	t	2026-10-03 17:20:10.2811+00
4b87c8f9-d877-499c-a3d2-e9b317931b11	VDG26102914742	41d1e25d-a0b9-4aba-8eaf-f86db84c90e0	demo-jeweller-001	buy	gold	0.2809	7119.66	2000	60	2060	upi	completed		{}	t	2026-10-18 17:20:10.2811+00
e686bfc6-3cd7-473b-a55c-1498f9d1e8b3	VDG26102971601	41d1e25d-a0b9-4aba-8eaf-f86db84c90e0	demo-jeweller-001	buy	gold	0.7066	7076.05	5000	150	5150	upi	completed		{}	t	2026-10-11 17:20:10.2811+00
8dca3297-067a-4c8a-b342-650af3b4f8a2	VDG26102917575	82db254e-16c1-447e-a5aa-dc4a74b47a8b	demo-jeweller-001	buy	gold	0.1383	7227.1	1000	30	1030	upi	completed		{}	t	2026-10-09 17:20:10.2811+00
928df523-99b4-4c8a-9f4f-4c8a89df4c43	VDG26102980806	82db254e-16c1-447e-a5aa-dc4a74b47a8b	demo-jeweller-001	buy	gold	0.2772	7214.08	2000	60	2060	upi	completed		{}	t	2026-10-24 17:20:10.2811+00
9ecbd960-3131-44ac-9c2e-ab17d1acdd93	VDG26102948296	82db254e-16c1-447e-a5aa-dc4a74b47a8b	demo-jeweller-001	buy	gold	0.3506	7130.31	2500	75	2575	upi	completed		{}	t	2026-10-27 17:20:10.2811+00
4febbe7c-2540-44e3-94ba-68f85282b642	VDG26102983770	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	buy	gold	0.2773	7211.86	2000	60	2060	upi	completed		{}	t	2026-10-11 17:20:10.2811+00
4131bac1-86bc-4746-9333-c666132fd029	VDG26102992131	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	buy	gold	0.2811	7112.43	2000	60	2060	upi	completed		{}	t	2026-10-04 17:20:10.2811+00
75a58078-e794-469c-a25e-4fe0d5e2a994	VDG26102930141	b37c10f7-5af1-4711-817b-b53849d7016c	demo-jeweller-001	sip	gold	0.7005	7137.23	5000	150	5150	upi	completed		{}	t	2026-10-10 17:20:10.2811+00
\.


--
-- Data for Name: uploads; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.uploads (id, owner, path, content_type, size, created_at) FROM stdin;
\.


--
-- Data for Name: wallet_transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.wallet_transactions (id, customer_id, type, amount, description, created_at) FROM stdin;
\.


--
-- Name: alerts alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_pkey PRIMARY KEY (id);


--
-- Name: app_settings app_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.app_settings
    ADD CONSTRAINT app_settings_pkey PRIMARY KEY (key);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: banners banners_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.banners
    ADD CONSTRAINT banners_pkey PRIMARY KEY (id);


--
-- Name: bifurcation_invoices bifurcation_invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bifurcation_invoices
    ADD CONSTRAINT bifurcation_invoices_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: customers customers_referral_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_referral_code_key UNIQUE (referral_code);


--
-- Name: customers customers_wallet_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_wallet_id_key UNIQUE (wallet_id);


--
-- Name: faqs faqs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faqs
    ADD CONSTRAINT faqs_pkey PRIMARY KEY (id);


--
-- Name: gifts gifts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gifts
    ADD CONSTRAINT gifts_pkey PRIMARY KEY (id);


--
-- Name: goals goals_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.goals
    ADD CONSTRAINT goals_pkey PRIMARY KEY (id);


--
-- Name: jewellers jewellers_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jewellers
    ADD CONSTRAINT jewellers_email_key UNIQUE (email);


--
-- Name: jewellers jewellers_phone_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jewellers
    ADD CONSTRAINT jewellers_phone_key UNIQUE (phone);


--
-- Name: jewellers jewellers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jewellers
    ADD CONSTRAINT jewellers_pkey PRIMARY KEY (id);


--
-- Name: master_admins master_admins_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.master_admins
    ADD CONSTRAINT master_admins_pkey PRIMARY KEY (id);


--
-- Name: master_admins master_admins_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.master_admins
    ADD CONSTRAINT master_admins_username_key UNIQUE (username);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: otp_challenges otp_challenges_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.otp_challenges
    ADD CONSTRAINT otp_challenges_pkey PRIMARY KEY (id);


--
-- Name: pickups pickups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pickups
    ADD CONSTRAINT pickups_pkey PRIMARY KEY (id);


--
-- Name: pool_accumulator pool_accumulator_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pool_accumulator
    ADD CONSTRAINT pool_accumulator_pkey PRIMARY KEY (id);


--
-- Name: pool_contributions pool_contributions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pool_contributions
    ADD CONSTRAINT pool_contributions_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: quotes quotes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT quotes_pkey PRIMARY KEY (id);


--
-- Name: sips sips_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sips
    ADD CONSTRAINT sips_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: uploads uploads_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.uploads
    ADD CONSTRAINT uploads_pkey PRIMARY KEY (id);


--
-- Name: wallet_transactions wallet_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wallet_transactions
    ADD CONSTRAINT wallet_transactions_pkey PRIMARY KEY (id);


--
-- Name: ix_audit_logs_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_audit_logs_created_at ON public.audit_logs USING btree (created_at);


--
-- Name: ix_audit_logs_jeweller_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_audit_logs_jeweller_id ON public.audit_logs USING btree (jeweller_id);


--
-- Name: ix_banners_jeweller_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_banners_jeweller_id ON public.banners USING btree (jeweller_id);


--
-- Name: ix_customer_jeweller_phone; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_customer_jeweller_phone ON public.customers USING btree (jeweller_id, phone);


--
-- Name: ix_faqs_jeweller_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_faqs_jeweller_id ON public.faqs USING btree (jeweller_id);


--
-- Name: ix_txn_customer_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_txn_customer_date ON public.transactions USING btree (customer_id, created_at);


--
-- Name: ix_txn_jeweller_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_txn_jeweller_date ON public.transactions USING btree (jeweller_id, created_at);


--
-- Name: alerts alerts_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: alerts alerts_jeweller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_jeweller_id_fkey FOREIGN KEY (jeweller_id) REFERENCES public.jewellers(id);


--
-- Name: banners banners_jeweller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.banners
    ADD CONSTRAINT banners_jeweller_id_fkey FOREIGN KEY (jeweller_id) REFERENCES public.jewellers(id);


--
-- Name: bifurcation_invoices bifurcation_invoices_pool_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bifurcation_invoices
    ADD CONSTRAINT bifurcation_invoices_pool_id_fkey FOREIGN KEY (pool_id) REFERENCES public.pool_accumulator(id);


--
-- Name: customers customers_jeweller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_jeweller_id_fkey FOREIGN KEY (jeweller_id) REFERENCES public.jewellers(id);


--
-- Name: customers customers_referred_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_referred_by_fkey FOREIGN KEY (referred_by) REFERENCES public.customers(id);


--
-- Name: faqs faqs_jeweller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faqs
    ADD CONSTRAINT faqs_jeweller_id_fkey FOREIGN KEY (jeweller_id) REFERENCES public.jewellers(id);


--
-- Name: gifts gifts_jeweller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gifts
    ADD CONSTRAINT gifts_jeweller_id_fkey FOREIGN KEY (jeweller_id) REFERENCES public.jewellers(id);


--
-- Name: gifts gifts_recipient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gifts
    ADD CONSTRAINT gifts_recipient_id_fkey FOREIGN KEY (recipient_id) REFERENCES public.customers(id);


--
-- Name: gifts gifts_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gifts
    ADD CONSTRAINT gifts_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES public.customers(id);


--
-- Name: goals goals_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.goals
    ADD CONSTRAINT goals_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: notifications notifications_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: orders orders_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: orders orders_jeweller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_jeweller_id_fkey FOREIGN KEY (jeweller_id) REFERENCES public.jewellers(id);


--
-- Name: otp_challenges otp_challenges_jeweller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.otp_challenges
    ADD CONSTRAINT otp_challenges_jeweller_id_fkey FOREIGN KEY (jeweller_id) REFERENCES public.jewellers(id);


--
-- Name: pickups pickups_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pickups
    ADD CONSTRAINT pickups_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: pickups pickups_jeweller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pickups
    ADD CONSTRAINT pickups_jeweller_id_fkey FOREIGN KEY (jeweller_id) REFERENCES public.jewellers(id);


--
-- Name: pickups pickups_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pickups
    ADD CONSTRAINT pickups_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES public.transactions(id);


--
-- Name: pool_contributions pool_contributions_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pool_contributions
    ADD CONSTRAINT pool_contributions_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: pool_contributions pool_contributions_jeweller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pool_contributions
    ADD CONSTRAINT pool_contributions_jeweller_id_fkey FOREIGN KEY (jeweller_id) REFERENCES public.jewellers(id);


--
-- Name: pool_contributions pool_contributions_pool_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pool_contributions
    ADD CONSTRAINT pool_contributions_pool_id_fkey FOREIGN KEY (pool_id) REFERENCES public.pool_accumulator(id);


--
-- Name: pool_contributions pool_contributions_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pool_contributions
    ADD CONSTRAINT pool_contributions_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES public.transactions(id);


--
-- Name: products products_jeweller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_jeweller_id_fkey FOREIGN KEY (jeweller_id) REFERENCES public.jewellers(id);


--
-- Name: quotes quotes_jeweller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT quotes_jeweller_id_fkey FOREIGN KEY (jeweller_id) REFERENCES public.jewellers(id);


--
-- Name: sips sips_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sips
    ADD CONSTRAINT sips_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: sips sips_jeweller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sips
    ADD CONSTRAINT sips_jeweller_id_fkey FOREIGN KEY (jeweller_id) REFERENCES public.jewellers(id);


--
-- Name: transactions transactions_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: transactions transactions_jeweller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_jeweller_id_fkey FOREIGN KEY (jeweller_id) REFERENCES public.jewellers(id);


--
-- Name: wallet_transactions wallet_transactions_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wallet_transactions
    ADD CONSTRAINT wallet_transactions_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- PostgreSQL database dump complete
--

\unrestrict aJgFC8OaYf05tlzeuWoflg2ciVGrJi8gsU8X51wIDIcml2H3a6MZZPxgD4n0vzy

